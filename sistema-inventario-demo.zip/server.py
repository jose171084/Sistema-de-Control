"""
server.py - Servidor HTTP RESTful puro en Python 3 (Sin dependencias externas ni pip).
Gestiona el sistema de control de inventarios, productos, servicios, facturación multimoneda y compras.
"""

import http.server
import socketserver
import os
import json
import sqlite3
import urllib.parse
import urllib.request
import ssl
import mimetypes
import base64
import time
import re
import shutil
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
import database
from database import (
    procesar_devolucion_compra,
    anular_devolucion_compra,
    anular_factura_venta, anular_devolucion_cliente, anular_compra_proveedor,
    anular_abono_cxc, anular_abono_cxp, anular_cuenta_cxp_directa,
    obtener_estado_cuenta_cliente_cxc, obtener_estado_cuenta_proveedor_cxp,
    get_connection, init_db, DB_PATH, 
    limpiar_transacciones_db, restablecer_fabrica_db, 
    schedule_cloud_sync, get_supabase_config,
    auditar_y_migrar_db, migrar_historico_inventario,
    conciliar_inventario, registrar_movimiento_inventario,
    calcular_cpp_entrada, calcular_valor_salida_cpp, validar_stock_no_negativo,
    validar_movimiento_no_retroactivo, ErrorStockNegativo, 
    ErrorMovimientoRetroactivoNoPermitido, ErrorInconsistenciaCPP,
    ErrorCostoHistoricoNoRecuperable, ErrorCantidadDevolucionExcedeDisponible,
    ErrorAnulacionAjusteConMovimientosPosteriores,
    procesar_ajuste_inventario_cpp, anular_ajuste_inventario,
    resolver_subtipo_ajuste_canonico, SUBTIPOS_AJUSTE_CANONICOS,
    obtener_cuentas_tesoreria, obtener_resumen_tesoreria,
    registrar_pago_financiero, anular_pago_financiero,
    aplicar_anticipo_cliente, abrir_caja_turno, cerrar_caja_turno,
    registrar_gasto_operativo, transferir_entre_cuentas_tesoreria,
    obtener_historial_pagos, obtener_anticipos_cliente, obtener_gastos_operativos
)
from inventario_ia import diagnosticar_inventario_organico, simular_impacto_precio
import cfo_copilot

PORT = int(os.environ.get("PORT", 8000))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")

os.makedirs(PUBLIC_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)

def obtener_tasas_oficiales():
    """
    Consulta las tasas oficiales en tiempo real:
    - BCV (Banco Central de Venezuela): ve.dolarapi.com/v1/dolares/oficial con fallback scraping bcv.org.ve
    - TRM Colombia: open.er-api.com y api.exchangerate-api.com
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    tasa_ves = None
    tasa_cop = None
    fuentes = []
    errores = []

    # 1. Tasa BCV Oficial (Venezuela)
    try:
        req_ves = urllib.request.Request(
            'https://ve.dolarapi.com/v1/dolares/oficial', 
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        with urllib.request.urlopen(req_ves, timeout=4, context=ctx) as r:
            data_ves = json.loads(r.read().decode('utf-8'))
            val_ves = data_ves.get('promedio')
            if val_ves:
                tasa_ves = round(float(val_ves), 4)
                fuentes.append("BCV Oficial")
    except Exception as e_ves:
        errores.append(f"DolarApi: {str(e_ves)}")
        try:
            req_bcv = urllib.request.Request(
                'https://www.bcv.org.ve',
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )
            with urllib.request.urlopen(req_bcv, timeout=4, context=ctx) as r_bcv:
                html = r_bcv.read().decode('utf-8', errors='ignore')
                m = re.search(r'id=[\"\']dolar[\"\'].*?<strong[^>]*>\s*([0-9.,]+)\s*</strong>', html, re.DOTALL | re.IGNORECASE)
                if m:
                    val_str = m.group(1).strip().replace('.', '').replace(',', '.')
                    tasa_ves = round(float(val_str), 4)
                    fuentes.append("BCV Oficial (Web Directa)")
        except Exception as e_bcv:
            errores.append(f"BCV Directo: {str(e_bcv)}")

    # 2. Tasa TRM Oficial (Colombia)
    for url_cop in ['https://open.er-api.com/v6/latest/USD', 'https://api.exchangerate-api.com/v4/latest/USD']:
        try:
            req_cop = urllib.request.Request(
                url_cop, 
                headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
            )
            with urllib.request.urlopen(req_cop, timeout=4, context=ctx) as r:
                data_cop = json.loads(r.read().decode('utf-8'))
                rates = data_cop.get("rates", {})
                if "COP" in rates and rates["COP"]:
                    tasa_cop = round(float(rates["COP"]), 2)
                    fuentes.append("TRM Colombia")
                    break
        except Exception as e_cop:
            errores.append(f"TRM ({url_cop}): {str(e_cop)}")
            continue

    fuente_str = " / ".join(fuentes) if fuentes else "Error de conexión"
    error_str = "; ".join(errores) if errores else None
    return tasa_ves, tasa_cop, fuente_str, error_str

class InventoryAppHandler(http.server.BaseHTTPRequestHandler):

    def send_json(self, data, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()
        self.wfile.write(json.dumps(data, ensure_ascii=False).encode("utf-8"))

    def send_error_json(self, message, status=400):
        self.send_json({"error": message, "success": False}, status=status)

    def parse_body_json(self):
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length == 0:
                return {}
            body_bytes = self.rfile.read(content_length)
            return json.loads(body_bytes.decode("utf-8"))
        except Exception as e:
            return None

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    # --- ENRUTADOR GET ---
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # Rutas de la API
        if path.startswith("/api/"):
            self.handle_api_get(path, query)
            return

        # Archivos estáticos o subidos
        if path.startswith("/uploads/"):
            rel_path = path[len("/uploads/"):]
            file_path = os.path.join(UPLOADS_DIR, rel_path)
            self.serve_file(file_path)
            return

        # Frontend SPA
        rel_path = path.lstrip("/")
        if not rel_path or rel_path == "":
            rel_path = "index.html"
        file_path = os.path.join(PUBLIC_DIR, rel_path)
        if not os.path.exists(file_path) or os.path.isdir(file_path):
            file_path = os.path.join(PUBLIC_DIR, "index.html")
        self.serve_file(file_path)

    # --- ENRUTADOR POST ---
    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            self.handle_api_post(path)
            return

        self.send_error_json("Ruta no encontrada", 404)

    # --- ENRUTADOR PUT ---
    def do_PUT(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            self.handle_api_put(path)
            return

        self.send_error_json("Ruta no encontrada", 404)

    # --- ENRUTADOR DELETE ---
    def do_DELETE(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/"):
            self.handle_api_delete(path)
            return

        self.send_error_json("Ruta no encontrada", 404)

    def serve_file(self, filepath):
        if not os.path.exists(filepath) or os.path.isdir(filepath):
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            return

        mime_type, _ = mimetypes.guess_type(filepath)
        if not mime_type:
            mime_type = "application/octet-stream"

        try:
            with open(filepath, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", mime_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(str(e).encode())

    # ==========================================
    # CONTROLADORES DE LA API (GET)
    # ==========================================
    def handle_api_get(self, path, query):
        conn = get_connection()
        cursor = conn.cursor()

        try:
            # 1. Configuración & Tasas
            if path == "/api/config":
                cursor.execute("SELECT * FROM configuracion WHERE id = 1")
                row = cursor.fetchone()
                if row:
                    res = dict(row)
                    raw_tema = res.get("tema_config") or res.get("tema")
                    if raw_tema:
                        try:
                            parsed_tema = json.loads(raw_tema) if isinstance(raw_tema, str) else raw_tema
                            res["tema_config"] = parsed_tema
                            res["tema"] = parsed_tema
                        except Exception:
                            res["tema_config"] = raw_tema
                            res["tema"] = raw_tema
                    else:
                        res["tema_config"] = None
                        res["tema"] = None

                    raw_labels = res.get("labels_config") or res.get("labels")
                    if raw_labels:
                        try:
                            parsed_labels = json.loads(raw_labels) if isinstance(raw_labels, str) else raw_labels
                            res["labels_config"] = parsed_labels
                            res["labels"] = parsed_labels
                        except Exception:
                            res["labels_config"] = raw_labels
                            res["labels"] = raw_labels
                    else:
                        res["labels_config"] = None
                        res["labels"] = None

                    self.send_json(res)
                else:
                    self.send_error_json("Configuración no encontrada", 404)

            elif path == "/api/tasas/oficiales":
                ves, cop, fuente, err = obtener_tasas_oficiales()
                self.send_json({
                    "tasa_ves": ves,
                    "tasa_cop": cop,
                    "fuente": fuente,
                    "error": err
                })

            # Respaldo y Descarga de Base de Datos (.db)
            elif path == "/api/database/backup":
                if not os.path.exists(DB_PATH):
                    self.send_error_json("Archivo de base de datos no encontrado", 404)
                    return
                try:
                    with open(DB_PATH, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/x-sqlite3")
                    self.send_header("Content-Disposition", f'attachment; filename="inventario_respaldo_{datetime.now().strftime("%Y%m%d_%H%M%S")}.db"')
                    self.send_header("Content-Length", str(len(content)))
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.end_headers()
                    self.wfile.write(content)
                    return
                except Exception as e:
                    self.send_error_json(f"Error al exportar base de datos: {str(e)}", 500)
                    return

            # Estado de Persistencia y Estadísticas de la Base de Datos (Auditoría Render / Cloud)
            elif path == "/api/database/status":
                cfg_supabase = get_supabase_config()
                is_persistent_disk = (DB_PATH != getattr(database, "DEFAULT_DB_PATH", DB_PATH)) or os.path.exists("/data/inventario.db") or os.path.exists("/var/data/inventario.db")
                is_render = bool(os.environ.get("RENDER") or os.environ.get("RENDER_SERVICE_ID"))
                is_ephemeral = is_render and not is_persistent_disk and not bool(cfg_supabase)

                size_bytes = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
                c_facturas = cursor.execute("SELECT count(*) FROM facturas").fetchone()[0]
                c_productos = cursor.execute("SELECT count(*) FROM productos").fetchone()[0]
                c_clientes = cursor.execute("SELECT count(*) FROM clientes").fetchone()[0]
                c_compras = cursor.execute("SELECT count(*) FROM compras").fetchone()[0]
                c_devoluciones = cursor.execute("SELECT count(*) FROM devoluciones").fetchone()[0]
                c_cxc = cursor.execute("SELECT count(*) FROM cuentas_por_cobrar").fetchone()[0]
                c_cxp = cursor.execute("SELECT count(*) FROM cuentas_por_pagar").fetchone()[0]
                c_movs = cursor.execute("SELECT count(*) FROM inventario_movimientos").fetchone()[0]

                last_sync = getattr(database, "_last_cloud_sync_status", {})

                self.send_json({
                    "modo_persistencia": "persistent_disk" if is_persistent_disk else ("supabase_storage" if cfg_supabase else "local_disk"),
                    "es_efimero": is_ephemeral,
                    "is_render": is_render,
                    "db_path": DB_PATH,
                    "supabase_conectado": bool(cfg_supabase),
                    "supabase_bucket": cfg_supabase["bucket"] if cfg_supabase else None,
                    "supabase_url_masked": (cfg_supabase["url"][:18] + "...") if cfg_supabase else None,
                    "ultimo_sync_estado": last_sync.get("ok"),
                    "ultimo_sync_fecha": last_sync.get("timestamp"),
                    "ultimo_sync_error": last_sync.get("error"),
                    "tamano_bytes": size_bytes,
                    "tamano_formateado": f"{size_bytes / 1024:.1f} KB",
                    "facturas_count": c_facturas,
                    "productos_count": c_productos,
                    "clientes_count": c_clientes,
                    "compras_count": c_compras,
                    "devoluciones_count": c_devoluciones,
                    "cxc_count": c_cxc,
                    "cxp_count": c_cxp,
                    "movimientos_count": c_movs,
                    "tiene_datos_prueba": (c_facturas > 0 or c_compras > 0 or c_devoluciones > 0)
                })
                return

            elif path == "/api/database/test-supabase":
                res = database.test_supabase_connection()
                self.send_json(res)
                return

            # Auditoría Completa y Diagnóstico de Base de Datos
            elif path == "/api/database/audit":
                reporte = auditar_y_migrar_db(conn, cursor)
                cfg_supabase = get_supabase_config()
                reporte["modo_persistencia"] = "supabase_storage" if cfg_supabase else "local_disk"
                reporte["tamano_bytes"] = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
                reporte["tamano_formateado"] = f"{reporte['tamano_bytes'] / 1024:.1f} KB"
                self.send_json(reporte)
                return

            # Conciliación de Inventario (FASE 2A)
            elif path == "/api/inventario/conciliacion":
                resumen = conciliar_inventario(conn, cursor)
                self.send_json(resumen)
                return

            # Historial de Movimientos de Inventario (FASE 2A - Libro Mayor)
            elif path == "/api/inventario/movimientos":
                producto_id = query.get("producto_id", [None])[0]
                sql = """
                    SELECT m.*, p.codigo as producto_codigo, p.nombre as producto_nombre
                    FROM inventario_movimientos m
                    JOIN productos p ON m.producto_id = p.id
                """
                params = []
                if producto_id:
                    sql += " WHERE m.producto_id = ?"
                    params.append(producto_id)
                sql += " ORDER BY m.fecha ASC, m.id ASC"
                cursor.execute(sql, tuple(params))
                movs = [dict(r) for r in cursor.fetchall()]
                self.send_json({"total": len(movs), "movimientos": movs})
                return

            # Listado de Ajustes de Inventario (FASE 2C)
            elif path == "/api/inventario/ajustes":
                tipo_ajuste = query.get("tipo_ajuste", [None])[0]
                sql = """
                    SELECT a.*, 
                           COUNT(d.id) as total_items,
                           COALESCE(SUM(d.cantidad), 0.0) as total_cantidad,
                           COALESCE(SUM(d.costo_total), 0.0) as total_costo
                    FROM inventario_ajustes a
                    LEFT JOIN inventario_ajuste_detalles d ON a.id = d.ajuste_id
                """
                params = []
                if tipo_ajuste:
                    sql += " WHERE a.tipo_ajuste = ?"
                    params.append(tipo_ajuste.upper())
                sql += " GROUP BY a.id ORDER BY a.fecha DESC, a.id DESC"
                cursor.execute(sql, tuple(params))
                ajustes = [dict(r) for r in cursor.fetchall()]
                self.send_json({"total": len(ajustes), "ajustes": ajustes})
                return

            elif path.startswith("/api/inventario/ajustes/"):
                try:
                    ajuste_id = int(path.split("/")[-1])
                except ValueError:
                    self.send_error_json("ID de ajuste inválido", 400)
                    return
                cursor.execute("SELECT * FROM inventario_ajustes WHERE id = ?", (ajuste_id,))
                ajuste = cursor.fetchone()
                if not ajuste:
                    self.send_error_json("Ajuste de inventario no encontrado", 404)
                    return
                ajuste_dict = dict(ajuste)
                cursor.execute("""
                    SELECT d.*, p.codigo as producto_codigo, p.nombre as producto_nombre
                    FROM inventario_ajuste_detalles d
                    JOIN productos p ON d.producto_id = p.id
                    WHERE d.ajuste_id = ?
                    ORDER BY d.id ASC
                """, (ajuste_id,))
                detalles = [dict(r) for r in cursor.fetchall()]
                ajuste_dict["detalles"] = detalles
                self.send_json(ajuste_dict)
                return

            # 2. Resumen del Dashboard
            elif path == "/api/dashboard":
                cursor.execute("SELECT COUNT(*) FROM productos WHERE tipo = 'producto'")
                total_productos = cursor.fetchone()[0]

                cursor.execute("SELECT COUNT(*) FROM productos WHERE tipo = 'servicio'")
                total_servicios = cursor.fetchone()[0]

                cursor.execute("SELECT COUNT(*) FROM productos WHERE tipo = 'producto' AND stock <= stock_minimo")
                alertas_stock = cursor.fetchone()[0]

                cursor.execute("SELECT COUNT(*) FROM clientes")
                total_clientes = cursor.fetchone()[0]

                cursor.execute("SELECT COUNT(*) FROM proveedores")
                total_proveedores = cursor.fetchone()[0]

                cursor.execute("SELECT COUNT(*), COALESCE(SUM(total_usd), 0) FROM facturas WHERE estado != 'anulada'")
                facturas_row = cursor.fetchone()
                total_facturas = facturas_row[0]
                ventas_total_usd = round(facturas_row[1] or 0.0, 2)

                # Total de Devoluciones y Ventas Netas
                cursor.execute("SELECT COUNT(*), COALESCE(SUM(total_usd), 0) FROM devoluciones")
                dev_row = cursor.fetchone()
                total_devoluciones = dev_row[0]
                total_devoluciones_usd = round(dev_row[1] or 0.0, 2)
                ventas_netas_usd = max(0.0, round(ventas_total_usd - total_devoluciones_usd, 2))

                # Ventas del día (brutas y netas restando devoluciones de hoy)
                cursor.execute("SELECT COALESCE(SUM(total_usd), 0) FROM facturas WHERE estado != 'anulada' AND date(fecha) = date('now')")
                ventas_hoy_brutas = round(cursor.fetchone()[0] or 0.0, 2)
                cursor.execute("SELECT COALESCE(SUM(total_usd), 0) FROM devoluciones WHERE date(fecha_emision) = date('now')")
                dev_hoy_usd = round(cursor.fetchone()[0] or 0.0, 2)
                ventas_hoy_netas = max(0.0, round(ventas_hoy_brutas - dev_hoy_usd, 2))

                cursor.execute("SELECT COUNT(*), COALESCE(SUM(total), 0) FROM compras")
                compras_row = cursor.fetchone()
                total_compras = compras_row[0]
                compras_total_usd = compras_row[1]

                # Últimas 5 facturas
                cursor.execute("""
                    SELECT f.*, c.nombre as cliente_nombre 
                    FROM facturas f 
                    JOIN clientes c ON f.cliente_id = c.id 
                    ORDER BY f.id DESC LIMIT 5
                """)
                ultimas_facturas = [dict(r) for r in cursor.fetchall()]

                # Productos con poco stock
                cursor.execute("""
                    SELECT p.*, c.nombre as categoria_nombre 
                    FROM productos p
                    JOIN categorias c ON p.categoria_id = c.id
                    WHERE p.tipo = 'producto' AND p.stock <= p.stock_minimo
                    ORDER BY p.stock ASC LIMIT 5
                """)
                productos_bajo_stock = [dict(r) for r in cursor.fetchall()]

                # Resumen de Cuentas por Cobrar
                cursor.execute("""
                    SELECT 
                        COALESCE(SUM(saldo_pendiente), 0) as total_saldo_usd,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') THEN 1 END) as cuentas_pendientes
                    FROM cuentas_por_cobrar
                """)
                cxc_dash_row = cursor.fetchone()
                cxc_total_usd = round(cxc_dash_row[0] or 0.0, 2)
                cxc_pendientes = cxc_dash_row[1] or 0

                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_dash = cursor.fetchone()
                tasa_ves_dash = cfg_dash[0] if cfg_dash else 45.0
                tasa_cop_dash = cfg_dash[1] if cfg_dash else 4100.0

                cxc_total_ves = round(cxc_total_usd * tasa_ves_dash, 2)
                cxc_total_cop = round(cxc_total_usd * tasa_cop_dash, 2)

                # Resumen de Cuentas por Pagar (CXP)
                cursor.execute("""
                    SELECT 
                        COALESCE(SUM(saldo_pendiente), 0) as total_saldo_usd,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') THEN 1 END) as cuentas_pendientes
                    FROM cuentas_por_pagar
                """)
                cxp_dash_row = cursor.fetchone()
                cxp_total_usd = round(cxp_dash_row[0] or 0.0, 2)
                cxp_pendientes = cxp_dash_row[1] or 0
                cxp_total_ves = round(cxp_total_usd * tasa_ves_dash, 2)
                cxp_total_cop = round(cxp_total_usd * tasa_cop_dash, 2)

                # Top 5 productos más vendidos
                cursor.execute("""
                    SELECT 
                        fd.producto_id,
                        fd.nombre_producto,
                        COALESCE(SUM(fd.cantidad), 0) as total_vendido,
                        ROUND(COALESCE(SUM(fd.total), 0), 2) as total_usd,
                        p.stock as stock_actual,
                        p.tipo
                    FROM factura_detalles fd
                    JOIN facturas f ON fd.factura_id = f.id
                    LEFT JOIN productos p ON fd.producto_id = p.id
                    GROUP BY fd.producto_id, fd.nombre_producto
                    ORDER BY total_vendido DESC
                    LIMIT 5
                """)
                top_productos = [dict(r) for r in cursor.fetchall()]

                # Top 5 mejores clientes
                cursor.execute("""
                    SELECT 
                        c.id,
                        c.nombre,
                        c.cedula,
                        c.telefono,
                        COUNT(f.id) as total_facturas,
                        ROUND(COALESCE(SUM(f.total_usd), 0), 2) as total_comprado_usd
                    FROM facturas f
                    JOIN clientes c ON f.cliente_id = c.id
                    GROUP BY c.id, c.nombre, c.cedula, c.telefono
                    ORDER BY total_comprado_usd DESC
                    LIMIT 5
                """)
                top_clientes = [dict(r) for r in cursor.fetchall()]

                self.send_json({
                    "total_productos": total_productos,
                    "total_servicios": total_servicios,
                    "alertas_stock": alertas_stock,
                    "total_clientes": total_clientes,
                    "total_proveedores": total_proveedores,
                    "total_facturas": total_facturas,
                    "ventas_total_usd": ventas_total_usd,
                    "total_devoluciones": total_devoluciones,
                    "total_devoluciones_usd": total_devoluciones_usd,
                    "ventas_netas_usd": ventas_netas_usd,
                    "ventas_hoy_brutas": ventas_hoy_brutas,
                    "ventas_hoy_netas": ventas_hoy_netas,
                    "dev_hoy_usd": dev_hoy_usd,
                    "total_compras": total_compras,
                    "compras_total_usd": compras_total_usd,
                    "cxc_total_usd": cxc_total_usd,
                    "cxc_pendientes": cxc_pendientes,
                    "cxc_total_ves": cxc_total_ves,
                    "cxc_total_cop": cxc_total_cop,
                    "cxp_total_usd": cxp_total_usd,
                    "cxp_pendientes": cxp_pendientes,
                    "cxp_total_ves": cxp_total_ves,
                    "cxp_total_cop": cxp_total_cop,
                    "ultimas_facturas": ultimas_facturas,
                    "productos_bajo_stock": productos_bajo_stock,
                    "top_productos": top_productos,
                    "top_clientes": top_clientes
                })

            # 3. Categorías
            elif path == "/api/categorias":
                tipo_filter = query.get("tipo", [None])[0]
                if tipo_filter:
                    cursor.execute("SELECT * FROM categorias WHERE tipo = ? ORDER BY nombre ASC", (tipo_filter,))
                else:
                    cursor.execute("SELECT * FROM categorias ORDER BY nombre ASC")
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            # 4. Productos y Servicios
            elif path == "/api/productos":
                tipo = query.get("tipo", [None])[0]
                categoria_id = query.get("categoria_id", [None])[0]
                search = query.get("q", [None])[0]

                sql = """
                    SELECT p.*, c.nombre as categoria_nombre, c.tipo as categoria_tipo 
                    FROM productos p 
                    JOIN categorias c ON p.categoria_id = c.id 
                    WHERE p.activo = 1
                """
                params = []

                if tipo:
                    sql += " AND p.tipo = ?"
                    params.append(tipo)
                if categoria_id:
                    sql += " AND p.categoria_id = ?"
                    params.append(categoria_id)
                if search:
                    sql += " AND (p.nombre LIKE ? OR p.codigo LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")

                sql += " ORDER BY p.id DESC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/productos/"):
                item_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT p.*, c.nombre as categoria_nombre 
                    FROM productos p 
                    JOIN categorias c ON p.categoria_id = c.id 
                    WHERE p.id = ?
                """, (item_id,))
                row = cursor.fetchone()
                if row:
                    self.send_json(dict(row))
                else:
                    self.send_error_json("Producto no encontrado", 404)

            # 5. Clientes
            elif path == "/api/clientes":
                search = query.get("q", [None])[0]
                if search:
                    cursor.execute("SELECT * FROM clientes WHERE nombre LIKE ? OR cedula LIKE ? ORDER BY nombre ASC", (f"%{search}%", f"%{search}%"))
                else:
                    cursor.execute("SELECT * FROM clientes ORDER BY nombre ASC")
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/clientes/"):
                c_id = path.split("/")[-1]
                cursor.execute("SELECT * FROM clientes WHERE id = ?", (c_id,))
                row = cursor.fetchone()
                if row:
                    self.send_json(dict(row))
                else:
                    self.send_error_json("Cliente no encontrado", 404)

            # 6. Proveedores
            elif path == "/api/proveedores":
                search = query.get("q", [None])[0]
                if search:
                    cursor.execute("SELECT * FROM proveedores WHERE nombre LIKE ? OR cedula LIKE ? ORDER BY nombre ASC", (f"%{search}%", f"%{search}%"))
                else:
                    cursor.execute("SELECT * FROM proveedores ORDER BY nombre ASC")
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/proveedores/"):
                p_id = path.split("/")[-1]
                cursor.execute("SELECT * FROM proveedores WHERE id = ?", (p_id,))
                row = cursor.fetchone()
                if row:
                    self.send_json(dict(row))
                else:
                    self.send_error_json("Proveedor no encontrado", 404)

            # 7. Facturas (Ventas) - Defensivo con LEFT JOIN
            elif path == "/api/facturas":
                cursor.execute("""
                    SELECT f.*, 
                           COALESCE(c.nombre, 'Cliente General') as cliente_nombre, 
                           COALESCE(c.cedula, '-') as cliente_cedula, 
                           COALESCE(c.telefono, '-') as cliente_telefono 
                    FROM facturas f 
                    LEFT JOIN clientes c ON f.cliente_id = c.id 
                    ORDER BY f.id DESC
                """)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/facturas/"):
                f_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT f.*, c.nombre as cliente_nombre, c.cedula as cliente_cedula, 
                           c.telefono as cliente_telefono, c.correo as cliente_correo, c.direccion as cliente_direccion
                    FROM facturas f 
                    JOIN clientes c ON f.cliente_id = c.id 
                    WHERE f.id = ?
                """, (f_id,))
                factura = cursor.fetchone()
                if not factura:
                    self.send_error_json("Factura no encontrada", 404)
                    return

                res = dict(factura)
                # Obtener detalles con código e imagen del producto
                cursor.execute("""
                    SELECT fd.*, fd.nombre_producto as nombre, p.codigo, p.imagen, p.costo
                    FROM factura_detalles fd
                    LEFT JOIN productos p ON fd.producto_id = p.id
                    WHERE fd.factura_id = ?
                """, (f_id,))
                detalles = []
                for d in cursor.fetchall():
                    item_dict = dict(d)
                    if "nombre" not in item_dict or not item_dict["nombre"]:
                        item_dict["nombre"] = item_dict.get("nombre_producto", "")
                    detalles.append(item_dict)
                res["detalles"] = detalles
                res["items"] = detalles

                # Obtener pagos
                cursor.execute("SELECT * FROM factura_pagos WHERE factura_id = ?", (f_id,))
                res["pagos"] = [dict(p) for p in cursor.fetchall()]

                self.send_json(res)

            # 8. Compras
            elif path == "/api/compras":
                cursor.execute("""
                    SELECT c.*, p.nombre as proveedor_nombre, p.cedula as proveedor_cedula 
                    FROM compras c 
                    JOIN proveedores p ON c.proveedor_id = p.id 
                    ORDER BY c.id DESC
                """)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/compras/") and path.endswith("/items-para-devolucion"):
                parts = path.split("/")
                compra_id = int(parts[3])
                cursor.execute("""
                    SELECT c.*, p.nombre as proveedor_nombre, p.cedula as proveedor_rif, p.telefono as proveedor_telefono
                    FROM compras c
                    JOIN proveedores p ON c.proveedor_id = p.id
                    WHERE c.id = ?
                """, (compra_id,))
                compra_row = cursor.fetchone()
                if not compra_row:
                    self.send_error_json("Compra no encontrada", 404)
                    return
                compra_dict = dict(compra_row)

                # CXP vinculada
                cursor.execute("SELECT * FROM cuentas_por_pagar WHERE compra_id = ? AND estado != 'anulada'", (compra_id,))
                cxp_row = cursor.fetchone()
                compra_dict["cxp"] = dict(cxp_row) if cxp_row else None

                # Detalles con disponibilidad
                cursor.execute("""
                    SELECT cd.*, p.codigo as prod_codigo, p.stock as stock_actual, p.nombre as prod_nombre
                    FROM compra_detalles cd
                    JOIN productos p ON cd.producto_id = p.id
                    WHERE cd.compra_id = ?
                """, (compra_id,))
                items = [dict(r) for r in cursor.fetchall()]

                for it in items:
                    cursor.execute("""
                        SELECT COALESCE(SUM(dcd.cantidad), 0)
                        FROM devolucion_compra_detalles dcd
                        JOIN devoluciones_compras dc ON dcd.devolucion_compra_id = dc.id
                        WHERE dcd.compra_detalle_id = ? AND dc.estado != 'anulada'
                    """, (it["id"],))
                    prev_dev = float(cursor.fetchone()[0] or 0.0)
                    it["cantidad_comprada"] = float(it["cantidad"])
                    it["cantidad_devuelta_previa"] = prev_dev
                    it["cantidad_disponible"] = max(0.0, it["cantidad_comprada"] - prev_dev)
                    it["stock_almacen"] = float(it.get("stock_actual") or 0.0)
                    it["max_permitido"] = min(it["cantidad_disponible"], it["stock_almacen"])

                compra_dict["items"] = items
                self.send_json(compra_dict)

            elif path.startswith("/api/compras/"):
                c_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT c.*, p.nombre as proveedor_nombre, p.cedula as proveedor_cedula, 
                           p.telefono as proveedor_telefono, p.correo as proveedor_correo
                    FROM compras c 
                    JOIN proveedores p ON c.proveedor_id = p.id 
                    WHERE c.id = ?
                """, (c_id,))
                compra = cursor.fetchone()
                if not compra:
                    self.send_error_json("Compra no encontrada", 404)
                    return

                res = dict(compra)
                cursor.execute("SELECT * FROM compra_detalles WHERE compra_id = ?", (c_id,))
                res["detalles"] = [dict(d) for d in cursor.fetchall()]
                self.send_json(res)

            # 9. Cuentas por Cobrar (CXC)
            elif path == "/api/cxc/resumen":
                cursor.execute("""
                    SELECT 
                        COALESCE(SUM(saldo_pendiente), 0) as total_saldo_usd,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') THEN 1 END) as pendientes_count,
                        COUNT(CASE WHEN estado = 'pagada' THEN 1 END) as pagadas_count,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') AND date(fecha_vencimiento) < date('now') THEN 1 END) as vencidas_count
                    FROM cuentas_por_cobrar
                    WHERE (estado IS NULL OR estado != 'anulada')
                """)
                res_row = dict(cursor.fetchone())

                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg = dict(cursor.fetchone())
                total_saldo_usd = float(res_row["total_saldo_usd"])
                res_row["total_saldo_ves"] = round(total_saldo_usd * cfg["tasa_ves"], 2)
                res_row["total_saldo_cop"] = round(total_saldo_usd * cfg["tasa_cop"], 2)
                self.send_json(res_row)

            elif path == "/api/cxc/consolidado":
                search = query.get("q", [None])[0]
                sql = """
                    SELECT c.id as cliente_id, c.nombre as cliente_nombre, c.cedula as cliente_cedula, c.telefono as cliente_telefono,
                           COUNT(CASE WHEN cxc.saldo_pendiente > 0.001 THEN 1 END) as facturas_pendientes_count,
                           COUNT(cxc.id) as total_facturas_count,
                           COALESCE(SUM(cxc.monto_total), 0.0) as total_facturado_usd,
                           COALESCE(SUM(cxc.monto_pagado), 0.0) as total_cobrado_usd,
                           COALESCE(SUM(cxc.monto_pagado), 0.0) as total_pagado_usd,
                           COALESCE(SUM(cxc.saldo_pendiente), 0.0) as saldo_pendiente_total_usd,
                           COALESCE(SUM(cxc.saldo_pendiente), 0.0) as saldo_pendiente_usd,
                           SUM(CASE WHEN cxc.saldo_pendiente > 0.001 AND date(cxc.fecha_vencimiento) < date('now') THEN 1 ELSE 0 END) as facturas_vencidas_count,
                           cfg.tasa_ves, cfg.tasa_cop,
                           ROUND(COALESCE(SUM(cxc.saldo_pendiente), 0.0) * cfg.tasa_ves, 2) as saldo_pendiente_total_ves,
                           ROUND(COALESCE(SUM(cxc.saldo_pendiente), 0.0) * cfg.tasa_ves, 2) as saldo_pendiente_ves,
                           ROUND(COALESCE(SUM(cxc.saldo_pendiente), 0.0) * cfg.tasa_cop, 2) as saldo_pendiente_total_cop
                    FROM clientes c
                    JOIN cuentas_por_cobrar cxc ON cxc.cliente_id = c.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE (cxc.estado IS NULL OR cxc.estado != 'anulada')
                """
                params = []
                if search:
                    sql += " AND (c.nombre LIKE ? OR c.cedula LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")
                sql += " GROUP BY c.id HAVING total_facturas_count > 0 ORDER BY saldo_pendiente_total_usd DESC, c.nombre ASC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path == "/api/cxc":
                estado = query.get("estado", [None])[0]
                cliente_id = query.get("cliente_id", [None])[0]
                search = query.get("q", [None])[0]

                sql = """
                    SELECT cxc.*, f.numero_factura, f.subtotal, f.iva_total, f.total_usd,
                           c.nombre as cliente_nombre, c.cedula as cliente_cedula, c.telefono as cliente_telefono,
                           cfg.tasa_ves, cfg.tasa_cop,
                           (SELECT COUNT(*) FROM abonos_cxc ab WHERE ab.cxc_id = cxc.id) as total_abonos_count,
                           (SELECT COUNT(*) FROM abonos_cxc ab WHERE ab.cxc_id = cxc.id AND (ab.estado IS NULL OR ab.estado = 'activo')) as abonos_activos_count
                    FROM cuentas_por_cobrar cxc
                    JOIN facturas f ON cxc.factura_id = f.id
                    JOIN clientes c ON cxc.cliente_id = c.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE 1=1
                """
                params = []
                if estado and estado != "todos":
                    if estado == "vencida":
                        sql += " AND cxc.estado IN ('pendiente', 'parcial') AND date(cxc.fecha_vencimiento) < date('now')"
                    else:
                        sql += " AND cxc.estado = ?"
                        params.append(estado)
                if cliente_id:
                    sql += " AND cxc.cliente_id = ?"
                    params.append(cliente_id)
                if search:
                    sql += " AND (c.nombre LIKE ? OR c.cedula LIKE ? OR f.numero_factura LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")

                sql += " ORDER BY cxc.id DESC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/cxc/estado-cuenta/") or path == "/api/cxc/movimientos":
                if path.startswith("/api/cxc/estado-cuenta/"):
                    cli_id = path.split("/")[-1]
                else:
                    cli_id = query.get("cliente_id", [None])[0]
                if not cli_id:
                    self.send_error_json("Se requiere cliente_id", 400)
                    return
                tipo_f = query.get("tipo", [None])[0]
                q_f = query.get("q", [None])[0]
                f_desde = query.get("desde", [None])[0]
                f_hasta = query.get("hasta", [None])[0]
                orden_f = query.get("orden", ["asc"])[0]
                data_ec = obtener_estado_cuenta_cliente_cxc(
                    cursor, cli_id, tipo_filtro=tipo_f, q=q_f,
                    fecha_desde=f_desde, fecha_hasta=f_hasta, orden=orden_f
                )
                self.send_json(data_ec)

            elif path.startswith("/api/cxc/"):
                cxc_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT cxc.*, f.numero_factura, f.subtotal, f.iva_total, f.total_usd,
                           c.nombre as cliente_nombre, c.cedula as cliente_cedula, c.telefono as cliente_telefono,
                           c.correo as cliente_correo, c.direccion as cliente_direccion,
                           cfg.tasa_ves, cfg.tasa_cop
                    FROM cuentas_por_cobrar cxc
                    JOIN facturas f ON cxc.factura_id = f.id
                    JOIN clientes c ON cxc.cliente_id = c.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE cxc.id = ?
                """, (cxc_id,))
                cxc = cursor.fetchone()
                if not cxc:
                    self.send_error_json("Cuenta por cobrar no encontrada", 404)
                    return
                res = dict(cxc)

                # Obtener abonos posteriores
                cursor.execute("SELECT * FROM abonos_cxc WHERE cxc_id = ? ORDER BY id DESC", (cxc_id,))
                abonos = []
                for ab in cursor.fetchall():
                    ab_dict = dict(ab)
                    cursor.execute("SELECT * FROM abono_cxc_pagos WHERE abono_id = ?", (ab_dict["id"],))
                    ab_dict["pagos"] = [dict(p) for p in cursor.fetchall()]
                    abonos.append(ab_dict)

                # Si hubo anticipo / abono inicial en la factura y aún no está en abonos_cxc, incluirlo como anulable
                ya_tiene_inicial = any("inicial" in (a.get("notas") or "").lower() for a in abonos)
                if cxc["factura_id"] and float(cxc["monto_pagado"] or 0) > 0 and not ya_tiene_inicial:
                    cursor.execute("SELECT * FROM factura_pagos WHERE factura_id = ?", (cxc["factura_id"],))
                    f_pagos = [dict(p) for p in cursor.fetchall()]
                    if f_pagos:
                        monto_ini = round(sum(float(p.get("equivalente_usd") or 0) for p in f_pagos), 2)
                        if monto_ini > 0:
                            abonos.append({
                                "id": 0,
                                "cxc_id": int(cxc_id),
                                "monto_usd": monto_ini,
                                "fecha": cxc["fecha_emision"],
                                "notas": "Anticipo / Pago inicial al momento de facturar",
                                "estado": "activo",
                                "pagos": f_pagos,
                                "es_inicial": True
                            })

                res["abonos"] = abonos
                self.send_json(res)

            # 9.1 Cuentas por Pagar (CXP) - Resumen
            elif path == "/api/cxp/resumen":
                cursor.execute("""
                    SELECT 
                        COALESCE(SUM(saldo_pendiente), 0) as total_saldo_usd,
                        COALESCE(SUM(monto_total), 0) as total_facturado_usd,
                        COALESCE(SUM(monto_pagado), 0) as total_pagado_usd,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') THEN 1 END) as pendientes_count,
                        COUNT(CASE WHEN estado = 'pagada' THEN 1 END) as pagadas_count,
                        COUNT(CASE WHEN estado IN ('pendiente', 'parcial') AND date(fecha_vencimiento) < date('now') THEN 1 END) as vencidas_count
                    FROM cuentas_por_pagar
                    WHERE (estado IS NULL OR estado != 'anulada')
                """)
                res_row = dict(cursor.fetchone())

                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg = dict(cursor.fetchone())
                total_saldo_usd = float(res_row["total_saldo_usd"])
                res_row["total_saldo_ves"] = round(total_saldo_usd * cfg["tasa_ves"], 2)
                res_row["total_saldo_cop"] = round(total_saldo_usd * cfg["tasa_cop"], 2)
                self.send_json(res_row)

            # 9.2 Cuentas por Pagar (CXP) - Listado con filtros
            elif path == "/api/cxp/consolidado":
                search = query.get("q", [None])[0]
                sql = """
                    SELECT p.id as proveedor_id, p.nombre as proveedor_nombre, p.cedula as proveedor_cedula, p.telefono as proveedor_telefono,
                           COUNT(CASE WHEN cxp.saldo_pendiente > 0.001 THEN 1 END) as cuentas_pendientes_count,
                           COUNT(cxp.id) as total_cuentas_count,
                           COALESCE(SUM(cxp.monto_total), 0.0) as total_deuda_usd,
                           COALESCE(SUM(cxp.monto_total), 0.0) as total_facturado_usd,
                           COALESCE(SUM(cxp.monto_pagado), 0.0) as total_pagado_usd,
                           COALESCE(SUM(cxp.saldo_pendiente), 0.0) as saldo_pendiente_total_usd,
                           COALESCE(SUM(cxp.saldo_pendiente), 0.0) as saldo_pendiente_usd,
                           SUM(CASE WHEN cxp.saldo_pendiente > 0.001 AND date(cxp.fecha_vencimiento) < date('now') THEN 1 ELSE 0 END) as cuentas_vencidas_count,
                           cfg.tasa_ves, cfg.tasa_cop,
                           ROUND(COALESCE(SUM(cxp.saldo_pendiente), 0.0) * cfg.tasa_ves, 2) as saldo_pendiente_total_ves,
                           ROUND(COALESCE(SUM(cxp.saldo_pendiente), 0.0) * cfg.tasa_ves, 2) as saldo_pendiente_ves,
                           ROUND(COALESCE(SUM(cxp.saldo_pendiente), 0.0) * cfg.tasa_cop, 2) as saldo_pendiente_total_cop
                    FROM proveedores p
                    JOIN cuentas_por_pagar cxp ON cxp.proveedor_id = p.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE (cxp.estado IS NULL OR cxp.estado != 'anulada')
                """
                params = []
                if search:
                    sql += " AND (p.nombre LIKE ? OR p.cedula LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")
                sql += " GROUP BY p.id HAVING total_cuentas_count > 0 ORDER BY saldo_pendiente_total_usd DESC, p.nombre ASC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path == "/api/notas-ajuste":
                modulo = query.get("modulo", [None])[0]
                tercero_id = query.get("tercero_id", [None])[0]
                cuenta_id = query.get("cuenta_id", [None])[0]
                sql = "SELECT * FROM notas_ajuste_comercial WHERE 1=1"
                params = []
                if modulo:
                    sql += " AND modulo = ?"
                    params.append(modulo)
                if tercero_id:
                    sql += " AND tercero_id = ?"
                    params.append(tercero_id)
                if cuenta_id:
                    sql += " AND cuenta_id = ?"
                    params.append(cuenta_id)
                sql += " ORDER BY id DESC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path == "/api/cxp":
                estado = query.get("estado", [None])[0]
                proveedor_id = query.get("proveedor_id", [None])[0]
                search = query.get("q", [None])[0]

                sql = """
                    SELECT cxp.*, 
                           comp.numero_control as compra_numero_control,
                           p.nombre as proveedor_nombre, p.cedula as proveedor_cedula, p.telefono as proveedor_telefono,
                           cfg.tasa_ves, cfg.tasa_cop,
                           ROUND(cxp.saldo_pendiente * cfg.tasa_ves, 2) as saldo_ves,
                           ROUND(cxp.saldo_pendiente * cfg.tasa_cop, 2) as saldo_cop,
                           CAST((julianday('now') - julianday(cxp.fecha_vencimiento)) AS INTEGER) as dias_vencido,
                           (SELECT COUNT(*) FROM abonos_cxp ab WHERE ab.cxp_id = cxp.id) as total_abonos_count,
                           (SELECT COUNT(*) FROM abonos_cxp ab WHERE ab.cxp_id = cxp.id AND (ab.estado IS NULL OR ab.estado = 'activo')) as abonos_activos_count
                    FROM cuentas_por_pagar cxp
                    LEFT JOIN compras comp ON cxp.compra_id = comp.id
                    JOIN proveedores p ON cxp.proveedor_id = p.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE 1=1
                """
                params = []
                if estado and estado != "todos":
                    if estado == "vencida":
                        sql += " AND cxp.estado IN ('pendiente', 'parcial') AND date(cxp.fecha_vencimiento) < date('now')"
                    else:
                        sql += " AND cxp.estado = ?"
                        params.append(estado)
                if proveedor_id:
                    sql += " AND cxp.proveedor_id = ?"
                    params.append(proveedor_id)
                if search:
                    sql += " AND (p.nombre LIKE ? OR p.cedula LIKE ? OR cxp.numero_factura LIKE ? OR cxp.descripcion_concepto LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")

                sql += " ORDER BY cxp.id DESC"
                cursor.execute(sql, params)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/cxp/estado-cuenta/") or path == "/api/cxp/movimientos":
                if path.startswith("/api/cxp/estado-cuenta/"):
                    prov_id = path.split("/")[-1]
                else:
                    prov_id = query.get("proveedor_id", [None])[0]
                if not prov_id:
                    self.send_error_json("Se requiere proveedor_id", 400)
                    return
                tipo_f = query.get("tipo", [None])[0]
                q_f = query.get("q", [None])[0]
                f_desde = query.get("desde", [None])[0]
                f_hasta = query.get("hasta", [None])[0]
                orden_f = query.get("orden", ["asc"])[0]
                data_ec = obtener_estado_cuenta_proveedor_cxp(
                    cursor, prov_id, tipo_filtro=tipo_f, q=q_f,
                    fecha_desde=f_desde, fecha_hasta=f_hasta, orden=orden_f
                )
                self.send_json(data_ec)

            # 9.3 Cuentas por Pagar (CXP) - Detalle y Abonos
            elif path.startswith("/api/cxp/"):
                cxp_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT cxp.*, 
                           comp.numero_control as compra_numero_control,
                           p.nombre as proveedor_nombre, p.cedula as proveedor_cedula, p.telefono as proveedor_telefono,
                           p.correo as proveedor_correo, p.direccion as proveedor_direccion,
                           cfg.tasa_ves, cfg.tasa_cop,
                           ROUND(cxp.saldo_pendiente * cfg.tasa_ves, 2) as saldo_ves,
                           ROUND(cxp.saldo_pendiente * cfg.tasa_cop, 2) as saldo_cop,
                           CAST((julianday('now') - julianday(cxp.fecha_vencimiento)) AS INTEGER) as dias_vencido
                    FROM cuentas_por_pagar cxp
                    LEFT JOIN compras comp ON cxp.compra_id = comp.id
                    JOIN proveedores p ON cxp.proveedor_id = p.id
                    CROSS JOIN configuracion cfg ON cfg.id = 1
                    WHERE cxp.id = ?
                """, (cxp_id,))
                cxp = cursor.fetchone()
                if not cxp:
                    self.send_error_json("Cuenta por pagar no encontrada", 404)
                    return
                res = dict(cxp)

                # Obtener abonos posteriores
                cursor.execute("SELECT * FROM abonos_cxp WHERE cxp_id = ? ORDER BY id DESC", (cxp_id,))
                abonos = []
                for ab in cursor.fetchall():
                    ab_dict = dict(ab)
                    cursor.execute("SELECT * FROM abono_cxp_pagos WHERE abono_id = ?", (ab_dict["id"],))
                    ab_dict["pagos"] = [dict(p) for p in cursor.fetchall()]
                    abonos.append(ab_dict)

                # Si hubo anticipo / abono inicial en la compra y aún no está en abonos_cxp, incluirlo como anulable
                ya_tiene_inicial = any("inicial" in (a.get("notas") or "").lower() for a in abonos)
                if cxp["compra_id"] and float(cxp["monto_pagado"] or 0) > 0 and not ya_tiene_inicial:
                    cursor.execute("SELECT * FROM compra_pagos WHERE compra_id = ?", (cxp["compra_id"],))
                    c_pagos = [dict(p) for p in cursor.fetchall()]
                    if c_pagos:
                        monto_ini = round(sum(float(p.get("equivalente_usd") or 0) for p in c_pagos), 2)
                        if monto_ini > 0:
                            abonos.append({
                                "id": 0,
                                "cxp_id": int(cxp_id),
                                "monto_usd": monto_ini,
                                "fecha": cxp["fecha_emision"],
                                "notas": "Anticipo / Pago inicial en compra",
                                "estado": "activo",
                                "pagos": c_pagos,
                                "es_inicial": True
                            })

                res["abonos"] = abonos
                self.send_json(res)

            # 10. Devoluciones

            # DEVOLUCIONES DE COMPRAS (PROVEEDORES)
            elif path == "/api/devoluciones-compras":
                cursor.execute("""
                    SELECT dc.*, p.nombre as proveedor_nombre, p.cedula as proveedor_rif, p.telefono as proveedor_telefono
                    FROM devoluciones_compras dc
                    JOIN proveedores p ON dc.proveedor_id = p.id
                    ORDER BY dc.id DESC
                """)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/devoluciones-compras/") and not path.endswith("/anular"):
                parts = path.split("/")
                dev_id = int(parts[3])
                cursor.execute("""
                    SELECT dc.*, p.nombre as proveedor_nombre, p.cedula as proveedor_rif, p.telefono as proveedor_telefono,
                           p.direccion as proveedor_direccion
                    FROM devoluciones_compras dc
                    JOIN proveedores p ON dc.proveedor_id = p.id
                    WHERE dc.id = ?
                """, (dev_id,))
                dev = cursor.fetchone()
                if not dev:
                    self.send_error_json("Devolución de compra no encontrada", 404)
                    return
                dev_dict = dict(dev)
                cursor.execute("""
                    SELECT * FROM devolucion_compra_detalles WHERE devolucion_compra_id = ?
                """, (dev_id,))
                dev_dict["detalles"] = [dict(r) for r in cursor.fetchall()]
                self.send_json(dev_dict)

            
            elif path == "/api/devoluciones":
                cursor.execute("""
                    SELECT d.*, c.nombre as cliente_nombre, c.cedula as cliente_cedula, c.telefono as cliente_telefono
                    FROM devoluciones d
                    JOIN clientes c ON d.cliente_id = c.id
                    ORDER BY d.id DESC
                """)
                rows = [dict(r) for r in cursor.fetchall()]
                self.send_json(rows)

            elif path.startswith("/api/devoluciones/"):
                dev_id = path.split("/")[-1]
                cursor.execute("""
                    SELECT d.*, c.nombre as cliente_nombre, c.cedula as cliente_cedula,
                           c.telefono as cliente_telefono, c.correo as cliente_correo, c.direccion as cliente_direccion
                    FROM devoluciones d
                    JOIN clientes c ON d.cliente_id = c.id
                    WHERE d.id = ?
                """, (dev_id,))
                dev = cursor.fetchone()
                if not dev:
                    self.send_error_json("Devolución no encontrada", 404)
                    return

                res = dict(dev)
                cursor.execute("SELECT * FROM devolucion_detalles WHERE devolucion_id = ?", (dev_id,))
                detalles = []
                for d in cursor.fetchall():
                    item_dict = dict(d)
                    if "nombre_producto" in item_dict and "nombre" not in item_dict:
                        item_dict["nombre"] = item_dict["nombre_producto"]
                    detalles.append(item_dict)
                res["detalles"] = detalles
                res["items"] = detalles

                cursor.execute("SELECT * FROM devolucion_pagos WHERE devolucion_id = ?", (dev_id,))
                res["pagos"] = [dict(p) for p in cursor.fetchall()]

                self.send_json(res)

            # ==========================================
            # REPORTES DEL SISTEMA
            # ==========================================
            # 10. Reporte de Inventario & Valoración
            elif path == "/api/reportes/inventario":
                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                t_ves = cfg_row[0] if cfg_row else 45.0
                t_cop = cfg_row[1] if cfg_row else 4100.0

                cursor.execute("""
                    SELECT 
                        p.id,
                        p.codigo,
                        p.nombre,
                        p.tipo,
                        p.impuesto_tipo,
                        c.nombre as categoria_nombre,
                        p.costo,
                        p.stock,
                        ROUND(CASE WHEN p.tipo = 'producto' THEN p.costo * p.stock ELSE 0 END, 2) as costo_total_stock,
                        p.precio_base,
                        p.precio_total,
                        ROUND(CASE WHEN p.tipo = 'producto' THEN p.precio_total * p.stock ELSE 0 END, 2) as valor_venta_stock
                    FROM productos p
                    JOIN categorias c ON p.categoria_id = c.id
                    WHERE p.activo = 1
                    ORDER BY p.tipo ASC, costo_total_stock DESC
                """)
                items = [dict(r) for r in cursor.fetchall()]

                total_costo_usd = round(sum(i["costo_total_stock"] for i in items if i["tipo"] == "producto"), 2)
                total_venta_usd = round(sum(i["valor_venta_stock"] for i in items if i["tipo"] == "producto"), 2)
                total_unidades = sum(i["stock"] for i in items if i["tipo"] == "producto")
                ganancia_estimada_usd = round(total_venta_usd - total_costo_usd, 2)

                self.send_json({
                    "items": items,
                    "resumen": {
                        "total_costo_inventario_usd": total_costo_usd,
                        "total_costo_inventario_ves": round(total_costo_usd * t_ves, 2),
                        "total_costo_inventario_cop": round(total_costo_usd * t_cop, 2),
                        "total_venta_estimada_usd": total_venta_usd,
                        "ganancia_estimada_usd": ganancia_estimada_usd,
                        "total_unidades_stock": total_unidades,
                        "total_items": len(items)
                    }
                })

            # 11. Reporte de Ventas Diarias con Desglose de Monedas
            elif path == "/api/reportes/ventas-diarias":
                fecha = query.get("fecha", [datetime.now().strftime("%Y-%m-%d")])[0]

                # Facturas emitidas en el día
                cursor.execute("""
                    SELECT f.*, c.nombre as cliente_nombre, c.cedula as cliente_cedula
                    FROM facturas f
                    JOIN clientes c ON f.cliente_id = c.id
                    WHERE date(f.fecha) = date(?)
                    ORDER BY f.id DESC
                """, (fecha,))
                facturas_dia = [dict(r) for r in cursor.fetchall()]

                total_ventas_usd = round(sum(f["total_usd"] for f in facturas_dia), 2)
                total_subtotal_usd = round(sum(f["subtotal"] for f in facturas_dia), 2)
                total_iva_usd = round(sum(f["iva_total"] for f in facturas_dia), 2)

                # Pagos en facturas del día (excluyendo facturas anuladas)
                cursor.execute("""
                    SELECT fp.moneda, fp.metodo, 
                           SUM(fp.monto_moneda) as total_moneda, 
                           SUM(fp.equivalente_usd) as total_usd,
                           COUNT(*) as transacciones
                    FROM factura_pagos fp
                    JOIN facturas f ON fp.factura_id = f.id
                    WHERE date(f.fecha) = date(?) AND f.estado != 'anulada'
                    GROUP BY fp.moneda, fp.metodo
                """, (fecha,))
                pagos_facturas = [dict(r) for r in cursor.fetchall()]

                # Abonos posteriores de crédito cobrados en el día (evitando duplicar anticipos iniciales si existieran registros históricos)
                cursor.execute("""
                    SELECT ap.moneda, ap.metodo,
                           SUM(ap.monto_moneda) as total_moneda,
                           SUM(ap.equivalente_usd) as total_usd,
                           COUNT(*) as transacciones
                    FROM abono_cxc_pagos ap
                    JOIN abonos_cxc ab ON ap.abono_id = ab.id
                    WHERE date(ab.fecha) = date(?)
                      AND (ab.notas IS NULL OR ab.notas NOT LIKE 'Abono inicial%')
                    GROUP BY ap.moneda, ap.metodo
                """, (fecha,))
                pagos_abonos = [dict(r) for r in cursor.fetchall()]

                # Consolidación estructurada por moneda y método
                desglose_por_moneda = {
                    "USD": {"total_moneda": 0.0, "total_usd": 0.0, "metodos": {}},
                    "VES": {"total_moneda": 0.0, "total_usd": 0.0, "metodos": {}},
                    "COP": {"total_moneda": 0.0, "total_usd": 0.0, "metodos": {}}
                }

                total_cobrado_usd = 0.0

                for p in (pagos_facturas + pagos_abonos):
                    mon = p["moneda"].upper()
                    met = p["metodo"]
                    m_moneda = float(p["total_moneda"] or 0)
                    m_usd = float(p["total_usd"] or 0)
                    total_cobrado_usd += m_usd

                    if mon not in desglose_por_moneda:
                        desglose_por_moneda[mon] = {"total_moneda": 0.0, "total_usd": 0.0, "metodos": {}}
                    
                    desglose_por_moneda[mon]["total_moneda"] = round(desglose_por_moneda[mon]["total_moneda"] + m_moneda, 2)
                    desglose_por_moneda[mon]["total_usd"] = round(desglose_por_moneda[mon]["total_usd"] + m_usd, 2)
                    
                    if met not in desglose_por_moneda[mon]["metodos"]:
                        desglose_por_moneda[mon]["metodos"][met] = {"monto_moneda": 0.0, "monto_usd": 0.0, "conteo": 0}
                    desglose_por_moneda[mon]["metodos"][met]["monto_moneda"] = round(desglose_por_moneda[mon]["metodos"][met]["monto_moneda"] + m_moneda, 2)
                    desglose_por_moneda[mon]["metodos"][met]["monto_usd"] = round(desglose_por_moneda[mon]["metodos"][met]["monto_usd"] + m_usd, 2)
                    desglose_por_moneda[mon]["metodos"][met]["conteo"] += p.get("transacciones", 1)

                # Devoluciones registradas en el día
                cursor.execute("""
                    SELECT d.*, c.nombre as cliente_nombre, c.cedula as cliente_cedula
                    FROM devoluciones d
                    JOIN clientes c ON d.cliente_id = c.id
                    WHERE date(d.fecha_emision) = date(?)
                    ORDER BY d.id DESC
                """, (fecha,))
                devoluciones_dia = [dict(r) for r in cursor.fetchall()]
                total_devoluciones_usd = round(sum(d["total_usd"] for d in devoluciones_dia), 2)
                ventas_netas_usd = max(0.0, round(total_ventas_usd - total_devoluciones_usd, 2))

                self.send_json({
                    "fecha": fecha,
                    "resumen": {
                        "facturas_emitidas": len(facturas_dia),
                        "total_facturado_usd": total_ventas_usd,
                        "total_devoluciones_usd": total_devoluciones_usd,
                        "ventas_netas_usd": ventas_netas_usd,
                        "devoluciones_count": len(devoluciones_dia),
                        "subtotal_usd": total_subtotal_usd,
                        "iva_usd": total_iva_usd,
                        "total_cobrado_caja_usd": round(total_cobrado_usd, 2)
                    },
                    "desglose_monedas": desglose_por_moneda,
                    "facturas": facturas_dia,
                    "devoluciones": devoluciones_dia
                })

            # 12. Reporte de Ventas Mensuales
            elif path == "/api/reportes/ventas-mensuales":
                cursor.execute("""
                    SELECT 
                        strftime('%Y-%m', fecha) as mes,
                        COUNT(id) as total_facturas,
                        ROUND(COALESCE(SUM(subtotal), 0), 2) as subtotal_usd,
                        ROUND(COALESCE(SUM(iva_total), 0), 2) as iva_usd,
                        ROUND(COALESCE(SUM(total_usd), 0), 2) as total_usd,
                        ROUND(COALESCE(SUM(CASE WHEN tipo_venta = 'contado' THEN total_usd ELSE 0 END), 0), 2) as ventas_contado_usd,
                        ROUND(COALESCE(SUM(CASE WHEN tipo_venta = 'credito' THEN total_usd ELSE 0 END), 0), 2) as ventas_credito_usd
                    FROM facturas
                    GROUP BY strftime('%Y-%m', fecha)
                    ORDER BY mes DESC
                """)
                meses = [dict(r) for r in cursor.fetchall()]

                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                t_ves = cfg_row[0] if cfg_row else 45.0
                t_cop = cfg_row[1] if cfg_row else 4100.0

                for m in meses:
                    m["total_ves"] = round(m["total_usd"] * t_ves, 2)
                    m["total_cop"] = round(m["total_usd"] * t_cop, 2)

                total_historico_usd = round(sum(m["total_usd"] for m in meses), 2)
                total_facturas_historico = sum(m["total_facturas"] for m in meses)

                self.send_json({
                    "meses": meses,
                    "total_historico_usd": total_historico_usd,
                    "total_facturas_historico": total_facturas_historico
                })

            # 13. Reporte Detallado de Cuentas por Cobrar
            elif path == "/api/reportes/cxc-detallado":
                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                t_ves = cfg_row[0] if cfg_row else 45.0
                t_cop = cfg_row[1] if cfg_row else 4100.0

                cursor.execute("""
                    SELECT 
                        cxc.*,
                        f.numero_factura,
                        f.fecha as fecha_factura,
                        f.total_usd as factura_total_usd,
                        c.nombre as cliente_nombre,
                        c.cedula as cliente_cedula,
                        c.telefono as cliente_telefono,
                        c.correo as cliente_correo,
                        c.direccion as cliente_direccion,
                        ROUND(cxc.saldo_pendiente * ?, 2) as saldo_ves,
                        ROUND(cxc.saldo_pendiente * ?, 2) as saldo_cop,
                        CAST((julianday('now') - julianday(cxc.fecha_vencimiento)) AS INTEGER) as dias_vencido
                    FROM cuentas_por_cobrar cxc
                    JOIN facturas f ON cxc.factura_id = f.id
                    JOIN clientes c ON cxc.cliente_id = c.id
                    ORDER BY 
                        CASE WHEN cxc.estado = 'pendiente' THEN 1 WHEN cxc.estado = 'parcial' THEN 2 ELSE 3 END,
                        cxc.fecha_vencimiento ASC
                """, (t_ves, t_cop))
                cuentas = [dict(r) for r in cursor.fetchall()]

                total_deuda_usd = round(sum(c["saldo_pendiente"] for c in cuentas if c["estado"] != "pagada"), 2)
                total_facturado_usd = round(sum(c["monto_total"] for c in cuentas), 2)
                total_cobrado_usd = round(sum(c["monto_pagado"] for c in cuentas), 2)

                self.send_json({
                    "cuentas": cuentas,
                    "resumen": {
                        "total_deuda_usd": total_deuda_usd,
                        "total_deuda_ves": round(total_deuda_usd * t_ves, 2),
                        "total_deuda_cop": round(total_deuda_usd * t_cop, 2),
                        "total_facturado_usd": total_facturado_usd,
                        "total_cobrado_usd": total_cobrado_usd,
                        "cuentas_activas": len([c for c in cuentas if c["estado"] != "pagada"]),
                        "cuentas_vencidas": len([c for c in cuentas if c["estado"] != "pagada" and (c.get("dias_vencido") or 0) > 0]),
                        "cuentas_pagadas": len([c for c in cuentas if c["estado"] == "pagada"])
                    }
                })

            # 14. Reporte Detallado de Cuentas por Pagar (CXP)
            elif path == "/api/reportes/cxp-detallado":
                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                t_ves = cfg_row[0] if cfg_row else 45.0
                t_cop = cfg_row[1] if cfg_row else 4100.0

                cursor.execute("""
                    SELECT 
                        cxp.*,
                        comp.numero_control as compra_numero_control,
                        comp.fecha as fecha_compra,
                        prov.nombre as proveedor_nombre,
                        prov.cedula as proveedor_cedula,
                        prov.telefono as proveedor_telefono,
                        prov.correo as proveedor_correo,
                        prov.direccion as proveedor_direccion,
                        ROUND(cxp.saldo_pendiente * ?, 2) as saldo_ves,
                        ROUND(cxp.saldo_pendiente * ?, 2) as saldo_cop,
                        CAST((julianday('now') - julianday(cxp.fecha_vencimiento)) AS INTEGER) as dias_vencido
                    FROM cuentas_por_pagar cxp
                    LEFT JOIN compras comp ON cxp.compra_id = comp.id
                    JOIN proveedores prov ON cxp.proveedor_id = prov.id
                    ORDER BY 
                        CASE WHEN cxp.estado = 'pendiente' THEN 1 WHEN cxp.estado = 'parcial' THEN 2 ELSE 3 END,
                        cxp.fecha_vencimiento ASC
                """, (t_ves, t_cop))
                cuentas = [dict(r) for r in cursor.fetchall()]

                total_deuda_usd = round(sum(c["saldo_pendiente"] for c in cuentas if c["estado"] != "pagada"), 2)
                total_facturado_usd = round(sum(c["monto_total"] for c in cuentas), 2)
                total_pagado_usd = round(sum(c["monto_pagado"] for c in cuentas), 2)

                self.send_json({
                    "cuentas": cuentas,
                    "resumen": {
                        "total_deuda_usd": total_deuda_usd,
                        "total_deuda_ves": round(total_deuda_usd * t_ves, 2),
                        "total_deuda_cop": round(total_deuda_usd * t_cop, 2),
                        "total_facturado_usd": total_facturado_usd,
                        "total_pagado_usd": total_pagado_usd,
                        "cuentas_activas": len([c for c in cuentas if c["estado"] != "pagada"]),
                        "cuentas_vencidas": len([c for c in cuentas if c["estado"] != "pagada" and (c.get("dias_vencido") or 0) > 0]),
                        "cuentas_pagadas": len([c for c in cuentas if c["estado"] == "pagada"])
                    }
                })

            # 15. Reporte de Kardex de Inventario (Entradas, Salidas y Saldos Valorizados)
            elif path == "/api/reportes/kardex":
                producto_id = query.get("producto_id", [None])[0]
                desde = query.get("desde", [None])[0]
                hasta = query.get("hasta", [None])[0]

                cursor.execute("""
                    SELECT id, codigo, nombre, tipo, stock, costo, precio_total 
                    FROM productos 
                    WHERE tipo = 'producto' 
                    ORDER BY nombre ASC
                """)
                todos_productos = [dict(r) for r in cursor.fetchall()]

                if not producto_id and todos_productos:
                    producto_id = str(todos_productos[0]["id"])

                if not producto_id:
                    self.send_json({"productos": [], "producto": None, "movimientos": [], "resumen": {}})
                    return

                cursor.execute("""
                    SELECT p.*, c.nombre as categoria_nombre
                    FROM productos p
                    JOIN categorias c ON p.categoria_id = c.id
                    WHERE p.id = ?
                """, (producto_id,))
                prod_row = cursor.fetchone()
                if not prod_row:
                    self.send_error_json("Producto no encontrado", 404)
                    return
                prod = dict(prod_row)

                # Compras (Entradas)
                cursor.execute("""
                    SELECT cd.id, cd.cantidad, cd.costo_unitario as valor_unitario, cd.total as valor_total,
                           coalesce(c.fecha, date('now')) as fecha,
                           coalesce(c.numero_control, 'COM-0000') as documento,
                           c.numero_factura as referencia,
                           p.nombre as tercero,
                           'COMPRA' as tipo_movimiento,
                           'Entrada por compra de mercancía' as concepto
                    FROM compra_detalles cd
                    JOIN compras c ON cd.compra_id = c.id
                    JOIN proveedores p ON c.proveedor_id = p.id
                    WHERE cd.producto_id = ?
                """, (producto_id,))
                compras_list = [dict(r) for r in cursor.fetchall()]

                # Ventas (Salidas)
                cursor.execute("""
                    SELECT fd.id, fd.cantidad, fd.precio_unitario as valor_unitario, fd.total as valor_total,
                           f.fecha,
                           f.numero_factura as documento,
                           '' as referencia,
                           cl.nombre as tercero,
                           'VENTA' as tipo_movimiento,
                           'Salida por facturación al cliente' as concepto
                    FROM factura_detalles fd
                    JOIN facturas f ON fd.factura_id = f.id
                    JOIN clientes cl ON f.cliente_id = cl.id
                    WHERE fd.producto_id = ? AND f.estado != 'anulada'
                """, (producto_id,))
                ventas_list = [dict(r) for r in cursor.fetchall()]

                # Devoluciones de clientes (Entradas / Reintegro a Stock)
                cursor.execute("""
                    SELECT dd.id, dd.cantidad, dd.precio_unitario as valor_unitario, dd.total as valor_total,
                           d.fecha_emision as fecha,
                           d.numero_devolucion as documento,
                           d.numero_factura as referencia,
                           d.cliente_nombre as tercero,
                           'DEVOLUCION' as tipo_movimiento,
                           'Entrada por reintegro de devolución de cliente' as concepto
                    FROM devolucion_detalles dd
                    JOIN devoluciones d ON dd.devolucion_id = d.id
                    WHERE dd.producto_id = ?
                """, (producto_id,))
                devoluciones_list = [dict(r) for r in cursor.fetchall()]

                todos_movimientos = compras_list + ventas_list + devoluciones_list
                todos_movimientos.sort(key=lambda x: str(x.get("fecha") or ""))

                stock_actual = float(prod.get("stock") or 0.0)
                costo_u = float(prod.get("costo") or 0.0)

                total_entradas_hist = sum(float(m["cantidad"]) for m in todos_movimientos if m["tipo_movimiento"] in ('COMPRA', 'DEVOLUCION'))
                total_salidas_hist = sum(float(m["cantidad"]) for m in todos_movimientos if m["tipo_movimiento"] == 'VENTA')

                stock_inicial_base = round(max(0.0, stock_actual - total_entradas_hist + total_salidas_hist), 2)
                saldo_cant = stock_inicial_base
                movimientos_calculados = []

                for m in todos_movimientos:
                    cant = float(m["cantidad"])
                    v_unit = float(m["valor_unitario"] or costo_u)
                    v_tot = float(m["valor_total"] or (cant * v_unit))

                    if m["tipo_movimiento"] in ('COMPRA', 'DEVOLUCION'):
                        entrada_cant = cant
                        entrada_valor = v_tot
                        salida_cant = 0.0
                        salida_valor = 0.0
                        saldo_cant = round(saldo_cant + cant, 2)
                    else:
                        entrada_cant = 0.0
                        entrada_valor = 0.0
                        salida_cant = cant
                        salida_valor = v_tot
                        saldo_cant = round(saldo_cant - cant, 2)

                    saldo_valor = round(saldo_cant * costo_u, 2)

                    m_obj = dict(m)
                    m_obj["entrada_cant"] = entrada_cant
                    m_obj["entrada_valor"] = entrada_valor
                    m_obj["salida_cant"] = salida_cant
                    m_obj["salida_valor"] = salida_valor
                    m_obj["saldo_cant"] = saldo_cant
                    m_obj["saldo_valor"] = saldo_valor
                    movimientos_calculados.append(m_obj)

                movimientos_filtrados = []
                saldo_anterior_cant = stock_inicial_base
                for m in movimientos_calculados:
                    f_str = str(m.get("fecha") or "")[:10]
                    if desde and f_str < desde:
                        saldo_anterior_cant = m["saldo_cant"]
                        continue
                    if hasta and f_str > hasta:
                        continue
                    movimientos_filtrados.append(m)

                resumen = {
                    "stock_inicial": saldo_anterior_cant,
                    "valor_inicial": round(saldo_anterior_cant * costo_u, 2),
                    "total_entradas_cant": sum(m["entrada_cant"] for m in movimientos_filtrados),
                    "total_entradas_valor": round(sum(m["entrada_valor"] for m in movimientos_filtrados), 2),
                    "total_salidas_cant": sum(m["salida_cant"] for m in movimientos_filtrados),
                    "total_salidas_valor": round(sum(m["salida_valor"] for m in movimientos_filtrados), 2),
                    "stock_actual": stock_actual,
                    "valor_stock_actual": round(stock_actual * costo_u, 2),
                    "costo_unitario": costo_u
                }

                self.send_json({
                    "productos": todos_productos,
                    "producto": prod,
                    "movimientos": movimientos_filtrados,
                    "resumen": resumen
                })

            # 15b. Reporte de Kardex Oficial V2 (Basado directamente en inventario_movimientos - FASE 2D)
            elif path == "/api/reportes/kardex-v2":
                producto_id = query.get("producto_id", [None])[0]
                desde = query.get("desde", [None])[0]
                hasta = query.get("hasta", [None])[0]
                tipo_movimiento = query.get("tipo_movimiento", [None])[0]
                sentido = query.get("sentido", [None])[0]
                limit_q = query.get("limit", [100])[0]
                page_q = query.get("page", [1])[0]

                cursor.execute("""
                    SELECT id, codigo, nombre, tipo, stock, costo, precio_total 
                    FROM productos 
                    WHERE tipo = 'producto' 
                    ORDER BY nombre ASC
                """ )
                todos_productos = [dict(r) for r in cursor.fetchall()]

                producto_seleccionado = None
                if producto_id and str(producto_id).strip() not in ("", "0", "all"):
                    cursor.execute("""
                        SELECT p.*, c.nombre as categoria_nombre
                        FROM productos p
                        LEFT JOIN categorias c ON p.categoria_id = c.id
                        WHERE p.id = ?
                    """, (producto_id,))
                    p_row = cursor.fetchone()
                    if p_row:
                        producto_seleccionado = dict(p_row)

                sql = """
                    SELECT m.id, m.fecha, m.producto_id, m.tipo_movimiento, m.sentido,
                           m.cantidad, m.costo_unitario, m.costo_total,
                           m.stock_anterior, m.stock_nuevo,
                           m.documento_tipo, m.documento_id, m.documento_numero,
                           m.motivo, m.usuario_id, m.created_at,
                           p.codigo as producto_codigo, p.nombre as producto_nombre
                    FROM inventario_movimientos m
                    JOIN productos p ON m.producto_id = p.id
                    WHERE 1=1
                """
                params = []

                if producto_seleccionado:
                    sql += " AND m.producto_id = ?"
                    params.append(producto_seleccionado["id"])

                if desde and str(desde).strip():
                    sql += " AND m.fecha >= ?"
                    params.append(f"{desde.strip()} 00:00:00" if len(desde.strip()) == 10 else desde.strip())

                if hasta and str(hasta).strip():
                    sql += " AND m.fecha <= ?"
                    params.append(f"{hasta.strip()} 23:59:59" if len(hasta.strip()) == 10 else hasta.strip())

                if sentido and str(sentido).strip().upper() in ("ENTRADA", "SALIDA"):
                    sql += " AND m.sentido = ?"
                    params.append(sentido.strip().upper())

                if tipo_movimiento and str(tipo_movimiento).strip() not in ("", "all"):
                    tm = str(tipo_movimiento).strip().lower()
                    if tm == "compras":
                        sql += " AND m.tipo_movimiento = 'compra'"
                    elif tm == "ventas":
                        sql += " AND m.tipo_movimiento = 'venta'"
                    elif tm == "devoluciones":
                        sql += " AND m.tipo_movimiento IN ('devolucion_cliente', 'devolucion_proveedor')"
                    elif tm == "cargos":
                        sql += " AND m.tipo_movimiento = 'cargo_ajuste'"
                    elif tm == "descargos":
                        sql += " AND m.tipo_movimiento LIKE 'descargo_%'"
                    else:
                        sql += " AND m.tipo_movimiento = ?"
                        params.append(tipo_movimiento)

                # Orden cronológico determinístico
                sql += " ORDER BY m.fecha ASC, m.id ASC"

                cursor.execute(sql, tuple(params))
                raw_movs = [dict(r) for r in cursor.fetchall()]

                TIPO_MOVIMIENTO_LABELS = {
                    "inventario_inicial": "Inventario inicial",
                    "compra": "Compra",
                    "venta": "Venta",
                    "devolucion_cliente": "Devolución de cliente",
                    "devolucion_proveedor": "Devolución a proveedor",
                    "cargo_ajuste": "Cargo de inventario",
                    "descargo_merma": "Descargo por merma",
                    "descargo_vencimiento": "Descargo por vencimiento",
                    "descargo_rotura": "Descargo por rotura",
                    "descargo_uso_interno": "Descargo por uso interno",
                    "APERTURA_MIGRACION": "Apertura migración histórica"
                }

                movimientos_formateados = []
                total_entradas_cant = 0.0
                total_salidas_cant = 0.0
                total_entradas_costo = 0.0
                total_salidas_costo = 0.0

                for m in raw_movs:
                    cant = float(m["cantidad"] or 0.0)
                    c_unit = float(m["costo_unitario"] or 0.0)
                    c_tot = float(m["costo_total"] or round(cant * c_unit, 4))
                    sent = str(m["sentido"]).strip().upper()

                    if sent == "ENTRADA":
                        entrada_cant = cant
                        salida_cant = 0.0
                        total_entradas_cant += cant
                        total_entradas_costo += c_tot
                    else:
                        entrada_cant = 0.0
                        salida_cant = cant
                        total_salidas_cant += cant
                        total_salidas_costo += c_tot

                    doc_num = m["documento_numero"]
                    if not doc_num or str(doc_num).strip().upper() in ("NONE", "NULL", ""):
                        doc_num = "—"

                    doc_tipo = m["documento_tipo"]
                    if not doc_tipo or str(doc_tipo).strip().upper() in ("NONE", "NULL", ""):
                        doc_tipo = "—"

                    motivo = m["motivo"]
                    if not motivo or str(motivo).strip().upper() in ("NONE", "NULL", ""):
                        motivo = "—"

                    m_fmt = {
                        "id": m["id"],
                        "fecha": m["fecha"],
                        "producto_id": m["producto_id"],
                        "producto_codigo": m["producto_codigo"],
                        "producto_nombre": m["producto_nombre"],
                        "tipo_movimiento": m["tipo_movimiento"],
                        "tipo_movimiento_label": TIPO_MOVIMIENTO_LABELS.get(m["tipo_movimiento"], m["tipo_movimiento"].replace("_", " ").capitalize()),
                        "sentido": sent,
                        "cantidad": cant,
                        "entrada": entrada_cant,
                        "salida": salida_cant,
                        "costo_unitario": c_unit,
                        "costo_total": c_tot,
                        "stock_anterior": float(m["stock_anterior"] or 0.0),
                        "stock_nuevo": float(m["stock_nuevo"] or 0.0),
                        "saldo": float(m["stock_nuevo"] or 0.0),
                        "documento_tipo": doc_tipo,
                        "documento_id": m["documento_id"],
                        "documento_numero": doc_num,
                        "motivo": motivo,
                        "usuario_id": m["usuario_id"] or 1,
                        "created_at": m["created_at"]
                    }
                    movimientos_formateados.append(m_fmt)

                resumen = {
                    "total_movimientos": len(movimientos_formateados),
                    "total_entradas": round(total_entradas_cant, 2),
                    "total_salidas": round(total_salidas_cant, 2),
                    "total_costo_entradas": round(total_entradas_costo, 2),
                    "total_costo_salidas": round(total_salidas_costo, 2),
                    "stock_actual": float(producto_seleccionado["stock"]) if producto_seleccionado else None
                }

                total_items = len(movimientos_formateados)
                limit = None
                try:
                    if str(limit_q).lower() != "all":
                        limit = int(limit_q)
                except ValueError:
                    limit = 100

                page = 1
                try:
                    page = max(1, int(page_q))
                except ValueError:
                    page = 1

                if limit and total_items > limit:
                    offset = (page - 1) * limit
                    movs_paged = movimientos_formateados[offset:offset + limit]
                else:
                    movs_paged = movimientos_formateados

                self.send_json({
                    "success": True,
                    "productos": todos_productos,
                    "producto": producto_seleccionado,
                    "movimientos": movs_paged,
                    "resumen": resumen,
                    "paginacion": {
                        "total_items": total_items,
                        "pagina_actual": page,
                        "limite": limit,
                        "total_paginas": (total_items + limit - 1) // limit if limit else 1
                    }
                })

            # 16. Reporte de Inventario Simple (Código, Nombre y Stock Actual con Filtro de Categoría)
            elif path == "/api/reportes/inventario-simple":
                cat_id = query.get("categoria_id", [None])[0]
                search = (query.get("q", [None])[0] or "").strip().lower()

                sql = """
                    SELECT p.id, p.codigo, p.nombre, p.stock, p.stock_minimo, p.tipo,
                           p.precio_total, p.costo, c.id as categoria_id, c.nombre as categoria_nombre
                    FROM productos p
                    JOIN categorias c ON p.categoria_id = c.id
                    WHERE p.tipo = 'producto'
                """
                params = []
                if cat_id and cat_id != "todos":
                    sql += " AND p.categoria_id = ?"
                    params.append(cat_id)
                if search:
                    sql += " AND (LOWER(p.nombre) LIKE ? OR LOWER(p.codigo) LIKE ?)"
                    params.append(f"%{search}%")
                    params.append(f"%{search}%")

                sql += " ORDER BY c.nombre ASC, p.nombre ASC"
                cursor.execute(sql, tuple(params))
                items = [dict(r) for r in cursor.fetchall()]

                cursor.execute("SELECT id, nombre FROM categorias WHERE tipo = 'producto' ORDER BY nombre ASC")
                categorias = [dict(r) for r in cursor.fetchall()]

                self.send_json({
                    "items": items,
                    "productos": items,
                    "categorias": categorias,
                    "total_items": len(items),
                    "total_unidades": sum(float(i["stock"] or 0) for i in items),
                    "total_stock_unidades": sum(float(i["stock"] or 0) for i in items)
                })

            # 17. Libro de Ventas Fiscal SENIAT (Venezuela)
            elif path == "/api/reportes/seniat/libro-ventas":
                mes = query.get("mes", [None])[0] or datetime.now().strftime("%Y-%m")
                desde = query.get("desde", [None])[0]
                hasta = query.get("hasta", [None])[0]

                cursor.execute("SELECT nombre_negocio, documento_fiscal, tasa_ves FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                cfg = dict(cfg_row) if cfg_row else {"nombre_negocio": "Comercio", "documento_fiscal": "J-00000000-0", "tasa_ves": 45.0}
                t_ves = float(cfg.get("tasa_ves") or 45.0)

                sql_fac = """
                    SELECT f.*, cl.nombre as cliente_nombre, cl.cedula as cliente_cedula
                    FROM facturas f
                    JOIN clientes cl ON f.cliente_id = cl.id
                    WHERE 1=1
                """
                params_fac = []
                if desde and hasta:
                    sql_fac += " AND date(f.fecha) BETWEEN ? AND ?"
                    params_fac.extend([desde, hasta])
                else:
                    sql_fac += " AND strftime('%Y-%m', f.fecha) = ?"
                    params_fac.append(mes)
                sql_fac += " ORDER BY f.fecha ASC, f.id ASC"

                cursor.execute(sql_fac, tuple(params_fac))
                facturas_raw = [dict(r) for r in cursor.fetchall()]

                sql_dev = """
                    SELECT d.*
                    FROM devoluciones d
                    WHERE (d.estado IS NULL OR d.estado != 'anulada')
                """
                params_dev = []
                if desde and hasta:
                    sql_dev += " AND date(d.fecha_emision) BETWEEN ? AND ?"
                    params_dev.extend([desde, hasta])
                else:
                    sql_dev += " AND strftime('%Y-%m', d.fecha_emision) = ?"
                    params_dev.append(mes)
                sql_dev += " ORDER BY d.fecha_emision ASC, d.id ASC"

                cursor.execute(sql_dev, tuple(params_dev))
                devoluciones_raw = [dict(r) for r in cursor.fetchall()]

                registros = []
                num_op = 1

                for f in facturas_raw:
                    es_anulada = (f.get("estado") == "anulada")
                    if es_anulada:
                        registros.append({
                            "operacion_num": num_op,
                            "fecha": str(f.get("fecha") or "")[:10],
                            "cliente_rif": "-",
                            "cliente_nombre": "*** ANULADA ***",
                            "numero_factura": f.get("numero_factura"),
                            "numero_control": f.get("numero_factura"),
                            "nota_debito": "",
                            "nota_credito": "",
                            "factura_afectada": "",
                            "tipo_transaccion": "01-Reg",
                            "total_ventas_usd": 0.0,
                            "ventas_exentas_usd": 0.0,
                            "base_imponible_usd": 0.0,
                            "alicuota": 0.0,
                            "iva_causado_usd": 0.0,
                            "total_ventas_ves": 0.0,
                            "ventas_exentas_ves": 0.0,
                            "base_imponible_ves": 0.0,
                            "iva_causado_ves": 0.0,
                            "iva_retenido_ves": 0.0,
                            "estado": "ANULADA"
                        })
                        num_op += 1
                        continue

                    cursor.execute("""
                        SELECT 
                            SUM(CASE WHEN impuesto_tipo = 'exento' THEN total ELSE 0 END) as exento,
                            SUM(CASE WHEN impuesto_tipo = 'gravado' THEN subtotal ELSE 0 END) as base_gravada,
                            SUM(CASE WHEN impuesto_tipo = 'gravado' THEN (iva_unitario * cantidad) ELSE 0 END) as iva_gravado
                        FROM factura_detalles
                        WHERE factura_id = ?
                    """, (f["id"],))
                    det_row = cursor.fetchone()
                    exento_usd = float(det_row[0] or 0.0)
                    base_usd = float(det_row[1] or 0.0)
                    iva_usd = float(det_row[2] or f.get("iva_total", 0.0))
                    tot_usd = float(f.get("total_usd") or (exento_usd + base_usd + iva_usd))
                    t_ves_fac = float(f.get("tasa_ves") or t_ves)

                    registros.append({
                        "operacion_num": num_op,
                        "fecha": str(f.get("fecha") or "")[:10],
                        "cliente_rif": f.get("cliente_cedula") or "V-00000000",
                        "cliente_nombre": f.get("cliente_nombre") or "Consumidor Final",
                        "numero_factura": f.get("numero_factura"),
                        "numero_control": f.get("numero_factura"),
                        "nota_debito": "",
                        "nota_credito": "",
                        "factura_afectada": "",
                        "tipo_transaccion": "01-Reg",
                        "total_ventas_usd": round(tot_usd, 2),
                        "ventas_exentas_usd": round(exento_usd, 2),
                        "base_imponible_usd": round(base_usd, 2),
                        "alicuota": 16.0,
                        "iva_causado_usd": round(iva_usd, 2),
                        "total_ventas_ves": round(tot_usd * t_ves_fac, 2),
                        "ventas_exentas_ves": round(exento_usd * t_ves_fac, 2),
                        "base_imponible_ves": round(base_usd * t_ves_fac, 2),
                        "iva_causado_ves": round(iva_usd * t_ves_fac, 2),
                        "iva_retenido_ves": 0.0
                    })
                    num_op += 1

                for d in devoluciones_raw:
                    tot_usd = float(d.get("total_usd") or 0.0)
                    sub_usd = float(d.get("subtotal_usd") or 0.0)
                    iva_usd = float(d.get("iva_usd") or 0.0)
                    exento_usd = max(0.0, round(tot_usd - sub_usd - iva_usd, 2))
                    t_ves_dev = float(d.get("tasa_ves") or t_ves)

                    registros.append({
                        "operacion_num": num_op,
                        "fecha": str(d.get("fecha_emision") or "")[:10],
                        "cliente_rif": d.get("cliente_cedula") or "V-00000000",
                        "cliente_nombre": d.get("cliente_nombre") or "Cliente Devolución",
                        "numero_factura": "",
                        "numero_control": d.get("numero_devolucion"),
                        "nota_debito": "",
                        "nota_credito": d.get("numero_devolucion"),
                        "factura_afectada": d.get("numero_factura") or "",
                        "tipo_transaccion": "03-NC",
                        "total_ventas_usd": round(-tot_usd, 2),
                        "ventas_exentas_usd": round(-exento_usd, 2),
                        "base_imponible_usd": round(-sub_usd, 2),
                        "alicuota": 16.0,
                        "iva_causado_usd": round(-iva_usd, 2),
                        "total_ventas_ves": round(-tot_usd * t_ves_dev, 2),
                        "ventas_exentas_ves": round(-exento_usd * t_ves_dev, 2),
                        "base_imponible_ves": round(-sub_usd * t_ves_dev, 2),
                        "iva_causado_ves": round(-iva_usd * t_ves_dev, 2),
                        "iva_retenido_ves": 0.0
                    })
                    num_op += 1

                registros.sort(key=lambda r: r["fecha"])
                for i, r in enumerate(registros):
                    r["operacion_num"] = i + 1

                bruto_usd = sum(r["total_ventas_usd"] for r in registros if r["tipo_transaccion"] == "01-Reg")
                nc_usd = abs(sum(r["total_ventas_usd"] for r in registros if r["tipo_transaccion"] == "03-NC"))
                neto_usd = sum(r["total_ventas_usd"] for r in registros)
                exento_usd = sum(r["ventas_exentas_usd"] for r in registros)
                base_usd = sum(r["base_imponible_usd"] for r in registros)
                iva_usd = sum(r["iva_causado_usd"] for r in registros)

                bruto_ves = sum(r["total_ventas_ves"] for r in registros if r["tipo_transaccion"] == "01-Reg")
                nc_ves = abs(sum(r["total_ventas_ves"] for r in registros if r["tipo_transaccion"] == "03-NC"))
                neto_ves = sum(r["total_ventas_ves"] for r in registros)
                exento_ves = sum(r["ventas_exentas_ves"] for r in registros)
                base_ves = sum(r["base_imponible_ves"] for r in registros)
                iva_ves = sum(r["iva_causado_ves"] for r in registros)

                items_ventas = [
                    {
                        **r,
                        "operacion_nro": r["operacion_num"],
                        "es_devolucion": r["tipo_transaccion"] == "03-NC",
                        "numero_nota_credito": r.get("nota_credito", ""),
                        "iva_debito_ves": r.get("iva_causado_ves", 0.0),
                        "iva_debito_usd": r.get("iva_causado_usd", 0.0)
                    }
                    for r in registros
                ]

                mes_part = mes.split("-")[1] if "-" in mes else mes
                anio_part = mes.split("-")[0] if "-" in mes else ""

                self.send_json({
                    "contribuyente": cfg,
                    "empresa": {
                        "nombre": cfg.get("nombre_negocio"),
                        "rif": cfg.get("documento_fiscal")
                    },
                    "periodo": mes,
                    "mes": mes_part,
                    "anio": anio_part,
                    "tasa_bcv_cierre": t_ves,
                    "registros": registros,
                    "items": items_ventas,
                    "totales": {
                        "total_ventas_brutas_usd": round(bruto_usd, 2),
                        "total_notas_credito_usd": round(nc_usd, 2),
                        "total_ventas_netas_usd": round(neto_usd, 2),
                        "total_exentas_usd": round(exento_usd, 2),
                        "total_base_imponible_usd": round(base_usd, 2),
                        "total_iva_debito_usd": round(iva_usd, 2),
                        "total_ventas_brutas_ves": round(bruto_ves, 2),
                        "total_notas_credito_ves": round(nc_ves, 2),
                        "total_ventas_netas_ves": round(neto_ves, 2),
                        "total_exentas_ves": round(exento_ves, 2),
                        "total_base_imponible_ves": round(base_ves, 2),
                        "total_iva_debito_ves": round(iva_ves, 2)
                    },
                    "resumen": {
                        "total_ventas_ves": round(neto_ves, 2),
                        "total_ventas_usd": round(neto_usd, 2),
                        "total_base_imponible_ves": round(base_ves, 2),
                        "total_base_imponible_usd": round(base_usd, 2),
                        "total_iva_ves": round(iva_ves, 2),
                        "total_iva_usd": round(iva_usd, 2),
                        "total_exento_ves": round(exento_ves, 2),
                        "total_exento_usd": round(exento_usd, 2)
                    }
                })

            # 18. Libro de Compras Fiscal SENIAT (Venezuela)
            elif path == "/api/reportes/seniat/libro-compras":
                mes = query.get("mes", [None])[0] or datetime.now().strftime("%Y-%m")
                desde = query.get("desde", [None])[0]
                hasta = query.get("hasta", [None])[0]

                cursor.execute("SELECT nombre_negocio, documento_fiscal, tasa_ves FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                cfg = dict(cfg_row) if cfg_row else {"nombre_negocio": "Comercio", "documento_fiscal": "J-00000000-0", "tasa_ves": 45.0}
                t_ves = float(cfg.get("tasa_ves") or 45.0)

                sql_com = """
                    SELECT c.*, p.nombre as proveedor_nombre, p.cedula as proveedor_cedula
                    FROM compras c
                    JOIN proveedores p ON c.proveedor_id = p.id
                    WHERE (c.estado IS NULL OR c.estado != 'anulada')
                """
                params_com = []
                if desde and hasta:
                    sql_com += " AND date(c.fecha) BETWEEN ? AND ?"
                    params_com.extend([desde, hasta])
                else:
                    sql_com += " AND strftime('%Y-%m', c.fecha) = ?"
                    params_com.append(mes)
                sql_com += " ORDER BY c.fecha ASC, c.id ASC"

                cursor.execute(sql_com, tuple(params_com))
                compras_raw = [dict(r) for r in cursor.fetchall()]

                registros = []
                num_op = 1

                for c in compras_raw:
                    cursor.execute("""
                        SELECT 
                            SUM(CASE WHEN impuesto_tipo = 'exento' THEN total ELSE 0 END) as exento,
                            SUM(CASE WHEN impuesto_tipo = 'gravado' THEN (costo_unitario * cantidad) ELSE 0 END) as base_gravada,
                            SUM(CASE WHEN impuesto_tipo = 'gravado' THEN (iva_unitario * cantidad) ELSE 0 END) as iva_gravado
                        FROM compra_detalles
                        WHERE compra_id = ?
                    """, (c["id"],))
                    det_row = cursor.fetchone()
                    exento_usd = float(det_row[0] or 0.0)
                    base_usd = float(det_row[1] or c.get("subtotal", 0.0))
                    iva_usd = float(det_row[2] or c.get("iva_total", 0.0))
                    tot_usd = float(c.get("total") or (exento_usd + base_usd + iva_usd))

                    registros.append({
                        "operacion_num": num_op,
                        "fecha": str(c.get("fecha") or "")[:10],
                        "proveedor_rif": c.get("proveedor_cedula") or "J-00000000-0",
                        "proveedor_nombre": c.get("proveedor_nombre") or "Proveedor",
                        "numero_factura": c.get("numero_factura") or c.get("numero_control"),
                        "numero_control": c.get("numero_control"),
                        "nota_debito": "",
                        "nota_credito": "",
                        "tipo_transaccion": "01-Reg",
                        "total_compras_usd": round(tot_usd, 2),
                        "compras_exentas_usd": round(exento_usd, 2),
                        "base_imponible_usd": round(base_usd, 2),
                        "alicuota": 16.0,
                        "iva_credito_usd": round(iva_usd, 2),
                        "total_compras_ves": round(tot_usd * t_ves, 2),
                        "compras_exentas_ves": round(exento_usd * t_ves, 2),
                        "base_imponible_ves": round(base_usd * t_ves, 2),
                        "iva_credito_ves": round(iva_usd * t_ves, 2),
                        "iva_retenido_ves": 0.0
                    })
                    num_op += 1

                tot_compras_usd = sum(r["total_compras_usd"] for r in registros)
                tot_exentas_usd = sum(r["compras_exentas_usd"] for r in registros)
                tot_base_usd = sum(r["base_imponible_usd"] for r in registros)
                tot_iva_usd = sum(r["iva_credito_usd"] for r in registros)

                tot_compras_ves = sum(r["total_compras_ves"] for r in registros)
                tot_exentas_ves = sum(r["compras_exentas_ves"] for r in registros)
                tot_base_ves = sum(r["base_imponible_ves"] for r in registros)
                tot_iva_ves = sum(r["iva_credito_ves"] for r in registros)

                items_compras = [
                    {
                        **r,
                        "operacion_nro": r["operacion_num"],
                        "numero_nota_deb_cred": r.get("nota_credito") or r.get("nota_debito") or "",
                        "factura_afectada": ""
                    }
                    for r in registros
                ]

                mes_part = mes.split("-")[1] if "-" in mes else mes
                anio_part = mes.split("-")[0] if "-" in mes else ""

                self.send_json({
                    "contribuyente": cfg,
                    "empresa": {
                        "nombre": cfg.get("nombre_negocio"),
                        "rif": cfg.get("documento_fiscal")
                    },
                    "periodo": mes,
                    "mes": mes_part,
                    "anio": anio_part,
                    "tasa_bcv_cierre": t_ves,
                    "registros": registros,
                    "items": items_compras,
                    "totales": {
                        "total_compras_usd": round(tot_compras_usd, 2),
                        "total_exentas_usd": round(tot_exentas_usd, 2),
                        "total_base_imponible_usd": round(tot_base_usd, 2),
                        "total_iva_credito_usd": round(tot_iva_usd, 2),
                        "total_compras_ves": round(tot_compras_ves, 2),
                        "total_exentas_ves": round(tot_exentas_ves, 2),
                        "total_base_imponible_ves": round(tot_base_ves, 2),
                        "total_iva_credito_ves": round(tot_iva_ves, 2)
                    },
                    "resumen": {
                        "total_compras_ves": round(tot_compras_ves, 2),
                        "total_compras_usd": round(tot_compras_usd, 2),
                        "total_base_imponible_ves": round(tot_base_ves, 2),
                        "total_base_imponible_usd": round(tot_base_usd, 2),
                        "total_iva_ves": round(tot_iva_ves, 2),
                        "total_iva_usd": round(tot_iva_usd, 2),
                        "total_exento_ves": round(tot_exentas_ves, 2),
                        "total_exento_usd": round(tot_exentas_usd, 2)
                    }
                })

            # 19. Libro de Movimiento de Inventario según Artículo 177 R-LISLR (Venezuela)
            elif path == "/api/reportes/seniat/libro-inventario-art177":
                mes = query.get("mes", [None])[0] or datetime.now().strftime("%Y-%m")
                cursor.execute("SELECT nombre_negocio, documento_fiscal, tasa_ves FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                cfg = dict(cfg_row) if cfg_row else {"nombre_negocio": "Comercio", "documento_fiscal": "J-00000000-0", "tasa_ves": 45.0}
                t_ves = float(cfg.get("tasa_ves") or 45.0)

                cursor.execute("""
                    SELECT p.id, p.codigo, p.nombre, p.costo, p.stock, c.nombre as categoria_nombre
                    FROM productos p
                    JOIN categorias c ON p.categoria_id = c.id
                    WHERE p.tipo = 'producto'
                    ORDER BY c.nombre ASC, p.nombre ASC
                """)
                productos = [dict(r) for r in cursor.fetchall()]

                articulos = []
                tot_val_inicial = 0.0
                tot_val_entradas = 0.0
                tot_val_salidas = 0.0
                tot_val_final = 0.0

                for p in productos:
                    p_id = p["id"]
                    costo_u = float(p.get("costo") or 0.0)
                    stock_db = float(p.get("stock") or 0.0)

                    cursor.execute("""
                        SELECT COALESCE(SUM(cd.cantidad), 0)
                        FROM compra_detalles cd
                        JOIN compras c ON cd.compra_id = c.id
                        WHERE cd.producto_id = ? AND strftime('%Y-%m', c.fecha) = ?
                    """, (p_id, mes))
                    cant_compras = float(cursor.fetchone()[0] or 0.0)

                    cursor.execute("""
                        SELECT COALESCE(SUM(dd.cantidad), 0)
                        FROM devolucion_detalles dd
                        JOIN devoluciones d ON dd.devolucion_id = d.id
                        WHERE dd.producto_id = ? AND strftime('%Y-%m', d.fecha_emision) = ?
                    """, (p_id, mes))
                    cant_devoluciones = float(cursor.fetchone()[0] or 0.0)

                    total_entradas = cant_compras + cant_devoluciones

                    cursor.execute("""
                        SELECT COALESCE(SUM(fd.cantidad), 0)
                        FROM factura_detalles fd
                        JOIN facturas f ON fd.factura_id = f.id
                        WHERE fd.producto_id = ? AND strftime('%Y-%m', f.fecha) = ? AND f.estado != 'anulada'
                    """, (p_id, mes))
                    cant_ventas = float(cursor.fetchone()[0] or 0.0)
                    total_salidas = cant_ventas

                    inv_final_cant = stock_db
                    inv_inicial_cant = max(0.0, inv_final_cant - total_entradas + total_salidas)

                    val_inicial_usd = round(inv_inicial_cant * costo_u, 2)
                    val_entradas_usd = round(total_entradas * costo_u, 2)
                    val_salidas_usd = round(total_salidas * costo_u, 2)
                    val_final_usd = round(inv_final_cant * costo_u, 2)

                    tot_val_inicial += val_inicial_usd
                    tot_val_entradas += val_entradas_usd
                    tot_val_salidas += val_salidas_usd
                    tot_val_final += val_final_usd

                    articulos.append({
                        "producto_id": p_id,
                        "codigo": p.get("codigo") or "-",
                        "nombre": p.get("nombre"),
                        "categoria": p.get("categoria_nombre"),
                        "costo_unitario": costo_u,
                        "inicial_cant": inv_inicial_cant,
                        "inicial_valor_usd": val_inicial_usd,
                        "inicial_valor_ves": round(val_inicial_usd * t_ves, 2),
                        "entradas_cant": total_entradas,
                        "entradas_valor_usd": val_entradas_usd,
                        "entradas_valor_ves": round(val_entradas_usd * t_ves, 2),
                        "salidas_cant": total_salidas,
                        "salidas_valor_usd": val_salidas_usd,
                        "salidas_valor_ves": round(val_salidas_usd * t_ves, 2),
                        "final_cant": inv_final_cant,
                        "final_valor_usd": val_final_usd,
                        "final_valor_ves": round(val_final_usd * t_ves, 2)
                    })

                items_art177 = [
                    {
                        **a,
                        "costo_unit_usd": a["costo_unitario"],
                        "inicial_total_ves": a["inicial_valor_ves"],
                        "entradas_total_ves": a["entradas_valor_ves"],
                        "salidas_total_ves": a["salidas_valor_ves"],
                        "final_total_ves": a["final_valor_ves"]
                    }
                    for a in articulos
                ]

                self.send_json({
                    "contribuyente": cfg,
                    "empresa": {
                        "nombre": cfg.get("nombre_negocio"),
                        "rif": cfg.get("documento_fiscal")
                    },
                    "periodo_mes": mes,
                    "periodo": mes,
                    "tasa_bcv": t_ves,
                    "articulos": articulos,
                    "items": items_art177,
                    "totales": {
                        "inicial_valor_usd": round(tot_val_inicial, 2),
                        "entradas_valor_usd": round(tot_val_entradas, 2),
                        "salidas_valor_usd": round(tot_val_salidas, 2),
                        "final_valor_usd": round(tot_val_final, 2),
                        "inicial_valor_ves": round(tot_val_inicial * t_ves, 2),
                        "entradas_valor_ves": round(tot_val_entradas * t_ves, 2),
                        "salidas_valor_ves": round(tot_val_salidas * t_ves, 2),
                        "final_valor_ves": round(tot_val_final * t_ves, 2)
                    },
                    "resumen": {
                        "total_inicial_usd": round(tot_val_inicial, 2),
                        "total_inicial_ves": round(tot_val_inicial * t_ves, 2),
                        "total_entradas_usd": round(tot_val_entradas, 2),
                        "total_entradas_ves": round(tot_val_entradas * t_ves, 2),
                        "total_salidas_usd": round(tot_val_salidas, 2),
                        "total_salidas_ves": round(tot_val_salidas * t_ves, 2),
                        "total_final_usd": round(tot_val_final, 2),
                        "total_final_ves": round(tot_val_final * t_ves, 2)
                    }
                })

            # --- FASE 2F-6C: MODELO FINANCIERO & TESORERÍA (GET) ---
            elif path == "/api/tesoreria/cuentas":
                solo_activas = query.get("solo_activas", ["true"])[0].lower() != "false"
                cuentas = obtener_cuentas_tesoreria(solo_activas=solo_activas, conn=conn)
                self.send_json({"success": True, "data": cuentas})
                return

            elif path == "/api/tesoreria/resumen":
                resumen = obtener_resumen_tesoreria(conn=conn)
                self.send_json({"success": True, "data": resumen})
                return

            elif path == "/api/pagos":
                filtros = {k: v[0] for k, v in query.items()}
                pagos = obtener_historial_pagos(filtros=filtros, conn=conn)
                self.send_json({"success": True, "data": pagos})
                return

            elif path.startswith("/api/anticipos/cliente/"):
                parts = path.split("/")
                cliente_id = int(parts[-1])
                solo_disp = query.get("solo_disponibles", ["true"])[0].lower() != "false"
                anticipos = obtener_anticipos_cliente(cliente_id, solo_disponibles=solo_disp, conn=conn)
                self.send_json({"success": True, "data": anticipos})
                return

            elif path == "/api/gastos":
                filtros = {k: v[0] for k, v in query.items()}
                gastos = obtener_gastos_operativos(filtros=filtros, conn=conn)
                self.send_json({"success": True, "data": gastos})
                return

            # --- FASE 3A: INTELIGENCIA ARTIFICIAL ORGÁNICA DE INVENTARIOS ---
            elif path == "/api/ia/inventario/diagnostico":
                diag = diagnosticar_inventario_organico(conn=conn)
                self.send_json(diag)
                return

            elif path == "/api/ia/inventario/alertas":
                diag = diagnosticar_inventario_organico(conn=conn)
                self.send_json({
                    "success": True,
                    "alertas": diag.get("alertas_gerenciales", []),
                    "resumen": diag.get("resumen_patrimonial", {})
                })
                return

            # --- FASE 3B: CFO COPILOT GERENCIAL - SUGERENCIAS RÁPIDAS ---
            elif path == "/api/ia/copilot/sugerencias":
                sug = cfo_copilot.obtener_sugerencias_copilot()
                self.send_json({
                    "success": True,
                    "sugerencias": sug
                })
                return

            else:
                self.send_error_json("Endpoint no reconocido", 404)

        except Exception as e:
            self.send_error_json(str(e), 500)
        finally:
            conn.close()

    # ==========================================
    # CONTROLADORES DE LA API (POST)
    # ==========================================
    def handle_api_post(self, path):
        body = self.parse_body_json()
        if body is None:
            self.send_error_json("Formato JSON inválido", 400)
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:
            # 0. Mantenimiento y Gestión de Base de Datos para Beta Tester (Protegido con Frases de Seguridad)
            if path == "/api/database/clean-transactions":
                confirmacion = (body.get("confirmacion") or "").strip()
                if confirmacion != "CONFIRMAR_BORRADO_TOTAL_AUTORIZADO":
                    self.send_error_json(
                        "Operación de alta seguridad bloqueada: Se requiere confirmacion='CONFIRMAR_BORRADO_TOTAL_AUTORIZADO' para prevenir borrado accidental de transacciones.",
                        403
                    )
                    return
                limpiar_transacciones_db(confirmacion)
                self.send_json({
                    "success": True,
                    "message": "Datos de prueba eliminados correctamente. Facturas, compras y deudas en 0. Stock reiniciado."
                })
                return

            elif path == "/api/database/factory-reset":
                confirmacion = (body.get("confirmacion") or "").strip()
                if confirmacion not in ["CONFIRMAR_RESTABLECER_FABRICA_AUTORIZADO", "CONFIRMAR_BORRADO_TOTAL_AUTORIZADO"]:
                    self.send_error_json(
                        "Operación de alta seguridad bloqueada: Se requiere confirmacion='CONFIRMAR_RESTABLECER_FABRICA_AUTORIZADO'.",
                        403
                    )
                    return
                restablecer_fabrica_db(confirmacion)
                self.send_json({
                    "success": True,
                    "message": "Base de datos restablecida a valores de fábrica limpios para el Beta Tester."
                })
                return

            elif path == "/api/database/restore":
                db_b64 = body.get("file_base64")
                if not db_b64:
                    self.send_error_json("Falta file_base64 en la solicitud", 400)
                    return
                try:
                    db_bytes = base64.b64decode(db_b64)
                    if len(db_bytes) < 100 or not db_bytes.startswith(b"SQLite format 3\x00"):
                        self.send_error_json("El archivo subido no es una base de datos SQLite válida", 400)
                        return
                    
                    backup_path = os.path.join(BASE_DIR, "inventario_pre_restore.db")
                    if os.path.exists(DB_PATH):
                        shutil.copy2(DB_PATH, backup_path)
                    
                    with open(DB_PATH, "wb") as f:
                        f.write(db_bytes)
                    
                    schedule_cloud_sync()
                    self.send_json({
                        "success": True,
                        "message": "Base de datos restaurada exitosamente."
                    })
                    return
                except Exception as e:
                    self.send_error_json(f"Error al restaurar archivo: {str(e)}", 500)
                    return

            elif path == "/api/database/sync-now":
                ok = sync_to_supabase_storage()
                self.send_json({
                    "success": ok,
                    "message": "Sincronización manual con Supabase completada." if ok else "No se pudo sincronizar con Supabase (verifique credenciales)."
                })
                return

            # 1. Crear Categoría
            elif path == "/api/categorias":
                nombre = body.get("nombre", "").strip()
                tipo = body.get("tipo", "").strip().lower()
                descripcion = body.get("descripcion", "").strip()

                if not nombre or tipo not in ('servicio', 'producto'):
                    self.send_error_json("Nombre y tipo válido ('servicio' o 'producto') son requeridos", 400)
                    return

                cursor.execute("INSERT INTO categorias (nombre, tipo, descripcion) VALUES (?, ?, ?)",
                               (nombre, tipo, descripcion))
                conn.commit()
                cat_id = cursor.lastrowid
                self.send_json({"id": cat_id, "nombre": nombre, "tipo": tipo, "descripcion": descripcion, "success": True}, 201)

            # 2. Crear Producto o Servicio
            elif path == "/api/productos":
                codigo = body.get("codigo", "").strip()
                nombre = body.get("nombre", "").strip()
                categoria_id = body.get("categoria_id")
                tipo = body.get("tipo", "").strip().lower()
                impuesto_tipo = body.get("impuesto_tipo", "gravado").strip().lower()
                precio_base = float(body.get("precio_base", 0.0))
                costo = float(body.get("costo", 0.0))
                stock = float(body.get("stock", 0.0))
                stock_minimo = float(body.get("stock_minimo", 5.0))
                imagen = body.get("imagen", "")
                descripcion = body.get("descripcion", "").strip()

                if not nombre or not categoria_id or tipo not in ('servicio', 'producto'):
                    self.send_error_json("Campos obligatorios: nombre, categoria_id y tipo ('servicio' o 'producto')", 400)
                    return

                if not codigo:
                    # Generar código automático si no se proporcionó
                    prefix = "PRD" if tipo == "producto" else "SRV"
                    codigo = f"{prefix}-{int(time.time()) % 100000:05d}"

                # Si es servicio, NO maneja existencia
                if tipo == 'servicio':
                    stock = 0.0
                    stock_minimo = 0.0

                # Obtener porcentaje de IVA de configuración
                cursor.execute("SELECT iva_porcentaje FROM configuracion WHERE id = 1")
                iva_pct = cursor.fetchone()[0] / 100.0

                if impuesto_tipo == 'gravado':
                    iva_monto = round(precio_base * iva_pct, 4)
                else:
                    iva_monto = 0.0

                precio_total = round(precio_base + iva_monto, 4)

                cursor.execute("""
                    INSERT INTO productos (codigo, nombre, categoria_id, tipo, impuesto_tipo, precio_base, iva_monto, precio_total, costo, stock, stock_minimo, imagen, descripcion)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (codigo, nombre, categoria_id, tipo, impuesto_tipo, precio_base, iva_monto, precio_total, costo, stock, stock_minimo, imagen, descripcion))
                p_id = cursor.lastrowid

                # FASE 2C: Si se crea un producto físico con stock inicial > 0,
                # registrar formalmente el movimiento de inventario_inicial en la misma transacción
                if tipo == 'producto' and stock > 0:
                    ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    registrar_movimiento_inventario(
                        cursor=cursor,
                        producto_id=p_id,
                        fecha=ahora,
                        tipo_movimiento="inventario_inicial",
                        sentido="ENTRADA",
                        cantidad=stock,
                        costo_unitario=costo,
                        costo_total=round(stock * costo, 4),
                        stock_anterior=0.0,
                        stock_nuevo=stock,
                        documento_tipo="INVENTARIO_INICIAL",
                        documento_id=p_id,
                        documento_numero=f"INI-{codigo}",
                        motivo="Inventario inicial registrado al crear producto",
                        usuario_id=1
                    )
                conn.commit()
                self.send_json({"id": p_id, "codigo": codigo, "success": True}, 201)

            # 3. Crear Cliente
            elif path == "/api/clientes":
                nombre = body.get("nombre", "").strip()
                cedula = body.get("cedula", "").strip().upper()
                telefono = body.get("telefono", "").strip()
                correo = body.get("correo", "").strip()
                direccion = body.get("direccion", "").strip()

                if not nombre or not cedula or not telefono:
                    self.send_error_json("Nombre, cédula y teléfono para WhatsApp son obligatorios", 400)
                    return

                cursor.execute("""
                    INSERT INTO clientes (nombre, cedula, telefono, correo, direccion)
                    VALUES (?, ?, ?, ?, ?)
                """, (nombre, cedula, telefono, correo, direccion))
                conn.commit()
                self.send_json({"id": cursor.lastrowid, "success": True}, 201)

            # 4. Crear Proveedor
            elif path == "/api/proveedores":
                nombre = body.get("nombre", "").strip()
                cedula = body.get("cedula", "").strip().upper()
                telefono = body.get("telefono", "").strip()
                correo = body.get("correo", "").strip()
                direccion = body.get("direccion", "").strip()

                if not nombre or not cedula or not telefono:
                    self.send_error_json("Nombre, cédula/RIF y teléfono para WhatsApp son obligatorios", 400)
                    return

                cursor.execute("""
                    INSERT INTO proveedores (nombre, cedula, telefono, correo, direccion)
                    VALUES (?, ?, ?, ?, ?)
                """, (nombre, cedula, telefono, correo, direccion))
                conn.commit()
                self.send_json({"id": cursor.lastrowid, "success": True}, 201)

            # 5. Crear Factura (Integración Transaccional Motor CPP - FASE 2F-3B)
            elif path == "/api/facturas":
                cliente_id = body.get("cliente_id")
                items = body.get("items", [])
                pagos = body.get("pagos", [])
                notas = body.get("notas", "")
                tipo_venta = body.get("tipo_venta", "contado").strip().lower()
                fecha_vencimiento = body.get("fecha_vencimiento", "")
                fecha_factura_input = body.get("fecha")
                numero_factura_input = (body.get("numero_factura") or "").strip()
                idempotency_key = (body.get("idempotency_key") or body.get("client_tx_id") or "").strip()

                if not cliente_id or not items or len(items) == 0:
                    self.send_error_json("Se requiere un cliente y al menos un producto o servicio", 400)
                    return

                cursor.execute("SELECT id FROM clientes WHERE id = ?", (cliente_id,))
                if not cursor.fetchone():
                    self.send_error_json(f"Cliente ID {cliente_id} no encontrado", 404)
                    return

                if tipo_venta == "credito" and not fecha_vencimiento:
                    fecha_vencimiento = (datetime.now() + timedelta(days=15)).strftime("%Y-%m-%d")

                # Normalización de fecha de factura
                if fecha_factura_input and str(fecha_factura_input).strip():
                    f_str = str(fecha_factura_input).strip()
                    if len(f_str) == 10:
                        ahora_h = datetime.now().strftime("%H:%M:%S")
                        fecha_factura = f"{f_str} {ahora_h}"
                    else:
                        fecha_factura = f_str
                else:
                    fecha_factura = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # Idempotencia: Verificar si ya existe factura con ese número o clave de idempotencia
                if numero_factura_input:
                    cursor.execute("""
                        SELECT id, numero_factura, total_usd, saldo_pendiente, tipo_venta 
                        FROM facturas 
                        WHERE numero_factura = ?
                    """, (numero_factura_input,))
                    fact_existente = cursor.fetchone()
                    if fact_existente:
                        self.send_error_json(
                            f"IDEMPOTENCIA: Ya existe una factura registrada con el número '{numero_factura_input}' (Factura ID {fact_existente['id']}). Operación rechazada.",
                            409
                        )
                        return

                if idempotency_key:
                    cursor.execute("""
                        SELECT id, numero_factura, total_usd, saldo_pendiente, tipo_venta 
                        FROM facturas 
                        WHERE notas LIKE ?
                    """, (f"%[IDEMPOTENCY:{idempotency_key}]%",))
                    fact_idem = cursor.fetchone()
                    if fact_idem:
                        self.send_error_json(
                            f"IDEMPOTENCIA: La transacción con clave '{idempotency_key}' ya fue procesada (Factura {fact_idem['numero_factura']} ID {fact_idem['id']}). Operación rechazada.",
                            409
                        )
                        return

                # BEGIN IMMEDIATE: Candado exclusivo para aislar lecturas y escrituras de stock y CPP
                cursor.execute("BEGIN IMMEDIATE")

                # Obtener configuración de tasas e IVA
                cursor.execute("SELECT * FROM configuracion WHERE id = 1")
                cfg = dict(cursor.fetchone())
                tasa_ves = cfg["tasa_ves"]
                tasa_cop = cfg["tasa_cop"]
                iva_pct = cfg["iva_porcentaje"] / 100.0

                # Pre-validación de ítems y cálculo de subtotales financieros
                subtotal = 0.0
                iva_total = 0.0

                for itm in items:
                    prod_id = itm.get("producto_id")
                    cant_v = float(itm.get("cantidad", 1))
                    if cant_v <= 0:
                        raise ValueError(f"La cantidad vendida debe ser mayor a 0, recibido: {cant_v}")

                    cursor.execute("SELECT id, nombre, tipo, impuesto_tipo, precio_base FROM productos WHERE id = ?", (prod_id,))
                    p_info = cursor.fetchone()
                    if not p_info:
                        raise ValueError(f"Producto ID {prod_id} no existe en catálogo")

                    p_dict = dict(p_info)
                    precio_u_v = float(itm.get("precio_unitario", p_dict["precio_base"]))
                    if precio_u_v < 0:
                        raise ValueError(f"El precio unitario no puede ser negativo, recibido: {precio_u_v}")

                    imp_tipo_v = p_dict["impuesto_tipo"]
                    iva_u_v = round(precio_u_v * iva_pct, 4) if imp_tipo_v == "gravado" else 0.0
                    subtotal += round(precio_u_v * cant_v, 4)
                    iva_total += round(iva_u_v * cant_v, 4)

                total_usd = round(subtotal + iva_total, 2)
                total_ves = round(total_usd * tasa_ves, 2)
                total_cop = round(total_usd * tasa_cop, 2)

                # Procesar pagos recibidos
                total_pagado_usd = 0.0
                pagos_procesados = []
                for p in pagos:
                    moneda = (p.get("moneda") or "USD").upper()
                    metodo = p.get("metodo") or "Efectivo"
                    monto_moneda = float(p.get("monto_moneda", 0))
                    tasa_cambio = float(p.get("tasa_cambio") or 1.0)
                    referencia = p.get("referencia", "")

                    if moneda == "USD":
                        equiv_usd = monto_moneda
                    elif moneda in ("VES", "COP"):
                        equiv_usd = round(monto_moneda / tasa_cambio, 2) if tasa_cambio > 0 else 0.0
                    else:
                        equiv_usd = monto_moneda

                    if monto_moneda > 0:
                        total_pagado_usd += equiv_usd
                        pagos_procesados.append({
                            "moneda": moneda,
                            "metodo": metodo,
                            "monto_moneda": monto_moneda,
                            "tasa_cambio": tasa_cambio,
                            "equivalente_usd": round(equiv_usd, 2),
                            "referencia": referencia
                        })

                total_pagado_usd = round(total_pagado_usd, 2)

                if tipo_venta == "credito":
                    saldo_pendiente = max(0.0, round(total_usd - total_pagado_usd, 2))
                    estado_factura = "pagada" if saldo_pendiente <= 0.001 else "pendiente"
                else:
                    saldo_pendiente = 0.0
                    estado_factura = "pagada"

                # Generar número correlativo de factura protegido bajo BEGIN IMMEDIATE
                if numero_factura_input:
                    numero_factura = numero_factura_input
                else:
                    cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM facturas")
                    correlativo = cursor.fetchone()[0]
                    numero_factura = f"FAC-{correlativo:06d}"

                notas_final = notas
                if idempotency_key and f"[IDEMPOTENCY:{idempotency_key}]" not in notas_final:
                    notas_final = f"{notas_final} [IDEMPOTENCY:{idempotency_key}]".strip()

                cursor.execute("""
                    INSERT INTO facturas (numero_factura, cliente_id, subtotal, iva_total, total_usd, total, tasa_ves, tasa_cop, total_ves, total_cop, estado, tipo_venta, fecha_vencimiento, saldo_pendiente, notas, fecha)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (numero_factura, cliente_id, subtotal, iva_total, total_usd, total_usd, tasa_ves, tasa_cop, total_ves, total_cop, estado_factura, tipo_venta, fecha_vencimiento if tipo_venta == 'credito' else None, saldo_pendiente, notas_final, fecha_factura))
                factura_id = cursor.lastrowid

                # Procesamiento secuencial renglón por renglón con integración transaccional CPP
                for itm in items:
                    prod_id = itm.get("producto_id")
                    cant_dec = Decimal(str(itm.get("cantidad", 1)))

                    # Lectura atómica del estado del producto bajo BEGIN IMMEDIATE
                    cursor.execute("""
                        SELECT id, codigo, nombre, tipo, impuesto_tipo, precio_base, stock, costo, costo_cpp 
                        FROM productos WHERE id = ?
                    """, (prod_id,))
                    prod = dict(cursor.fetchone())

                    precio_unitario = float(itm.get("precio_unitario", prod["precio_base"]))
                    impuesto_tipo = prod["impuesto_tipo"]
                    tipo = prod["tipo"]

                    iva_u = round(precio_unitario * iva_pct, 4) if impuesto_tipo == "gravado" else 0.0
                    item_subtotal = round(precio_unitario * float(cant_dec), 4)
                    item_iva = round(iva_u * float(cant_dec), 4)
                    item_total = round(item_subtotal + item_iva, 4)

                    costo_u_val = None
                    costo_tot_val = None

                    # Si es producto físico, aplicar máquina de estados CPP, validar retroactividad y descontar stock
                    if tipo == "producto":
                        # Validar fecha retroactiva para este SKU
                        validar_movimiento_no_retroactivo(cursor, prod_id, fecha_factura)

                        stock_ant_dec = Decimal(str(prod.get("stock") or 0.0))
                        cpp_ant_val = prod.get("costo_cpp")

                        # 1. Bloqueo estricto ante stock físico negativo preexistente (Caso C)
                        if stock_ant_dec < Decimal("0"):
                            raise ErrorStockNegativo(
                                f"STOCK_NEGATIVO: Imposible operar con stock físico negativo ({stock_ant_dec}) en SKU {prod['codigo']}. Operación bloqueada."
                            )

                        # 2. Bloqueo estricto ante stock insuficiente (Caso B)
                        if cant_dec > stock_ant_dec:
                            raise ErrorStockNegativo(
                                f"STOCK_INSUFICIENTE: Salida solicitada ({cant_dec}) supera existencia disponible ({stock_ant_dec}) en SKU '{prod['nombre']}' ({prod['codigo']}). Stock < 0 prohibido."
                            )

                        # 3. Bloqueo estricto ante stock positivo con CPP inválido (Caso D)
                        if cpp_ant_val is None or Decimal(str(cpp_ant_val)) <= Decimal("0"):
                            raise ErrorInconsistenciaCPP(
                                f"INCONSISTENCIA_CPP: Producto {prod['codigo']} tiene stock positivo ({stock_ant_dec}) "
                                f"pero costo_cpp inválido ({cpp_ant_val}). Operación bloqueada. Prohibido usar productos.costo como sustituto."
                            )

                        # 4. Caso A: Stock suficiente y CPP válido -> Cálculo puro de salida CPP
                        cpp_dec = Decimal(str(cpp_ant_val))
                        nuevo_stk_dec = (stock_ant_dec - cant_dec).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                        costo_u_dec = cpp_dec.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                        costo_tot_dec = (cant_dec * cpp_dec).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

                        costo_u_val = float(costo_u_dec)
                        costo_tot_val = float(costo_tot_dec)

                        # Inserción en factura_detalles conservando copia documental congelada del costo
                        cursor.execute("""
                            INSERT INTO factura_detalles (factura_id, producto_id, nombre_producto, tipo, impuesto_tipo, cantidad, precio_unitario, iva_unitario, subtotal, total, costo_unitario, costo_total)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (factura_id, prod_id, prod["nombre"], tipo, impuesto_tipo, float(cant_dec), precio_unitario, iva_u, item_subtotal, item_total, costo_u_val, costo_tot_val))
                        factura_detalle_id = cursor.lastrowid

                        # Registrar movimiento inmutable en Libro Mayor con costo CPP de salida y documento_linea_id
                        registrar_movimiento_inventario(
                            cursor=cursor,
                            producto_id=prod_id,
                            fecha=fecha_factura,
                            tipo_movimiento="venta",
                            sentido="SALIDA",
                            cantidad=float(cant_dec),
                            costo_unitario=costo_u_val,
                            costo_total=costo_tot_val,
                            stock_anterior=float(stock_ant_dec),
                            stock_nuevo=float(nuevo_stk_dec),
                            documento_tipo="FACTURA",
                            documento_id=factura_id,
                            documento_numero=numero_factura,
                            motivo=f"Salida por venta según factura {numero_factura} (Línea {factura_detalle_id})",
                            usuario_id=1,
                            documento_linea_id=factura_detalle_id
                        )

                        # Actualización atómica de productos: stock descontado, costo_cpp permanece INVARIANTE
                        cursor.execute("""
                            UPDATE productos 
                            SET stock = ?
                            WHERE id = ?
                        """, (float(nuevo_stk_dec), prod_id))

                    else:
                        # Tipo servicio: no afecta stock ni costo ni libro mayor
                        cursor.execute("""
                            INSERT INTO factura_detalles (factura_id, producto_id, nombre_producto, tipo, impuesto_tipo, cantidad, precio_unitario, iva_unitario, subtotal, total, costo_unitario, costo_total)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (factura_id, prod_id, prod["nombre"], tipo, impuesto_tipo, float(cant_dec), precio_unitario, iva_u, item_subtotal, item_total, None, None))
                        factura_detalle_id = cursor.lastrowid

                # Guardar pagos iniciales de la factura
                for pp in pagos_procesados:
                    cursor.execute("""
                        INSERT INTO factura_pagos (factura_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (factura_id, pp["moneda"], pp["metodo"], pp["monto_moneda"], pp["tasa_cambio"], pp["equivalente_usd"], pp["referencia"]))

                cxc_id = None
                # Si es crédito, registrar en Cuentas por Cobrar
                if tipo_venta == "credito":
                    cxc_estado = "pagada" if saldo_pendiente <= 0.001 else ("parcial" if total_pagado_usd > 0 else "pendiente")
                    fecha_emision = fecha_factura

                    cursor.execute("""
                        INSERT INTO cuentas_por_cobrar (factura_id, cliente_id, monto_total, monto_pagado, saldo_pendiente, fecha_emision, fecha_vencimiento, estado, notas)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (factura_id, cliente_id, total_usd, total_pagado_usd, saldo_pendiente, fecha_emision, fecha_vencimiento, cxc_estado, notas_final))
                    cxc_id = cursor.lastrowid

                    if total_pagado_usd > 0 and pagos_procesados:
                        cursor.execute("""
                            INSERT INTO abonos_cxc (cxc_id, monto_usd, fecha, notas, estado)
                            VALUES (?, ?, ?, 'Anticipo / Pago inicial al momento de facturar', 'activo')
                        """, (cxc_id, round(total_pagado_usd, 2), fecha_emision))
                        ab_ini_id = cursor.lastrowid
                        for pp in pagos_procesados:
                            cursor.execute("""
                                INSERT INTO abono_cxc_pagos (abono_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                                VALUES (?, ?, ?, ?, ?, ?, ?)
                            """, (ab_ini_id, pp["moneda"], pp["metodo"], pp["monto_moneda"], pp["tasa_cambio"], pp["equivalente_usd"], pp["referencia"]))

                conn.commit()
                self.send_json({
                    "id": factura_id,
                    "numero_factura": numero_factura,
                    "total_usd": total_usd,
                    "total_ves": total_ves,
                    "total_cop": total_cop,
                    "tipo_venta": tipo_venta,
                    "fecha_vencimiento": fecha_vencimiento,
                    "saldo_pendiente": saldo_pendiente,
                    "cxc_id": cxc_id,
                    "success": True
                }, 201)

            # 6. Registrar Abono a Cuenta por Cobrar
            elif path.startswith("/api/cxc/") and path.endswith("/abonos"):
                parts = path.split("/")
                cxc_id = int(parts[3])
                pagos = body.get("pagos", [])
                notas = body.get("notas", "Abono a cuenta por cobrar")

                if not pagos or len(pagos) == 0:
                    self.send_error_json("Se requiere al menos una forma y monto de pago", 400)
                    return

                cursor.execute("SELECT * FROM cuentas_por_cobrar WHERE id = ?", (cxc_id,))
                cxc = cursor.fetchone()
                if not cxc:
                    self.send_error_json("Cuenta por cobrar no encontrada", 404)
                    return

                cxc_dict = dict(cxc)
                if cxc_dict.get("estado") == "anulada":
                    self.send_error_json("No se pueden registrar pagos sobre una cuenta por cobrar anulada", 400)
                    return
                if cxc_dict["saldo_pendiente"] <= 0.001:
                    self.send_error_json("Esta cuenta ya se encuentra totalmente saldada", 400)
                    return

                # Calcular total abono
                total_abono_usd = 0.0
                pagos_proc = []
                for p in pagos:
                    moneda = p.get("moneda", "USD").upper()
                    metodo = p.get("metodo", "Efectivo")
                    monto_moneda = float(p.get("monto_moneda", 0))
                    tasa_cambio = float(p.get("tasa_cambio", 1.0))
                    referencia = p.get("referencia", "")

                    if moneda == "USD":
                        equiv_usd = monto_moneda
                    elif moneda in ("VES", "COP"):
                        equiv_usd = round(monto_moneda / tasa_cambio, 2) if tasa_cambio > 0 else 0
                    else:
                        equiv_usd = monto_moneda

                    if monto_moneda > 0:
                        total_abono_usd += equiv_usd
                        pagos_proc.append({
                            "moneda": moneda,
                            "metodo": metodo,
                            "monto_moneda": monto_moneda,
                            "tasa_cambio": tasa_cambio,
                            "equivalente_usd": equiv_usd,
                            "referencia": referencia
                        })

                total_abono_usd = round(total_abono_usd, 2)
                if total_abono_usd <= 0:
                    conn.rollback()
                    self.send_error_json("El monto del pago debe ser mayor a 0", 400)
                    return

                if total_abono_usd > cxc_dict["saldo_pendiente"] + 0.05:
                    conn.rollback()
                    self.send_error_json(f"El monto a pagar (${total_abono_usd:.2f}) excede el saldo pendiente (${cxc_dict['saldo_pendiente']:.2f})", 400)
                    return

                # Registrar abono
                cursor.execute("""
                    INSERT INTO abonos_cxc (cxc_id, monto_usd, notas, estado)
                    VALUES (?, ?, ?, 'activo')
                """, (cxc_id, total_abono_usd, notas))
                abono_id = cursor.lastrowid

                # Registrar pagos del abono
                for pp in pagos_proc:
                    cursor.execute("""
                        INSERT INTO abono_cxc_pagos (abono_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (abono_id, pp["moneda"], pp["metodo"], pp["monto_moneda"], pp["tasa_cambio"], pp["equivalente_usd"], pp["referencia"]))

                # Actualizar saldo en CXC
                nuevo_monto_pagado = round(cxc_dict["monto_pagado"] + total_abono_usd, 2)
                nuevo_saldo = max(0.0, round(cxc_dict["saldo_pendiente"] - total_abono_usd, 2))
                nuevo_estado = "pagada" if nuevo_saldo <= 0.001 else "parcial"

                cursor.execute("""
                    UPDATE cuentas_por_cobrar
                    SET monto_pagado = ?, saldo_pendiente = ?, estado = ?
                    WHERE id = ?
                """, (nuevo_monto_pagado, nuevo_saldo, nuevo_estado, cxc_id))

                # Actualizar factura correspondiente (saldo y estado según saldo restante)
                nuevo_estado_factura = "pagada" if nuevo_saldo <= 0.001 else "pendiente"
                cursor.execute("""
                    UPDATE facturas
                    SET saldo_pendiente = ?, estado = ?
                    WHERE id = ?
                """, (nuevo_saldo, nuevo_estado_factura, cxc_dict["factura_id"]))

                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "abono_id": abono_id,
                    "monto_abono_usd": total_abono_usd,
                    "nuevo_saldo_pendiente": nuevo_saldo,
                    "nuevo_estado": nuevo_estado
                }, 201)

            # 6. Crear Compra (Integración Transaccional Motor CPP - FASE 2F-2B)
            elif path == "/api/compras":
                proveedor_id = body.get("proveedor_id")
                numero_control = body.get("numero_control", f"CMP-{int(time.time()) % 100000:05d}")
                foto_factura = body.get("foto_factura", "")
                items = body.get("items", [])
                notas = body.get("notas", "")
                numero_factura = body.get("numero_factura", numero_control)
                tipo_compra = body.get("tipo_compra", "contado")
                fecha_compra_input = body.get("fecha")

                if not proveedor_id or not items or len(items) == 0:
                    self.send_error_json("Se requiere un proveedor y al menos un ítem comprado", 400)
                    return

                cursor.execute("SELECT id FROM proveedores WHERE id = ?", (proveedor_id,))
                if not cursor.fetchone():
                    self.send_error_json(f"Proveedor ID {proveedor_id} no encontrado", 404)
                    return

                # Normalización de fecha de compra
                if fecha_compra_input and str(fecha_compra_input).strip():
                    f_str = str(fecha_compra_input).strip()
                    if len(f_str) == 10:
                        ahora_h = datetime.now().strftime("%H:%M:%S")
                        fecha_compra = f"{f_str} {ahora_h}"
                    else:
                        fecha_compra = f_str
                else:
                    fecha_compra = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # Idempotencia: Verificar si ya existe compra registrada con ese proveedor y factura/control
                if numero_factura:
                    cursor.execute("""
                        SELECT id, numero_control, total, tipo_compra, saldo_pendiente 
                        FROM compras 
                        WHERE proveedor_id = ? AND (numero_factura = ? OR numero_control = ?)
                        ORDER BY id DESC LIMIT 1
                    """, (proveedor_id, numero_factura, numero_control))
                    compra_existente = cursor.fetchone()
                    if compra_existente:
                        self.send_error_json(
                            f"IDEMPOTENCIA: Ya existe una compra registrada con la factura/control '{numero_factura}' para este proveedor (Compra ID {compra_existente['id']}).",
                            409
                        )
                        return

                # BEGIN IMMEDIATE: Candado exclusivo para aislar lecturas y escrituras de stock y CPP
                cursor.execute("BEGIN IMMEDIATE")

                cursor.execute("SELECT iva_porcentaje FROM configuracion WHERE id = 1")
                iva_pct = cursor.fetchone()[0] / 100.0

                subtotal = 0.0
                iva_total = 0.0

                # Pre-validar ítems y calcular totales financieros
                for itm in items:
                    cant_v = float(itm.get("cantidad", 1))
                    costo_u_v = float(itm.get("costo_unitario", 0))
                    if cant_v <= 0:
                        raise ValueError(f"La cantidad comprada debe ser mayor a 0, recibido: {cant_v}")
                    if costo_u_v < 0:
                        raise ValueError(f"El costo unitario no puede ser negativo, recibido: {costo_u_v}")
                    imp_tipo_v = itm.get("impuesto_tipo", "gravado")
                    iva_u_v = round(costo_u_v * iva_pct, 4) if imp_tipo_v == "gravado" else 0.0
                    subtotal += round(costo_u_v * cant_v, 4)
                    iva_total += round(iva_u_v * cant_v, 4)

                total = round(subtotal + iva_total, 2)
                fecha_vencimiento = body.get("fecha_vencimiento")
                if tipo_compra == "credito" and not fecha_vencimiento:
                    fecha_vencimiento = (datetime.now() + timedelta(days=15)).strftime("%Y-%m-%d")

                pagos = body.get("pagos", [])
                total_pagado_usd = 0.0
                pagos_procesados = []
                for p in pagos:
                    mon = (p.get("moneda") or "USD").upper()
                    met = p.get("metodo") or "Efectivo"
                    m_m = float(p.get("monto_moneda", 0))
                    t_c = float(p.get("tasa_cambio") or 1.0)
                    if mon == "USD":
                        eq = m_m
                    elif mon in ("VES", "COP"):
                        eq = round(m_m / t_c, 2) if t_c > 0 else 0.0
                    else:
                        eq = m_m
                    if m_m > 0:
                        total_pagado_usd += eq
                        pagos_procesados.append({
                            "moneda": mon,
                            "metodo": met,
                            "monto_moneda": m_m,
                            "tasa_cambio": t_c,
                            "equivalente_usd": round(eq, 2),
                            "referencia": p.get("referencia", "")
                        })

                total_pagado_usd = round(total_pagado_usd, 2)
                if tipo_compra == "credito":
                    saldo_pendiente = max(0.0, round(total - total_pagado_usd, 2))
                else:
                    saldo_pendiente = 0.0

                # Inserción atómica de la cabecera de compra
                cursor.execute("""
                    INSERT INTO compras (numero_control, proveedor_id, foto_factura, subtotal, iva_total, total, tipo_compra, fecha_vencimiento, saldo_pendiente, numero_factura, notas)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (numero_control, proveedor_id, foto_factura, subtotal, iva_total, total, tipo_compra, fecha_vencimiento if tipo_compra == 'credito' else None, saldo_pendiente, numero_factura, notas))
                compra_id = cursor.lastrowid

                # Procesamiento secuencial renglón por renglón con integración transaccional CPP
                for itm in items:
                    prod_id = itm.get("producto_id")
                    cant = float(itm.get("cantidad", 1))
                    costo_unitario = float(itm.get("costo_unitario", 0))
                    impuesto_tipo = itm.get("impuesto_tipo", "gravado")

                    # Si el producto debe crearse al vuelo (crear_nuevo = true)
                    if not prod_id or itm.get("crear_nuevo") is True:
                        nombre_nuevo = itm.get("nombre", "").strip()
                        cat_id = itm.get("categoria_id")
                        precio_venta = float(itm.get("precio_venta", costo_unitario * 1.3))
                        tipo = itm.get("tipo", "producto")

                        if not cat_id:
                            cursor.execute("SELECT id FROM categorias WHERE tipo = 'producto' LIMIT 1")
                            cat_row = cursor.fetchone()
                            cat_id = cat_row[0] if cat_row else 1

                        codigo_nuevo = f"PRD-{int(time.time() * 100) % 1000000:06d}"
                        iva_v = round(precio_venta * iva_pct, 4) if impuesto_tipo == "gravado" else 0.0

                        cursor.execute("""
                            INSERT INTO productos (codigo, nombre, categoria_id, tipo, impuesto_tipo, precio_base, iva_monto, precio_total, costo, costo_cpp, stock, stock_minimo)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 5)
                        """, (codigo_nuevo, nombre_nuevo, cat_id, tipo, impuesto_tipo, precio_venta, iva_v, round(precio_venta + iva_v, 4), costo_unitario, costo_unitario))
                        prod_id = cursor.lastrowid

                    # Lectura atómica del estado del producto bajo el candado BEGIN IMMEDIATE
                    cursor.execute("SELECT id, codigo, nombre, tipo, stock, costo, costo_cpp FROM productos WHERE id = ?", (prod_id,))
                    prod = dict(cursor.fetchone())

                    # IVA de la línea
                    iva_u = round(costo_unitario * iva_pct, 4) if impuesto_tipo == "gravado" else 0.0
                    item_total = round((costo_unitario + iva_u) * cant, 4)

                    # Inserción en compra_detalles (permite obtener compra_detalle_id único para trazabilidad)
                    cursor.execute("""
                        INSERT INTO compra_detalles (compra_id, producto_id, nombre_producto, cantidad, costo_unitario, impuesto_tipo, iva_unitario, total)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (compra_id, prod_id, prod["nombre"], cant, costo_unitario, impuesto_tipo, iva_u, item_total))
                    compra_detalle_id = cursor.lastrowid

                    # Si es producto físico, calcular CPP y asentar en libro mayor
                    if prod["tipo"] == "producto":
                        # Validar fecha retroactiva para este SKU
                        validar_movimiento_no_retroactivo(cursor, prod_id, fecha_compra)

                        stock_ant_dec = Decimal(str(prod.get("stock") or 0.0))
                        cpp_ant_val = prod.get("costo_cpp")
                        cant_dec = Decimal(str(cant))
                        costo_u_dec = Decimal(str(costo_unitario))

                        # 1. Bloqueo estricto ante stock físico negativo preexistente
                        if stock_ant_dec < Decimal("0"):
                            raise ErrorStockNegativo(
                                f"STOCK_NEGATIVO: Imposible operar con stock físico negativo ({stock_ant_dec}) en SKU {prod['codigo']}. Operación bloqueada."
                            )

                        # 2. Máquina de estados para cálculo de CPP
                        if stock_ant_dec == Decimal("0"):
                            # Stock cero: costo de entrada se establece como CPP inicial
                            nuevo_cpp_dec = costo_u_dec.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                            nuevo_stk_dec = cant_dec.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                        else:
                            # Stock positivo: validar que tenga costo_cpp válido
                            if cpp_ant_val is None or Decimal(str(cpp_ant_val)) <= Decimal("0"):
                                raise ErrorInconsistenciaCPP(
                                    f"INCONSISTENCIA_CPP: Producto {prod['codigo']} tiene stock positivo ({stock_ant_dec}) "
                                    f"pero costo_cpp inválido ({cpp_ant_val}). Operación bloqueada. Prohibido usar productos.costo como sustituto."
                                )
                            cpp_calc_res = calcular_cpp_entrada(
                                stock_anterior=stock_ant_dec,
                                cpp_anterior=Decimal(str(cpp_ant_val)),
                                cantidad_entrada=cant_dec,
                                costo_entrada=costo_u_dec
                            )
                            nuevo_cpp_dec = Decimal(str(cpp_calc_res["cpp_nuevo"]))
                            nuevo_stk_dec = Decimal(str(cpp_calc_res["stock_nuevo"]))

                        # Registrar movimiento inmutable en Libro Mayor con costo real de entrada y documento_linea_id
                        registrar_movimiento_inventario(
                            cursor=cursor,
                            producto_id=prod_id,
                            fecha=fecha_compra,
                            tipo_movimiento="compra",
                            sentido="ENTRADA",
                            cantidad=float(cant_dec),
                            costo_unitario=float(costo_u_dec), # COSTO REAL DE ENTRADA (NO CPP)
                            costo_total=float((cant_dec * costo_u_dec).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)),
                            stock_anterior=float(stock_ant_dec),
                            stock_nuevo=float(nuevo_stk_dec),
                            documento_tipo="COMPRA",
                            documento_id=compra_id,
                            documento_numero=numero_factura or numero_control,
                            motivo=f"Entrada por compra #{numero_factura or numero_control} (Línea {compra_detalle_id})",
                            usuario_id=1,
                            documento_linea_id=compra_detalle_id
                        )

                        # Actualización atómica de productos: stock, costo (último costo adquisición), costo_cpp (promedio ponderado)
                        cursor.execute("""
                            UPDATE productos 
                            SET stock = ?, costo = ?, costo_cpp = ?
                            WHERE id = ?
                        """, (float(nuevo_stk_dec), float(costo_u_dec), float(nuevo_cpp_dec), prod_id))

                # Registrar pagos iniciales si aplican
                for pp in pagos_procesados:
                    cursor.execute("""
                        INSERT INTO compra_pagos (compra_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (compra_id, pp["moneda"], pp["metodo"], pp["monto_moneda"], pp["tasa_cambio"], pp["equivalente_usd"], pp["referencia"]))

                # Registrar en Cuentas por Pagar (CXP) si aplica crédito con saldo pendiente
                if tipo_compra == "credito" and saldo_pendiente > 0.001:
                    cxp_estado = "parcial" if total_pagado_usd > 0 else "pendiente"
                    fecha_emision = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    cursor.execute("""
                        INSERT INTO cuentas_por_pagar (compra_id, proveedor_id, descripcion_concepto, numero_factura, monto_total, monto_pagado, saldo_pendiente, fecha_emision, fecha_vencimiento, estado, tipo_registro, notas)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'compra', ?)
                    """, (compra_id, proveedor_id, f"Compra Factura #{numero_control}", numero_factura, total, total_pagado_usd, saldo_pendiente, fecha_emision, fecha_vencimiento, cxp_estado, notas))
                    cxp_id_new = cursor.lastrowid

                    if total_pagado_usd > 0 and pagos_procesados:
                        cursor.execute("""
                            INSERT INTO abonos_cxp (cxp_id, monto_usd, fecha, notas, estado)
                            VALUES (?, ?, ?, 'Anticipo / Pago inicial en compra', 'activo')
                        """, (cxp_id_new, round(total_pagado_usd, 2), fecha_emision))
                        ab_cxp_ini_id = cursor.lastrowid
                        for pp in pagos_procesados:
                            cursor.execute("""
                                INSERT INTO abono_cxp_pagos (abono_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                                VALUES (?, ?, ?, ?, ?, ?, ?)
                            """, (ab_cxp_ini_id, pp["moneda"], pp["metodo"], pp["monto_moneda"], pp["tasa_cambio"], pp["equivalente_usd"], pp["referencia"]))

                conn.commit()
                self.send_json({
                    "id": compra_id,
                    "numero_control": numero_control,
                    "total": total,
                    "tipo_compra": tipo_compra,
                    "saldo_pendiente": saldo_pendiente,
                    "success": True
                }, 201)

            # 7. Registrar Saldo o Gasto Directo a Proveedor (Sin afectar inventario)
            elif path == "/api/cxp/directo":
                proveedor_id = body.get("proveedor_id")
                descripcion_concepto = (body.get("descripcion_concepto") or "").strip()
                numero_factura = (body.get("numero_factura") or "").strip()
                numero_control = (body.get("numero_control") or "").strip()
                impuesto_tipo = (body.get("impuesto_tipo") or "exento").strip().lower()
                if impuesto_tipo not in ("gravado", "exento"):
                    impuesto_tipo = "exento"

                afecta_libro = 1 if body.get("afecta_libro_compras") in (1, "1", True, "true") else 0
                if afecta_libro and not numero_factura:
                    self.send_error_json("El N° de Factura / Control es obligatorio para gastos que afectan el Libro de Compras", 400)
                    return

                if not numero_factura:
                    numero_factura = f"DIR-{int(time.time()) % 100000:05d}"

                monto_total = float(body.get("monto_total", 0.0))
                base_imponible_usd = float(body.get("base_imponible_usd", monto_total if impuesto_tipo == "exento" else (monto_total / 1.16)))
                iva_usd = float(body.get("iva_usd", 0.0 if impuesto_tipo == "exento" else (monto_total - base_imponible_usd)))

                # Tasas oficiales BCV para libros fiscales
                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg = cursor.fetchone()
                tasa_bcv = float(cfg["tasa_ves"]) if cfg else 45.0
                base_imponible_ves = round(base_imponible_usd * tasa_bcv, 2)
                iva_ves = round(iva_usd * tasa_bcv, 2)
                total_ves = round(monto_total * tasa_bcv, 2)

                fecha_emision = body.get("fecha_emision") or datetime.now().strftime("%Y-%m-%d")
                fecha_vencimiento = body.get("fecha_vencimiento") or (datetime.now() + timedelta(days=15)).strftime("%Y-%m-%d")
                notas = body.get("notas", "")

                if not proveedor_id or not descripcion_concepto or monto_total <= 0:
                    self.send_error_json("Se requiere un proveedor, concepto/descripción y monto mayor a 0", 400)
                    return

                cursor.execute("""
                    INSERT INTO cuentas_por_pagar (
                        compra_id, proveedor_id, descripcion_concepto, numero_factura, numero_control,
                        impuesto_tipo, base_imponible_usd, iva_usd, tasa_bcv,
                        base_imponible_ves, iva_ves, total_ves, afecta_libro_compras,
                        monto_total, monto_pagado, saldo_pendiente, fecha_emision, fecha_vencimiento, estado, tipo_registro, notas
                    ) VALUES (
                        NULL, ?, ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, ?, ?, ?,
                        ?, 0.0, ?, ?, ?, 'pendiente', 'directo', ?
                    )
                """, (
                    proveedor_id, descripcion_concepto, numero_factura, numero_control,
                    impuesto_tipo, base_imponible_usd, iva_usd, tasa_bcv,
                    base_imponible_ves, iva_ves, total_ves, afecta_libro,
                    monto_total, monto_total, fecha_emision, fecha_vencimiento, notas
                ))
                cxp_id = cursor.lastrowid
                conn.commit()

                self.send_json({
                    "id": cxp_id,
                    "success": True,
                    "monto_total_usd": monto_total,
                    "total_ves": total_ves,
                    "afecta_libro_compras": afecta_libro,
                    "message": "Gasto / Saldo directo a pagar registrado exitosamente"
                }, 201)

            # 8. Registrar Abono o Pago a Cuenta por Pagar (Multimoneda)
            elif path.startswith("/api/cxp/") and path.endswith("/abonos"):
                cxp_id = int(path.split("/")[3])
                pagos = body.get("pagos", [])
                notas = body.get("notas", "")
                monto_usd = float(body.get("monto_usd", 0.0))

                if monto_usd <= 0 and pagos:
                    for p in pagos:
                        tasa = float(p.get("tasa_cambio") or 1.0)
                        monto_m = float(p.get("monto_moneda", 0.0))
                        eq = float(p.get("equivalente_usd") or (monto_m / tasa if p.get("moneda") != "USD" else monto_m))
                        monto_usd += eq
                    monto_usd = round(monto_usd, 2)

                if monto_usd <= 0:
                    self.send_error_json("El monto del abono debe ser mayor a 0", 400)
                    return

                cursor.execute("SELECT * FROM cuentas_por_pagar WHERE id = ?", (cxp_id,))
                cxp = cursor.fetchone()
                if not cxp:
                    self.send_error_json("Cuenta por pagar no encontrada", 404)
                    return
                cxp_dict = dict(cxp)
                if cxp_dict.get("estado") == "anulada":
                    self.send_error_json("No se pueden registrar pagos sobre una cuenta por pagar anulada", 400)
                    return
                if cxp_dict["saldo_pendiente"] <= 0.001:
                    self.send_error_json("Esta cuenta por pagar ya se encuentra totalmente saldada", 400)
                    return

                if monto_usd > cxp_dict["saldo_pendiente"] + 0.05:
                    self.send_error_json(f"El monto a pagar (${monto_usd:.2f}) excede el saldo pendiente (${cxp_dict['saldo_pendiente']:.2f})", 400)
                    return

                cursor.execute("""
                    INSERT INTO abonos_cxp (cxp_id, monto_usd, notas, estado)
                    VALUES (?, ?, ?, 'activo')
                """, (cxp_id, monto_usd, notas))
                abono_id = cursor.lastrowid

                for p in pagos:
                    tasa = float(p.get("tasa_cambio") or 1.0)
                    monto_m = float(p.get("monto_moneda", 0.0))
                    eq = float(p.get("equivalente_usd") or (monto_m / tasa if p.get("moneda") != "USD" else monto_m))
                    cursor.execute("""
                        INSERT INTO abono_cxp_pagos (abono_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (abono_id, p["moneda"], p["metodo"], monto_m, tasa, round(eq, 2), p.get("referencia", "")))

                nuevo_monto_pagado = round(cxp_dict["monto_pagado"] + monto_usd, 2)
                nuevo_saldo = max(0.0, round(cxp_dict["monto_total"] - nuevo_monto_pagado, 2))
                nuevo_estado = "pagada" if nuevo_saldo <= 0.01 else "parcial"

                cursor.execute("""
                    UPDATE cuentas_por_pagar
                    SET monto_pagado = ?, saldo_pendiente = ?, estado = ?
                    WHERE id = ?
                """, (nuevo_monto_pagado, nuevo_saldo, nuevo_estado, cxp_id))

                if cxp_dict.get("compra_id"):
                    cursor.execute("""
                        UPDATE compras
                        SET saldo_pendiente = ?
                        WHERE id = ?
                    """, (nuevo_saldo, cxp_dict["compra_id"]))

                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "abono_id": abono_id,
                    "monto_abono_usd": monto_usd,
                    "nuevo_saldo_pendiente": nuevo_saldo,
                    "nuevo_estado": nuevo_estado
                }, 201)

            # 9. Sincronización Automática de Tasas Oficiales (BCV & TRM)
            elif path == "/api/tasas/actualizar-auto":
                ves, cop, fuente, err = obtener_tasas_oficiales()
                
                # Obtener valores actuales por si alguna falló
                cursor.execute("SELECT tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
                cfg_curr = cursor.fetchone()
                curr_ves = cfg_curr[0] if cfg_curr else 45.0
                curr_cop = cfg_curr[1] if cfg_curr else 4100.0

                if ves is None and cop is None:
                    self.send_error_json(f"No se pudo consultar ninguna tasa oficial: {err}", 502)
                    return

                final_ves = ves if ves is not None else curr_ves
                final_cop = cop if cop is not None else curr_cop
                ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                cursor.execute("""
                    UPDATE configuracion 
                    SET tasa_ves = ?, tasa_cop = ?, fecha_tasas_actualizacion = ?, fuente_tasas = ?
                    WHERE id = 1
                """, (final_ves, final_cop, ahora, fuente))
                conn.commit()

                self.send_json({
                    "success": True,
                    "tasa_ves": final_ves,
                    "tasa_cop": final_cop,
                    "fecha_tasas_actualizacion": ahora,
                    "fuente_tasas": fuente,
                    "message": "Tasas oficiales de BCV y TRM sincronizadas correctamente"
                })

            # Toggle de Sincronización Automática con Páginas Oficiales
            elif path == "/api/tasas/toggle-auto":
                nuevo_modo = 1 if body.get("sincronizacion_tasas_auto", True) else 0
                cursor.execute("""
                    UPDATE configuracion 
                    SET sincronizacion_tasas_auto = ?
                    WHERE id = 1
                """, (nuevo_modo,))
                conn.commit()
                self.send_json({
                    "success": True,
                    "sincronizacion_tasas_auto": nuevo_modo,
                    "message": "Sincronización automática activada (BCV/TRM)" if nuevo_modo == 1 else "Sincronización automática desactivada (Modo Manual)"
                })

            # Guardar Tasas de Cambio Manualmente
            elif path == "/api/tasas/manual":
                tasa_ves = float(body.get("tasa_ves", 45.0))
                tasa_cop = float(body.get("tasa_cop", 4100.0))
                # 0 para desactivar sincronización automática al guardar manual, o según lo enviado
                desactivar_auto = 0 if body.get("apagar_auto", True) else 1
                ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                fuente = body.get("fuente", "Manual (Personalizado)")

                cursor.execute("""
                    UPDATE configuracion 
                    SET tasa_ves = ?, tasa_cop = ?, sincronizacion_tasas_auto = ?, 
                        fecha_tasas_actualizacion = ?, fuente_tasas = ?
                    WHERE id = 1
                """, (tasa_ves, tasa_cop, desactivar_auto, ahora, fuente))
                conn.commit()

                self.send_json({
                    "success": True,
                    "tasa_ves": tasa_ves,
                    "tasa_cop": tasa_cop,
                    "sincronizacion_tasas_auto": desactivar_auto,
                    "fecha_tasas_actualizacion": ahora,
                    "fuente_tasas": fuente,
                    "message": "Tasas manuales guardadas correctamente."
                })

            # 9. Guardar Personalización Visual y Textos (Temas, Colores y Nombres)
            elif path == "/api/config/personalizacion":
                tema = body.get("tema_config") or body.get("tema")
                labels = body.get("labels_config") or body.get("labels")

                tema_str = json.dumps(tema, ensure_ascii=False) if tema is not None else None
                labels_str = json.dumps(labels, ensure_ascii=False) if labels is not None else None

                cursor.execute("""
                    UPDATE configuracion 
                    SET tema_config = ?, labels_config = ?, tema = ?, labels = ?
                    WHERE id = 1
                """, (tema_str, labels_str, tema_str, labels_str))
                conn.commit()
                schedule_cloud_sync()

                self.send_json({
                    "success": True,
                    "message": "Personalización guardada exitosamente"
                })

            # 10. Restablecer Personalización a Valores de Fábrica
            elif path == "/api/config/personalizacion/reset":
                cursor.execute("""
                    UPDATE configuracion 
                    SET tema_config = NULL, labels_config = NULL, tema = NULL, labels = NULL
                    WHERE id = 1
                """)
                conn.commit()
                schedule_cloud_sync()

                self.send_json({
                    "success": True,
                    "message": "Personalización restablecida a valores originales"
                })


            # REGISTRAR DEVOLUCIÓN DE COMPRA A PROVEEDOR (NOTA DE DÉBITO)
            elif path == "/api/devoluciones-compras":
                cursor.execute("BEGIN IMMEDIATE")
                try:
                    res = procesar_devolucion_compra(cursor, body)
                    conn.commit()
                    schedule_cloud_sync()
                    self.send_json(res)
                except Exception as e:
                    conn.rollback()
                    self.send_error_json(str(e), 400)

            # ANULAR DEVOLUCIÓN DE COMPRA
            elif path.startswith("/api/devoluciones-compras/") and path.endswith("/anular"):
                parts = path.split("/")
                dev_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulación de devolución").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                cursor.execute("BEGIN IMMEDIATE")
                try:
                    res = anular_devolucion_compra(cursor, dev_id, motivo=motivo, usuario_id=usuario_id)
                    conn.commit()
                    schedule_cloud_sync()
                    self.send_json(res)
                except Exception as e:
                    conn.rollback()
                    self.send_error_json(str(e), 400)

            # 11. Registrar Devolución (Retorno de ítems al inventario, reversión de ventas y ajuste de CXC) - FASE 2F-4B CPP

            elif path == "/api/devoluciones":
                factura_id = body.get("factura_id")
                cliente_id = body.get("cliente_id")
                motivo = (body.get("motivo") or "").strip() or "Devolución de mercancía / solicitud de cliente"
                tipo_devolucion_input = (body.get("tipo_devolucion") or "").strip().lower()
                metodo_reembolso = (body.get("metodo_reembolso") or "efectivo").strip().lower()
                items = body.get("items", [])
                pagos_reembolso = body.get("pagos_reembolso") or body.get("pagos") or []
                notas = (body.get("notas") or "").strip()
                fecha_devolucion_input = body.get("fecha") or body.get("fecha_emision")
                numero_devolucion_input = (body.get("numero_devolucion") or "").strip()
                idempotency_key = (body.get("idempotency_key") or body.get("client_tx_id") or "").strip()

                if not items or len(items) == 0:
                    self.send_error_json("La devolución debe contener al menos un ítem", 400)
                    return

                # Normalización de fecha de devolución
                if fecha_devolucion_input and str(fecha_devolucion_input).strip():
                    f_str = str(fecha_devolucion_input).strip()
                    if len(f_str) == 10:
                        ahora_h = datetime.now().strftime("%H:%M:%S")
                        fecha_devolucion = f"{f_str} {ahora_h}"
                    else:
                        fecha_devolucion = f_str
                else:
                    fecha_devolucion = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                # Idempotencia: Verificar si ya existe devolución con ese número o clave de idempotencia
                if numero_devolucion_input:
                    cursor.execute("""
                        SELECT id, numero_devolucion, total_usd 
                        FROM devoluciones 
                        WHERE numero_devolucion = ?
                    """, (numero_devolucion_input,))
                    dev_existente = cursor.fetchone()
                    if dev_existente:
                        self.send_error_json(
                            f"IDEMPOTENCIA: Ya existe una devolución registrada con el número '{numero_devolucion_input}' (Devolución ID {dev_existente['id']}). Operación rechazada.",
                            409
                        )
                        return

                if idempotency_key:
                    cursor.execute("""
                        SELECT id, numero_devolucion, total_usd 
                        FROM devoluciones 
                        WHERE notas LIKE ?
                    """, (f"%[IDEMPOTENCY:{idempotency_key}]%",))
                    dev_idem = cursor.fetchone()
                    if dev_idem:
                        self.send_error_json(
                            f"IDEMPOTENCIA: La transacción con clave '{idempotency_key}' ya fue procesada (Devolución {dev_idem['numero_devolucion']} ID {dev_idem['id']}). Operación rechazada.",
                            409
                        )
                        return

                # BEGIN IMMEDIATE: Candado exclusivo para aislar lecturas y escrituras de stock, costos y CPP
                cursor.execute("BEGIN IMMEDIATE")

                # Si viene factura_id, obtener datos de la factura
                factura_dict = None
                if factura_id:
                    cursor.execute("SELECT * FROM facturas WHERE id = ?", (factura_id,))
                    fact_row = cursor.fetchone()
                    if not fact_row:
                        self.send_error_json(f"Factura ID {factura_id} no encontrada", 404)
                        return
                    factura_dict = dict(fact_row)
                    if not cliente_id:
                        cliente_id = factura_dict["cliente_id"]

                # Obtener datos del cliente
                if not cliente_id:
                    self.send_error_json("Se requiere un cliente para procesar la devolución", 400)
                    return

                cursor.execute("SELECT * FROM clientes WHERE id = ?", (cliente_id,))
                cli_row = cursor.fetchone()
                if not cli_row:
                    self.send_error_json("Cliente no encontrado", 404)
                    return
                cli_dict = dict(cli_row)

                # Obtener configuración de tasas e IVA
                cursor.execute("SELECT * FROM configuracion WHERE id = 1")
                cfg_row = cursor.fetchone()
                tasa_ves = cfg_row["tasa_ves"] if cfg_row else 45.0
                tasa_cop = cfg_row["tasa_cop"] if cfg_row else 4100.0
                iva_pct = (cfg_row["iva_porcentaje"] / 100.0) if cfg_row else 0.16

                # Generar número correlativo DEV-000001 bajo BEGIN IMMEDIATE
                if numero_devolucion_input:
                    numero_devolucion = numero_devolucion_input
                else:
                    cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM devoluciones")
                    correlativo = cursor.fetchone()[0]
                    numero_devolucion = f"DEV-{correlativo:06d}"

                notas_final = notas
                if idempotency_key and f"[IDEMPOTENCY:{idempotency_key}]" not in notas_final:
                    notas_final = f"{notas_final} [IDEMPOTENCY:{idempotency_key}]".strip()

                # Pre-validación y resolución de cada ítem de devolución
                subtotal_dev = 0.0
                iva_dev = 0.0
                detalles_proc = []
                cantidades_acumuladas_por_factura_detalle = {}

                for itm in items:
                    cant_dec = Decimal(str(itm.get("cantidad", 0)))
                    if cant_dec <= Decimal("0"):
                        raise ValueError(f"La cantidad a devolver debe ser mayor a 0, recibido: {cant_dec}")

                    prod_id = itm.get("producto_id")
                    factura_det_id = itm.get("factura_detalle_id")

                    if factura_id:
                        if factura_det_id:
                            cursor.execute("SELECT * FROM factura_detalles WHERE id = ? AND factura_id = ?", (factura_det_id, factura_id))
                            fd_row = cursor.fetchone()
                            if not fd_row:
                                raise ValueError(f"La línea de factura {factura_det_id} no pertenece a la factura {factura_id}")
                            fd = dict(fd_row)
                            if prod_id and fd["producto_id"] and fd["producto_id"] != prod_id:
                                raise ValueError(f"El producto_id {prod_id} no coincide con el ítem de la factura {fd['producto_id']}")
                            prod_id = fd["producto_id"]
                        else:
                            # Buscar en factura_detalles
                            if prod_id:
                                cursor.execute("SELECT * FROM factura_detalles WHERE factura_id = ? AND producto_id = ?", (factura_id, prod_id))
                            else:
                                nom_busca = itm.get("nombre") or itm.get("nombre_producto") or ""
                                cursor.execute("SELECT * FROM factura_detalles WHERE factura_id = ? AND nombre_producto = ?", (factura_id, nom_busca))
                            matching_lines = [dict(r) for r in cursor.fetchall()]
                            if not matching_lines:
                                raise ValueError(f"No se encontró el ítem en los detalles de la factura {factura_id}")
                            if len(matching_lines) == 1:
                                fd = matching_lines[0]
                                factura_det_id = fd["id"]
                                prod_id = fd["producto_id"]
                            else:
                                # SKU repetido en factura: elegir la línea con cantidad disponible suficiente
                                chosen = None
                                for candidate in matching_lines:
                                    c_id = candidate["id"]
                                    cursor.execute("SELECT COALESCE(SUM(cantidad), 0) FROM devolucion_detalles WHERE factura_detalle_id = ?", (c_id,))
                                    devuelto_prev = Decimal(str(cursor.fetchone()[0]))
                                    devuelto_batch = cantidades_acumuladas_por_factura_detalle.get(c_id, Decimal("0"))
                                    disp = Decimal(str(candidate["cantidad"])) - devuelto_prev - devuelto_batch
                                    if disp >= cant_dec:
                                        chosen = candidate
                                        break
                                if chosen is None:
                                    raise ErrorCantidadDevolucionExcedeDisponible(
                                        f"CANTIDAD_EXCEDIDA: No hay suficiente cantidad disponible para devolver en las líneas del SKU en factura {factura_id}. "
                                        "Especifique factura_detalle_id si desea devolver sobre un renglón particular."
                                    )
                                fd = chosen
                                factura_det_id = fd["id"]
                                prod_id = fd["producto_id"]

                        # Validar límite de cantidad a devolver en la línea
                        cursor.execute("SELECT COALESCE(SUM(cantidad), 0) FROM devolucion_detalles WHERE factura_detalle_id = ?", (factura_det_id,))
                        devuelto_prev = Decimal(str(cursor.fetchone()[0]))
                        devuelto_batch = cantidades_acumuladas_por_factura_detalle.get(factura_det_id, Decimal("0"))
                        cant_orig = Decimal(str(fd["cantidad"]))
                        disponible = cant_orig - devuelto_prev - devuelto_batch

                        if cant_dec > disponible:
                            raise ErrorCantidadDevolucionExcedeDisponible(
                                f"CANTIDAD_EXCEDIDA: La cantidad a devolver ({cant_dec}) supera la cantidad disponible ({disponible}) "
                                f"para el renglón {factura_det_id} de la factura {factura_id}."
                            )

                        cantidades_acumuladas_por_factura_detalle[factura_det_id] = devuelto_batch + cant_dec

                        tipo_itm = fd["tipo"]
                        nombre_itm = fd["nombre_producto"]
                        imp_tipo = fd["impuesto_tipo"]
                        p_unit = float(itm.get("precio_unitario", fd["precio_unitario"]))
                        codigo_itm = itm.get("codigo", "")
                    else:
                        tipo_itm = itm.get("tipo", "producto")
                        if tipo_itm != "servicio":
                            raise ErrorCostoHistoricoNoRecuperable("Se requiere una factura válida para procesar la devolución de productos físicos")
                        factura_det_id = None
                        p_unit = float(itm.get("precio_unitario", 0.0))
                        imp_tipo = itm.get("impuesto_tipo", "exento")
                        nombre_itm = itm.get("nombre") or itm.get("nombre_producto") or "Servicio"
                        codigo_itm = itm.get("codigo", "")

                    sub_itm = round(float(cant_dec) * p_unit, 4)
                    iva_itm = round(sub_itm * iva_pct, 4) if imp_tipo == "gravado" else 0.0
                    tot_itm = round(sub_itm + iva_itm, 4)

                    subtotal_dev += sub_itm
                    iva_dev += iva_itm

                    # Recuperación de costo histórico original para productos físicos
                    costo_u_dev = None
                    costo_tot_dev = None
                    costo_hist_dec = None

                    if tipo_itm == "producto" and prod_id:
                        # 1. Fuente primaria: factura_detalles.costo_unitario
                        if fd and fd.get("costo_unitario") is not None and float(fd["costo_unitario"]) > 0:
                            costo_hist_dec = Decimal(str(fd["costo_unitario"]))

                        # 2. Fuente secundaria: inventario_movimientos
                        if costo_hist_dec is None and factura_id:
                            cursor.execute("""
                                SELECT costo_unitario FROM inventario_movimientos
                                WHERE documento_tipo = 'FACTURA' AND documento_id = ? AND producto_id = ?
                                  AND (documento_linea_id = ? OR documento_linea_id IS NULL)
                                  AND costo_unitario > 0
                                ORDER BY id DESC LIMIT 1
                            """, (factura_id, prod_id, factura_det_id))
                            mov_c = cursor.fetchone()
                            if mov_c and mov_c[0] is not None and float(mov_c[0]) > 0:
                                costo_hist_dec = Decimal(str(mov_c[0]))

                        # Bloqueo estricto: Prohibición absoluta de fallback
                        if costo_hist_dec is None or costo_hist_dec <= Decimal("0"):
                            raise ErrorCostoHistoricoNoRecuperable(
                                f"COSTO_HISTORICO_NO_RECUPERABLE: Imposible recuperar el costo histórico original de la venta "
                                f"para el producto ID {prod_id} en la factura ID {factura_id}. "
                                "Operación bloqueada. Prohibido usar costo de catálogo o CPP actual como fallback."
                            )

                        costo_u_dev = float(costo_hist_dec.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))
                        costo_tot_dev = float((cant_dec * costo_hist_dec).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))

                    detalles_proc.append({
                        "producto_id": prod_id,
                        "factura_detalle_id": factura_det_id,
                        "codigo": codigo_itm,
                        "nombre": nombre_itm,
                        "tipo": tipo_itm,
                        "impuesto_tipo": imp_tipo,
                        "cantidad": float(cant_dec),
                        "cant_dec": cant_dec,
                        "precio_unitario": p_unit,
                        "iva_unitario": round(iva_itm / float(cant_dec), 4) if float(cant_dec) > 0 else 0.0,
                        "subtotal": sub_itm,
                        "total": tot_itm,
                        "costo_unitario": costo_u_dev,
                        "costo_total": costo_tot_dev,
                        "costo_hist_dec": costo_hist_dec
                    })

                total_usd = round(subtotal_dev + iva_dev, 2)
                subtotal_usd = round(subtotal_dev, 2)
                iva_usd = round(iva_dev, 2)
                total_ves = round(total_usd * tasa_ves, 2)
                total_cop = round(total_usd * tasa_cop, 2)

                num_fact = factura_dict["numero_factura"] if factura_dict else None
                fecha_fact_orig = factura_dict["fecha"] if factura_dict else None
                tipo_venta_orig = factura_dict.get("tipo_venta", "contado") if factura_dict else "contado"

                # Evaluar si la devolución resulta en devolución total o parcial
                totalmente_devuelta = False
                if factura_id and factura_dict:
                    cursor.execute("""
                        SELECT fd.id, fd.cantidad, COALESCE(SUM(dd.cantidad), 0) as devuelta
                        FROM factura_detalles fd
                        LEFT JOIN devolucion_detalles dd ON dd.factura_detalle_id = fd.id
                        WHERE fd.factura_id = ?
                        GROUP BY fd.id
                    """, (factura_id,))
                    line_status = cursor.fetchall()
                    totalmente_devuelta = len(line_status) > 0 and all(
                        (Decimal(str(ls["cantidad"])) - Decimal(str(ls["devuelta"])) - cantidades_acumuladas_por_factura_detalle.get(ls["id"], Decimal("0"))) <= Decimal("0.0001")
                        for ls in line_status
                    )

                if totalmente_devuelta:
                    tipo_devolucion = "total"
                elif tipo_devolucion_input in ("total", "parcial"):
                    tipo_devolucion = tipo_devolucion_input
                else:
                    tipo_devolucion = "parcial"

                # 1. Insertar cabecera de devolución
                cursor.execute("""
                    INSERT INTO devoluciones (
                        numero_devolucion, factura_id, numero_factura, cliente_id,
                        cliente_nombre, cliente_cedula, cliente_telefono, cliente_direccion,
                        fecha_emision, fecha_factura_original, tipo_devolucion, tipo_venta_original,
                        motivo, subtotal_usd, iva_usd, total_usd,
                        tasa_ves, tasa_cop, total_ves, total_cop,
                        metodo_reembolso, notas
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    numero_devolucion, factura_id, num_fact, cliente_id,
                    cli_dict["nombre"], cli_dict.get("cedula", ""), cli_dict.get("telefono", ""), cli_dict.get("direccion", ""),
                    fecha_devolucion, fecha_fact_orig, tipo_devolucion, tipo_venta_orig,
                    motivo, subtotal_usd, iva_usd, total_usd,
                    tasa_ves, tasa_cop, total_ves, total_cop,
                    metodo_reembolso, notas_final
                ))
                dev_id = cursor.lastrowid

                # 2. Insertar detalles y procesar inventario bajo motor CPP
                for d in detalles_proc:
                    cursor.execute("""
                        INSERT INTO devolucion_detalles (
                            devolucion_id, factura_detalle_id, producto_id, codigo, nombre_producto, tipo,
                            impuesto_tipo, cantidad, precio_unitario, iva_unitario, subtotal, total,
                            costo_unitario, costo_total
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        dev_id, d["factura_detalle_id"], d["producto_id"], d["codigo"], d["nombre"], d["tipo"],
                        d["impuesto_tipo"], d["cantidad"], d["precio_unitario"], d["iva_unitario"], d["subtotal"], d["total"],
                        d["costo_unitario"], d["costo_total"]
                    ))
                    dev_detalle_id = cursor.lastrowid
                    d["id"] = dev_detalle_id

                    # Si es producto físico, aplicar máquina de 4 estados CPP, validar retroactividad y reintegrar stock
                    if d["tipo"] == "producto" and d["producto_id"]:
                        prod_id = d["producto_id"]
                        cant_dec = d["cant_dec"]
                        costo_hist = d["costo_hist_dec"]

                        # Validar fecha retroactiva para este SKU
                        validar_movimiento_no_retroactivo(cursor, prod_id, fecha_devolucion)

                        # Lectura atómica del estado del producto
                        cursor.execute("SELECT id, codigo, nombre, stock, costo_cpp FROM productos WHERE id = ?", (prod_id,))
                        p_row = dict(cursor.fetchone())
                        stk_ant = Decimal(str(p_row.get("stock") or 0.0))
                        cpp_ant_val = p_row.get("costo_cpp")

                        # Estado 1: Stock anterior negativo -> Bloqueo estricto
                        if stk_ant < Decimal("0"):
                            raise ErrorStockNegativo(
                                f"STOCK_NEGATIVO: Imposible operar con stock físico negativo ({stk_ant}) en SKU {p_row['codigo']}. Operación bloqueada."
                            )

                        # Estado 2: Stock anterior == 0 -> Inicio limpio: nuevo CPP = costo histórico de la devolución
                        if stk_ant == Decimal("0"):
                            nuevo_cpp = costo_hist.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                            nuevo_stk = cant_dec.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)
                        else:
                            # Estado 4: Stock > 0 pero CPP inválido -> Bloqueo estricto
                            if cpp_ant_val is None or Decimal(str(cpp_ant_val)) <= Decimal("0"):
                                raise ErrorInconsistenciaCPP(
                                    f"INCONSISTENCIA_CPP: Producto {p_row['codigo']} tiene stock positivo ({stk_ant}) "
                                    f"pero costo_cpp inválido ({cpp_ant_val}). Operación bloqueada. Prohibido usar productos.costo como sustituto."
                                )
                            # Estado 3: Stock > 0 y CPP válido -> Recálculo puro de CPP entrada ponderada
                            cpp_ant = Decimal(str(cpp_ant_val))
                            res_cpp = calcular_cpp_entrada(stk_ant, cpp_ant, cant_dec, costo_hist)
                            nuevo_stk = Decimal(str(res_cpp["stock_nuevo"]))
                            nuevo_cpp = Decimal(str(res_cpp["cpp_nuevo"]))

                        # Actualización atómica de productos: stock y costo_cpp actualizados
                        cursor.execute("""
                            UPDATE productos
                            SET stock = ?, costo_cpp = ?
                            WHERE id = ?
                        """, (float(nuevo_stk), float(nuevo_cpp), prod_id))

                        # Registro oficial en Libro Mayor de Inventario con documento_linea_id = devolucion_detalle_id
                        registrar_movimiento_inventario(
                            cursor=cursor,
                            producto_id=prod_id,
                            fecha=fecha_devolucion,
                            tipo_movimiento="devolucion_cliente",
                            sentido="ENTRADA",
                            cantidad=float(cant_dec),
                            costo_unitario=d["costo_unitario"],
                            costo_total=d["costo_total"],
                            stock_anterior=float(stk_ant),
                            stock_nuevo=float(nuevo_stk),
                            documento_tipo="DEVOLUCION",
                            documento_id=dev_id,
                            documento_numero=numero_devolucion,
                            motivo=f"Entrada por devolución de cliente {numero_devolucion} (Factura {num_fact}, Línea {d['factura_detalle_id']})",
                            usuario_id=1,
                            documento_linea_id=dev_detalle_id
                        )

                # 3. Registrar pagos de reembolso si se especificaron
                for p in pagos_reembolso:
                    mon = (p.get("moneda") or "USD").upper()
                    met = p.get("metodo", metodo_reembolso)
                    m_m = float(p.get("monto_moneda", 0))
                    t_c = float(p.get("tasa_cambio") or (tasa_ves if mon == "VES" else (tasa_cop if mon == "COP" else 1.0)))
                    eq = float(p.get("equivalente_usd") or (m_m / t_c if mon != "USD" else m_m))
                    cursor.execute("""
                        INSERT INTO devolucion_pagos (devolucion_id, moneda, metodo, monto_moneda, tasa_cambio, equivalente_usd, referencia)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (dev_id, mon, met, m_m, t_c, round(eq, 2), p.get("referencia", "")))

                # 4. Ajustar saldo de factura y Cuentas por Cobrar (CXC)
                totalmente_devuelta = False
                if factura_id and factura_dict:
                    # Verificar si todos los renglones de la factura han sido completamente devueltos
                    cursor.execute("""
                        SELECT fd.id, fd.cantidad, COALESCE(SUM(dd.cantidad), 0) as devuelta
                        FROM factura_detalles fd
                        LEFT JOIN devolucion_detalles dd ON dd.factura_detalle_id = fd.id
                        WHERE fd.factura_id = ?
                        GROUP BY fd.id
                    """, (factura_id,))
                    line_status = cursor.fetchall()
                    totalmente_devuelta = len(line_status) > 0 and all(
                        (Decimal(str(ls["cantidad"])) - Decimal(str(ls["devuelta"]))) <= Decimal("0.0001")
                        for ls in line_status
                    )

                    if factura_dict.get("tipo_venta") == "credito":
                        cursor.execute("SELECT * FROM cuentas_por_cobrar WHERE factura_id = ?", (factura_id,))
                        cxc_row = cursor.fetchone()
                        if cxc_row:
                            cxc_d = dict(cxc_row)
                            nuevo_saldo_cxc = max(0.0, round(cxc_d["saldo_pendiente"] - total_usd, 2))
                            nuevo_estado_cxc = "pagada" if nuevo_saldo_cxc <= 0.01 else "parcial"
                            cursor.execute("""
                                UPDATE cuentas_por_cobrar
                                SET saldo_pendiente = ?, estado = ?, notas = coalesce(notas, '') || ' [Devolución ' || ? || ' por $' || ? || ']'
                                WHERE id = ?
                            """, (nuevo_saldo_cxc, nuevo_estado_cxc, numero_devolucion, total_usd, cxc_d["id"]))

                            nuevo_estado_fact = "pagada" if nuevo_saldo_cxc <= 0.001 else "pendiente"
                            cursor.execute("""
                                UPDATE facturas
                                SET saldo_pendiente = ?, estado = ?
                                WHERE id = ?
                            """, (nuevo_saldo_cxc, nuevo_estado_fact, factura_id))

                    if totalmente_devuelta or tipo_devolucion == "total":
                        cursor.execute("""
                            UPDATE facturas
                            SET estado = 'anulada', notas = coalesce(notas, '') || ' [ANULADA por Devolución Total ' || ? || ']'
                            WHERE id = ?
                        """, (numero_devolucion, factura_id))
                    else:
                        cursor.execute("""
                            UPDATE facturas
                            SET notas = coalesce(notas, '') || ' [Devolución Parcial ' || ? || ' por $' || ? || ']'
                            WHERE id = ?
                        """, (numero_devolucion, total_usd, factura_id))

                conn.commit()

                self.send_json({
                    "success": True,
                    "id": dev_id,
                    "devolucion_id": dev_id,
                    "numero_devolucion": numero_devolucion,
                    "total_usd": total_usd,
                    "total_ves": total_ves,
                    "total_cop": total_cop,
                    "tipo_devolucion": "total" if totalmente_devuelta or tipo_devolucion == "total" else "parcial",
                    "detalles": [
                        {
                            "id": d["id"],
                            "factura_detalle_id": d["factura_detalle_id"],
                            "producto_id": d["producto_id"],
                            "cantidad": d["cantidad"],
                            "costo_unitario": d["costo_unitario"],
                            "costo_total": d["costo_total"]
                        } for d in detalles_proc
                    ],
                    "message": f"Devolución {numero_devolucion} procesada exitosamente. Las cantidades fueron reintegradas al inventario."
                }, 201)
                        # 9. Registrar Nota de Ajuste Comercial (Crédito o Débito en CXC y CXP)
            elif path == "/api/notas-ajuste":
                modulo = (body.get("modulo") or "").strip().lower()
                if modulo not in ("cxc", "cxp"):
                    self.send_error_json("El campo 'modulo' debe ser 'cxc' o 'cxp'", 400)
                    return

                tercero_id = int(body.get("tercero_id") or 0)
                if tercero_id <= 0:
                    self.send_error_json("Se requiere un cliente_id o proveedor_id válido ('tercero_id')", 400)
                    return

                cuenta_id = body.get("cuenta_id")
                cuenta_id = int(cuenta_id) if cuenta_id else None

                tipo_nota = (body.get("tipo_nota") or "").strip().lower()
                if tipo_nota not in ("credito", "debito"):
                    self.send_error_json("tipo_nota debe ser 'credito' o 'debito'", 400)
                    return

                efecto = (body.get("efecto") or "").strip().lower()
                if efecto not in ("disminuye", "incrementa"):
                    # Por defecto natural: credito disminuye saldo, debito incrementa saldo
                    efecto = "disminuye" if tipo_nota == "credito" else "incrementa"

                monto_usd = float(body.get("monto_usd", 0.0))
                if monto_usd <= 0:
                    self.send_error_json("El monto de la nota debe ser mayor a 0", 400)
                    return

                motivo = (body.get("motivo") or "").strip()
                if not motivo:
                    self.send_error_json("El motivo o justificación de la nota es obligatorio", 400)
                    return

                fecha_nota = body.get("fecha") or datetime.now().strftime("%Y-%m-%d")
                numero_control = (body.get("numero_control") or "").strip()
                afecta_libro = 1 if body.get("afecta_libro_fiscal") in (1, "1", True, "true") else 0
                usuario_id = int(body.get("usuario_id") or 1)

                cursor.execute("SELECT tasa_ves FROM configuracion WHERE id = 1")
                cfg = cursor.fetchone()
                tasa_bcv = float(cfg["tasa_ves"]) if cfg else 45.0
                monto_ves = round(monto_usd * tasa_bcv, 2)

                cursor.execute("BEGIN IMMEDIATE")

                # Generar consecutivo si no fue provisto
                prefijo = "NC" if tipo_nota == "credito" else "ND"
                cursor.execute("SELECT COALESCE(MAX(id), 0) + 1 FROM notas_ajuste_comercial")
                next_nid = cursor.fetchone()[0]
                numero_nota = (body.get("numero_nota") or "").strip() or f"{prefijo}-{next_nid:06d}"

                # Aplicar efecto sobre la cuenta específica
                if cuenta_id:
                    if modulo == "cxc":
                        cursor.execute("SELECT * FROM cuentas_por_cobrar WHERE id = ?", (cuenta_id,))
                        cxc_row = cursor.fetchone()
                        if not cxc_row:
                            self.send_error_json(f"Cuenta por cobrar ID {cuenta_id} no encontrada", 404)
                            return
                        cxc = dict(cxc_row)
                        if efecto == "disminuye":
                            nuevo_pagado = round(float(cxc["monto_pagado"]) + monto_usd, 2)
                            nuevo_saldo = max(0.0, round(float(cxc["monto_total"]) - nuevo_pagado, 2))
                            nuevo_estado = "pagada" if nuevo_saldo <= 0.001 else "parcial"
                            cursor.execute("""
                                UPDATE cuentas_por_cobrar
                                SET monto_pagado = ?, saldo_pendiente = ?, estado = ?
                                WHERE id = ?
                            """, (nuevo_pagado, nuevo_saldo, nuevo_estado, cuenta_id))
                            if cxc.get("factura_id"):
                                cursor.execute("UPDATE facturas SET saldo_pendiente = ? WHERE id = ?", (nuevo_saldo, cxc["factura_id"]))
                        else:
                            # incrementa saldo
                            nuevo_total = round(float(cxc["monto_total"]) + monto_usd, 2)
                            nuevo_saldo = round(float(cxc["saldo_pendiente"]) + monto_usd, 2)
                            nuevo_estado = "pendiente" if cxc["estado"] == "pagada" else cxc["estado"]
                            cursor.execute("""
                                UPDATE cuentas_por_cobrar
                                SET monto_total = ?, saldo_pendiente = ?, estado = ?
                                WHERE id = ?
                            """, (nuevo_total, nuevo_saldo, nuevo_estado, cuenta_id))
                            if cxc.get("factura_id"):
                                cursor.execute("UPDATE facturas SET total_usd = ?, saldo_pendiente = ? WHERE id = ?", (nuevo_total, nuevo_saldo, cxc["factura_id"]))

                    elif modulo == "cxp":
                        cursor.execute("SELECT * FROM cuentas_por_pagar WHERE id = ?", (cuenta_id,))
                        cxp_row = cursor.fetchone()
                        if not cxp_row:
                            self.send_error_json(f"Cuenta por pagar ID {cuenta_id} no encontrada", 404)
                            return
                        cxp = dict(cxp_row)
                        if efecto == "disminuye":
                            nuevo_pagado = round(float(cxp["monto_pagado"]) + monto_usd, 2)
                            nuevo_saldo = max(0.0, round(float(cxp["monto_total"]) - nuevo_pagado, 2))
                            nuevo_estado = "pagada" if nuevo_saldo <= 0.001 else "parcial"
                            cursor.execute("""
                                UPDATE cuentas_por_pagar
                                SET monto_pagado = ?, saldo_pendiente = ?, estado = ?
                                WHERE id = ?
                            """, (nuevo_pagado, nuevo_saldo, nuevo_estado, cuenta_id))
                            if cxp.get("compra_id"):
                                cursor.execute("UPDATE compras SET saldo_pendiente = ? WHERE id = ?", (nuevo_saldo, cxp["compra_id"]))
                        else:
                            # incrementa saldo
                            nuevo_total = round(float(cxp["monto_total"]) + monto_usd, 2)
                            nuevo_saldo = round(float(cxp["saldo_pendiente"]) + monto_usd, 2)
                            nuevo_estado = "pendiente" if cxp["estado"] == "pagada" else cxp["estado"]
                            cursor.execute("""
                                UPDATE cuentas_por_pagar
                                SET monto_total = ?, saldo_pendiente = ?, estado = ?
                                WHERE id = ?
                            """, (nuevo_total, nuevo_saldo, nuevo_estado, cuenta_id))
                            if cxp.get("compra_id"):
                                cursor.execute("UPDATE compras SET total = ?, saldo_pendiente = ? WHERE id = ?", (nuevo_total, nuevo_saldo, cxp["compra_id"]))

                cursor.execute("""
                    INSERT INTO notas_ajuste_comercial (
                        modulo, tercero_id, cuenta_id, tipo_nota, numero_nota, fecha,
                        monto_usd, tasa_bcv, monto_ves, efecto, motivo, numero_control, afecta_libro_fiscal, usuario_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    modulo, tercero_id, cuenta_id, tipo_nota, numero_nota, fecha_nota,
                    monto_usd, tasa_bcv, monto_ves, efecto, motivo, numero_control, afecta_libro, usuario_id
                ))
                nota_id = cursor.lastrowid
                conn.commit()

                self.send_json({
                    "id": nota_id,
                    "success": True,
                    "numero_nota": numero_nota,
                    "tipo_nota": tipo_nota,
                    "efecto": efecto,
                    "monto_usd": monto_usd,
                    "monto_ves": monto_ves,
                    "message": f"Nota de {tipo_nota.capitalize()} {numero_nota} aplicada exitosamente ({efecto} saldo)"
                }, 201)

            # 11. Ajustes de Inventario (FASE 2C / FASE 2F-5B CPP: Cargos y Descargos Transaccionales)
            elif path in ("/api/inventario/ajustes", "/api/inventario/cargos", "/api/inventario/descargos"):
                payload_aj = dict(body)
                if path == "/api/inventario/cargos":
                    payload_aj["tipo_ajuste"] = "CARGO"
                elif path == "/api/inventario/descargos":
                    payload_aj["tipo_ajuste"] = "DESCARGO"

                res = procesar_ajuste_inventario_cpp(
                    cursor=cursor,
                    payload=payload_aj,
                    conn=conn,
                    auto_commit=True
                )

                if res.get("duplicado_ignorado"):
                    self.send_json(res, 200)
                    return

                # Sincronizacion asincrona segura
                schedule_cloud_sync()
                self.send_json(res, 201)
                return

            # Anulación Directa LIFO de Ajuste de Inventario (FASE 2F-5B)
            elif path.startswith("/api/inventario/ajustes/") and path.endswith("/anular"):
                parts = path.split("/")
                try:
                    aj_id = int(parts[4])
                except (IndexError, ValueError):
                    self.send_error_json("ID de ajuste inválido", 400)
                    return
                motivo = (body.get("motivo") or "Anulación directa de ajuste de inventario").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_ajuste_inventario(
                    cursor=cursor,
                    ajuste_id=aj_id,
                    motivo=motivo,
                    usuario_id=usuario_id,
                    conn=conn,
                    auto_commit=True
                )
                schedule_cloud_sync()
                self.send_json(res, 200)
                return

            # --- ENDPOINTS TRANSACCIONALES DE ANULACIÓN (FASE 4) ---

            # Anulación de Factura de Venta
            elif path.startswith("/api/facturas/") and path.endswith("/anular"):
                parts = path.split("/")
                f_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulación de factura").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_factura_venta(cursor, f_id, motivo=motivo, usuario_id=usuario_id)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Factura #{res.get('numero_factura')} anulada exitosamente. Stock reintegrado al inventario.",
                    "data": res
                })
                return

            # Anulación de Devolución de Cliente
            elif path.startswith("/api/devoluciones/") and path.endswith("/anular"):
                parts = path.split("/")
                d_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulación de devolución").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_devolucion_cliente(cursor, d_id, motivo=motivo, usuario_id=usuario_id)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Devolución #{res.get('numero_devolucion')} anulada exitosamente. Stock retirado del inventario.",
                    "data": res
                })
                return

            # Anulación de Compra de Proveedor
            elif path.startswith("/api/compras/") and path.endswith("/anular"):
                parts = path.split("/")
                c_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulación de compra").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_compra_proveedor(cursor, c_id, motivo=motivo, usuario_id=usuario_id)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Compra #{res.get('numero_control')} anulada exitosamente. Stock retirado y cuenta por pagar cancelada.",
                    "data": res
                })
                return

            # Anulación de Cobro / Abono en CXC
            elif path.startswith("/api/cxc/abonos/") and path.endswith("/anular"):
                parts = path.split("/")
                ab_id = int(parts[4])
                motivo = (body.get("motivo") or "Anulación de cobro a cliente").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                cxc_id_exp = body.get("cxc_id")
                res = anular_abono_cxc(cursor, ab_id, motivo=motivo, usuario_id=usuario_id, cxc_id_explicit=cxc_id_exp)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Pago de ${res['monto_reintegrado_usd']:.2f} USD anulado exitosamente. Saldo deudor restituido a ${res['nuevo_saldo_pendiente']:.2f}.",
                    "data": res
                })
                return

            # Anulación de Pago / Abono en CXP
            elif path.startswith("/api/cxp/abonos/") and path.endswith("/anular"):
                parts = path.split("/")
                ab_id = int(parts[4])
                motivo = (body.get("motivo") or "Anulación de pago a proveedor").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                cxp_id_exp = body.get("cxp_id")
                res = anular_abono_cxp(cursor, ab_id, motivo=motivo, usuario_id=usuario_id, cxp_id_explicit=cxp_id_exp)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Pago de ${res['monto_reintegrado_usd']:.2f} USD anulado exitosamente. Deuda con proveedor restituida a ${res['nuevo_saldo_pendiente']:.2f}.",
                    "data": res
                })
                return

            # Anulación de Cuenta por Pagar Directa (Gasto / Factura Directa)
            elif path.startswith("/api/cxp/") and path.endswith("/anular") and not path.startswith("/api/cxp/abonos/"):
                parts = path.split("/")
                cxp_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulación de cuenta por pagar").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_cuenta_cxp_directa(cursor, cxp_id, motivo=motivo, usuario_id=usuario_id)
                conn.commit()
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Cuenta por pagar #{cxp_id} anulada exitosamente.",
                    "data": res
                })
                return

            # --- FASE 2F-6C: MODELO FINANCIERO & TESORERÍA (POST) ---
            elif path == "/api/pagos":
                res = registrar_pago_financiero(body, conn=conn)
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Pago {res['numero_pago']} procesado exitosamente por ${res['monto_total_equivalente_usd']:.2f} USD.",
                    "data": res
                }, status=201)
                return

            elif path.startswith("/api/pagos/") and path.endswith("/anular"):
                parts = path.split("/")
                pago_id = int(parts[3])
                motivo = (body.get("motivo") or "Anulacin de pago financiero").strip()
                usuario_id = int(body.get("usuario_id") or 1)
                res = anular_pago_financiero(pago_id, usuario_id=usuario_id, motivo=motivo, conn=conn)
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Pago #{pago_id} anulado exitosamente.",
                    "data": res
                })
                return

            elif path == "/api/anticipos/aplicar":
                anticipo_id = int(body.get("anticipo_id"))
                aplicaciones = body.get("aplicaciones", [])
                usuario_id = int(body.get("usuario_id") or 1)
                res = aplicar_anticipo_cliente(anticipo_id, aplicaciones, usuario_id=usuario_id, conn=conn)
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Anticipo #{anticipo_id} aplicado exitosamente. Saldo disponible: ${res['saldo_restante_usd']:.2f} USD.",
                    "data": res
                })
                return

            elif path == "/api/tesoreria/cajas/apertura":
                cuenta_id = int(body.get("cuenta_tesoreria_id"))
                usuario_id = int(body.get("usuario_id") or 1)
                monto_usd = float(body.get("monto_inicial_usd") or 0.0)
                monto_mon = float(body.get("monto_inicial_moneda") or 0.0)
                notas = (body.get("notas") or body.get("notas_apertura") or "").strip()
                res = abrir_caja_turno(cuenta_id, usuario_id=usuario_id, monto_inicial_usd=monto_usd, monto_inicial_moneda=monto_mon, notas=notas, conn=conn)
                self.send_json({
                    "success": True,
                    "message": f"Turno de caja #{res['id']} abierto exitosamente.",
                    "data": res
                }, status=201)
                return

            elif path == "/api/tesoreria/cajas/cierre":
                apertura_id = int(body.get("caja_apertura_id"))
                usuario_id = int(body.get("usuario_id") or 1)
                saldo_usd = float(body.get("saldo_real_fisico_usd") or 0.0)
                saldo_mon = float(body.get("saldo_real_fisico_moneda") or 0.0)
                notas = (body.get("notas") or body.get("notas_cierre") or "").strip()
                res = cerrar_caja_turno(apertura_id, usuario_id=usuario_id, saldo_real_fisico_usd=saldo_usd, saldo_real_fisico_moneda=saldo_mon, notas=notas, conn=conn)
                self.send_json({
                    "success": True,
                    "message": f"Cierre de caja #{res['id']} completado. Arqueo: {res['estado_arqueo']} (Diferencia: ${res['diferencia_usd']:.2f} USD).",
                    "data": res
                })
                return

            elif path == "/api/tesoreria/transferencias":
                origen_id = int(body.get("cuenta_origen_id"))
                destino_id = int(body.get("cuenta_destino_id"))
                monto_origen = float(body.get("monto_origen") or 0.0)
                monto_destino = float(body.get("monto_destino") or 0.0)
                tasa = float(body.get("tasa_cambio") or 1.0)
                usuario_id = int(body.get("usuario_id") or 1)
                notas = (body.get("notas") or "").strip()
                res = transferir_entre_cuentas_tesoreria(origen_id, destino_id, monto_origen, monto_destino, tasa, usuario_id=usuario_id, notas=notas, conn=conn)
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Transferencia de tesorera completada exitosamente.",
                    "data": res
                })
                return

            elif path == "/api/gastos":
                usuario_id = int(body.get("usuario_id") or 1)
                res = registrar_gasto_operativo(body, usuario_id=usuario_id, conn=conn)
                schedule_cloud_sync()
                self.send_json({
                    "success": True,
                    "message": f"Gasto operativo {res['numero_gasto']} registrado exitosamente.",
                    "data": res
                }, status=201)
                return

            # --- FASE 3A: SIMULADOR DE IMPACTO DE PRECIOS CON IA ORGÁNICA ---
            elif path == "/api/ia/inventario/simular-precio":
                prod_id = int(body.get("producto_id"))
                nuevo_precio = float(body.get("nuevo_precio") or body.get("nuevo_precio_usd") or 0.0)
                sim = simular_impacto_precio(prod_id, nuevo_precio, conn=conn)
                self.send_json(sim)
                return

            # --- FASE 3B: CFO COPILOT GERENCIAL - CONSULTA CONVERSACIONAL ---
            elif path == "/api/ia/copilot/consulta":
                pregunta = (body.get("pregunta") or body.get("mensaje") or body.get("query") or "").strip()
                if not pregunta:
                    self.send_error_json("Debe ingresar una pregunta o consulta gerencial.", 400)
                    return
                resp = cfo_copilot.procesar_consulta_gerencial(pregunta, conn=conn)
                self.send_json(resp)
                return

            else:
                self.send_error_json("Endpoint no reconocido", 404)

        except LookupError as le:
            conn.rollback()
            self.send_error_json(str(le), 404)
        except (ErrorStockNegativo, ErrorMovimientoRetroactivoNoPermitido, ErrorInconsistenciaCPP,
                ErrorCostoHistoricoNoRecuperable, ErrorCantidadDevolucionExcedeDisponible,
                ErrorAnulacionAjusteConMovimientosPosteriores, ValueError) as ve:
            conn.rollback()
            self.send_error_json(str(ve), 400)
        except sqlite3.IntegrityError as ie:
            conn.rollback()
            self.send_error_json(f"Error de integridad: {str(ie)}", 400)
        except Exception as e:
            conn.rollback()
            self.send_error_json(str(e), 500)
        finally:
            conn.close()

    # ==========================================
    # CONTROLADORES DE LA API (PUT)
    # ==========================================
    def handle_api_put(self, path):
        body = self.parse_body_json()
        if body is None:
            self.send_error_json("Formato JSON inválido", 400)
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:
            # 1. Configuración & Tasas
            if path == "/api/config":
                auto_sync = int(body.get("sincronizacion_tasas_auto", 1)) if "sincronizacion_tasas_auto" in body else None
                if auto_sync is not None:
                    cursor.execute("""
                        UPDATE configuracion 
                        SET nombre_negocio = ?, documento_fiscal = ?, telefono = ?, direccion = ?, 
                            iva_porcentaje = ?, tasa_ves = ?, tasa_cop = ?, sincronizacion_tasas_auto = ?
                        WHERE id = 1
                    """, (
                        body.get("nombre_negocio"),
                        body.get("documento_fiscal"),
                        body.get("telefono"),
                        body.get("direccion"),
                        float(body.get("iva_porcentaje", 16.0)),
                        float(body.get("tasa_ves", 45.0)),
                        float(body.get("tasa_cop", 4100.0)),
                        auto_sync
                    ))
                else:
                    cursor.execute("""
                        UPDATE configuracion 
                        SET nombre_negocio = ?, documento_fiscal = ?, telefono = ?, direccion = ?, 
                            iva_porcentaje = ?, tasa_ves = ?, tasa_cop = ?
                        WHERE id = 1
                    """, (
                        body.get("nombre_negocio"),
                        body.get("documento_fiscal"),
                        body.get("telefono"),
                        body.get("direccion"),
                        float(body.get("iva_porcentaje", 16.0)),
                        float(body.get("tasa_ves", 45.0)),
                        float(body.get("tasa_cop", 4100.0))
                    ))
                conn.commit()
                self.send_json({"success": True, "message": "Configuración y tasas actualizadas correctamente"})

            # 2. Actualizar Producto / Servicio
            elif path.startswith("/api/productos/"):
                p_id = int(path.split("/")[-1])
                precio_base = float(body.get("precio_base", 0.0))
                impuesto_tipo = body.get("impuesto_tipo", "gravado")
                tipo = body.get("tipo", "producto")
                stock = float(body.get("stock", 0.0))
                if tipo == 'servicio':
                    stock = 0.0

                cursor.execute("SELECT iva_porcentaje FROM configuracion WHERE id = 1")
                iva_pct = cursor.fetchone()[0] / 100.0

                iva_monto = round(precio_base * iva_pct, 4) if impuesto_tipo == 'gravado' else 0.0
                precio_total = round(precio_base + iva_monto, 4)

                # FASE 2C: El stock NO debe poder modificarse directamente mediante PUT /api/productos/:id.
                # El stock es una cantidad materializada calculada exclusivamente por movimientos de inventario.
                # Se excluye 'stock' del UPDATE para neutralizar modificaciones directas arbitrarias.
                cursor.execute("""
                    UPDATE productos 
                    SET codigo = ?, nombre = ?, categoria_id = ?, tipo = ?, impuesto_tipo = ?,
                        precio_base = ?, iva_monto = ?, precio_total = ?, costo = ?, 
                        stock_minimo = ?, imagen = ?, descripcion = ?
                    WHERE id = ?
                """, (
                    body.get("codigo"),
                    body.get("nombre"),
                    body.get("categoria_id"),
                    tipo,
                    impuesto_tipo,
                    precio_base,
                    iva_monto,
                    precio_total,
                    float(body.get("costo", 0.0)),
                    float(body.get("stock_minimo", 5.0)),
                    body.get("imagen", ""),
                    body.get("descripcion", ""),
                    p_id
                ))
                conn.commit()
                self.send_json({"success": True, "message": "Producto actualizado"})

            # 3. Actualizar Categoría
            elif path.startswith("/api/categorias/"):
                c_id = int(path.split("/")[-1])
                cursor.execute("""
                    UPDATE categorias 
                    SET nombre = ?, tipo = ?, descripcion = ?
                    WHERE id = ?
                """, (body.get("nombre"), body.get("tipo"), body.get("descripcion"), c_id))
                conn.commit()
                self.send_json({"success": True})

            # 4. Actualizar Cliente
            elif path.startswith("/api/clientes/"):
                c_id = int(path.split("/")[-1])
                cursor.execute("""
                    UPDATE clientes 
                    SET nombre = ?, cedula = ?, telefono = ?, correo = ?, direccion = ?
                    WHERE id = ?
                """, (body.get("nombre"), body.get("cedula"), body.get("telefono"), body.get("correo"), body.get("direccion"), c_id))
                conn.commit()
                self.send_json({"success": True})

            # 5. Actualizar Proveedor
            elif path.startswith("/api/proveedores/"):
                pr_id = int(path.split("/")[-1])
                cursor.execute("""
                    UPDATE proveedores 
                    SET nombre = ?, cedula = ?, telefono = ?, correo = ?, direccion = ?
                    WHERE id = ?
                """, (body.get("nombre"), body.get("cedula"), body.get("telefono"), body.get("correo"), body.get("direccion"), pr_id))
                conn.commit()
                self.send_json({"success": True})

            else:
                self.send_error_json("Endpoint no reconocido", 404)

        except Exception as e:
            conn.rollback()
            self.send_error_json(str(e), 500)
        finally:
            conn.close()

    # ==========================================
    # CONTROLADORES DE LA API (DELETE)
    # ==========================================
    def handle_api_delete(self, path):
        conn = get_connection()
        cursor = conn.cursor()

        try:
            if path.startswith("/api/productos/"):
                p_id = int(path.split("/")[-1])
                # Marcar inactivo para mantener integridad de facturas históricas
                cursor.execute("UPDATE productos SET activo = 0 WHERE id = ?", (p_id,))
                conn.commit()
                self.send_json({"success": True, "message": "Producto desactivado correctamente"})

            elif path.startswith("/api/categorias/"):
                c_id = int(path.split("/")[-1])
                # Verificar si tiene productos asociados
                cursor.execute("SELECT COUNT(*) FROM productos WHERE categoria_id = ? AND activo = 1", (c_id,))
                count = cursor.fetchone()[0]
                if count > 0:
                    self.send_error_json(f"No se puede eliminar la categoría porque tiene {count} productos/servicios asociados.", 400)
                    return
                cursor.execute("DELETE FROM categorias WHERE id = ?", (c_id,))
                conn.commit()
                self.send_json({"success": True})

            elif path.startswith("/api/clientes/"):
                c_id = int(path.split("/")[-1])
                cursor.execute("DELETE FROM clientes WHERE id = ?", (c_id,))
                conn.commit()
                self.send_json({"success": True})

            elif path.startswith("/api/proveedores/"):
                p_id = int(path.split("/")[-1])
                cursor.execute("DELETE FROM proveedores WHERE id = ?", (p_id,))
                conn.commit()
                self.send_json({"success": True})

            else:
                self.send_error_json("Endpoint no reconocido", 404)

        except Exception as e:
            conn.rollback()
            self.send_error_json(str(e), 500)
        finally:
            conn.close()


import threading
import webbrowser

def is_server_responding(port):
    try:
        req = urllib.request.Request(f"http://localhost:{port}/api/config")
        with urllib.request.urlopen(req, timeout=1.5) as resp:
            return resp.status == 200
    except Exception:
        return False

def check_and_update_rates_background():
    time.sleep(1) # Esperar a que el servidor termine de iniciar
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT fecha_tasas_actualizacion, tasa_ves, tasa_cop FROM configuracion WHERE id = 1")
        row = cursor.fetchone()
        hoy = datetime.now().strftime("%Y-%m-%d")
        needs_update = False
        if not row or not row[0] or not row[0].startswith(hoy):
            needs_update = True

        if needs_update:
            print("[Auto-Tasas] Consultando tasas oficiales del BCV y TRM Colombia...")
            ves, cop, fuente, err = obtener_tasas_oficiales()
            if ves or cop:
                ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                curr_ves = row[1] if row else 45.0
                curr_cop = row[2] if row else 4100.0
                final_ves = ves if ves else curr_ves
                final_cop = cop if cop else curr_cop
                cursor.execute("""
                    UPDATE configuracion 
                    SET tasa_ves = ?, tasa_cop = ?, fecha_tasas_actualizacion = ?, fuente_tasas = ?
                    WHERE id = 1
                """, (final_ves, final_cop, ahora, fuente))
                conn.commit()
                print(f"[Auto-Tasas] Sincronizadas con éxito: BCV = {final_ves} Bs. | TRM = {final_cop} COP ({fuente})")
            else:
                print(f"[Auto-Tasas] Advertencia: {err}")
        else:
            print(f"[Auto-Tasas] Las tasas ya están actualizadas a la fecha de hoy ({row[0]}).")
        conn.close()
    except Exception as e:
        print(f"[Auto-Tasas] Excepción al verificar tasas: {e}")

def run_server():
    init_db()

    # Si ya hay un servidor activo en el puerto 8000, abrir navegador y no dar error
    if is_server_responding(PORT):
        print(f"===============================================================")
        print(f" Sistema de Control de Inventario y Facturacion Multimoneda")
        print(f"===============================================================")
        print(f" [INFO] El servidor ya se encuentra ACTIVO en: http://localhost:{PORT}")
        print(f" [INFO] Abriendo la aplicacion en su navegador web...")
        print(f"===============================================================")
        try:
            webbrowser.open(f"http://localhost:{PORT}")
        except Exception:
            pass
        return

    socketserver.ThreadingTCPServer.allow_reuse_address = True
    httpd = None
    actual_port = PORT

    ports_to_try = [PORT] if os.environ.get("PORT") else [PORT, 8001, 8002, 8080]

    for p in ports_to_try:
        try:
            server_address = ("", p)
            httpd = socketserver.ThreadingTCPServer(server_address, InventoryAppHandler)
            actual_port = p
            break
        except OSError:
            if is_server_responding(p):
                print(f"[INFO] Servidor ya activo en http://localhost:{p}. Abriendo navegador...")
                try:
                    if not os.environ.get("PORT") and not os.environ.get("RENDER"):
                        webbrowser.open(f"http://localhost:{p}")
                except Exception:
                    pass
                return
            continue

    if not httpd:
        print(f"[ERROR] No se pudo iniciar el servidor en el puerto {PORT}.")
        print(f"Verifique si otra aplicacion ajena lo esta utilizando.")
        return

    print(f"===============================================================")
    print(f" Sistema de Control de Inventario y Facturacion Multimoneda")
    print(f" Servidor iniciado exitosamente en: http://localhost:{actual_port}")
    print(f" Presione Ctrl + C para detener.")
    print(f"===============================================================")
    
    threading.Thread(target=check_and_update_rates_background, daemon=True).start()
    
    def _open_browser():
        if os.environ.get("PORT") or os.environ.get("RENDER"):
            return # En la nube no se abre navegador grafico
        time.sleep(0.8)
        try:
            webbrowser.open(f"http://localhost:{actual_port}")
        except Exception:
            pass
    threading.Thread(target=_open_browser, daemon=True).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido por el usuario.")
        httpd.server_close()

if __name__ == "__main__":
    run_server()
